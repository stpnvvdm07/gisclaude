import sys,pickle;sys.path.insert(0,'lib')
import gp,io9,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as P
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
d=pickle.load(open('out9/ent3.pkl','rb'))
x0,x1,y0,y1=[float(v) for v in sys.argv[1:5]]
fig,ax=plt.subplots(figsize=(18,18*(y1-y0)/(x1-x0)))
for g,a in io9.load(K,'buildings')[2]:
    for p in gp.polys(g): ax.add_patch(P(np.array(p[0]),fc='#ddd',ec='#888'))
for g,a in io9.load(K,'green')[2]:
    for p in gp.polys(g): ax.add_patch(P(np.array(p[0]),fc='#cfe8c0' if a['type']=='трава' else '#8cc07a',ec='none',alpha=.5))
for g,a in io9.load(K,'cells')[2]:
    for p in gp.polys(g): ax.add_patch(P(np.array(p[0]),fill=False,ec='k',lw=1))
for g,a in io9.load(A,'network')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='#c80' if a['type']=='проезд' else '#06c',lw=1)
for g,a in io9.load(K,'fences')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='brown',lw=1.5)
for g,a in io9.load(K,'arches')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='purple',lw=2)
for g,a in io9.load(K,'gates')[2]: ax.plot(*g[1],'s',c='m',ms=8,mfc='none')
col={'арка':'purple','ворота':'red','калитка':'orange','въезд':'blue','разрыв в застройке':'green','разрыв в насаждениях':'olive','не зафиксирован':'black'}
for i,(g,a) in enumerate(io9.load(K,'entries_territory')[2]):
    k=a['podtip'].replace('Вход — ','');ax.plot(*g[1],'o',c=col[k],ms=10);ax.text(g[1][0]+1,g[1][1]+1,str(i),fontsize=12,color=col[k])
for g,a in io9.load(A,'flows')[2]: ax.plot(*g[1],'*',c='r',ms=14)
for j,m in enumerate(d['M']):
    ax.plot(*m['p'],'x',c='r',ms=10);ax.text(m['p'][0],m['p'][1]-3,f'c{j}',color='r')
ax.set_xlim(x0,x1);ax.set_ylim(y0,y1);ax.set_aspect('equal');plt.savefig(sys.argv[5],dpi=50,bbox_inches='tight')
