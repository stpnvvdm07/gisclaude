# Освоенность v12: явные правила благоустройства (Б) и использования (И)
import sys,pickle,collections,cv2;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
K='out10/konkovo_v10.gpkg';A='out10/analiz_v10.gpkg'
P=pickle.load(open('out10/parcels.pkl','rb'))
lab=np.load('out10/lab.npy');w=pickle.load(open('out10/win.pkl','rb'));R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R);W.h,W.w=lab.shape
# пешеходные связи, по которым идёт >=2 путей дерева (группы «низкая»/«высокая»)
PATH=W.blank()
for g,a in io9.load(A,'network')[2]:
    if a['group'] in ('низкая','высокая'):
        for l in gp.lines(g): W.line(PATH,np.array(l),10.0)
pickle.dump(PATH,open('out12/path10.pkl','wb'))
def pmask(p):
    sx=[];m=None
    allr=np.vstack([np.array(r) for rings in p['poly'] for r in rings[:1]])
    x0,y0=allr.min(0)-1;x1,y1=allr.max(0)+1
    sw=rb.Win(x0,y0,x1,y1,R)
    m=sw.blank()
    for rings in p['poly']: sw.fill(m,[np.array(rings[0])],1,holes=[np.array(h) for h in rings[1:]])
    i0=int(round((x0-W.x0)/R));j0=int(round((y0-W.y0)/R))
    return sw,m,i0,j0
out=[]
for p in P:
    sw,m,i0,j0=pmask(p)
    h,wd=m.shape
    sub=PATH[j0:j0+h,i0:i0+wd]
    if sub.shape!=m.shape: sub=np.zeros_like(m)
    npx=max(int(m.sum()),1)
    p['near_path']=float((sub[m>0]>0).sum())/npx
    dt=cv2.distanceTransform(np.pad(m,1),cv2.DIST_L2,5)[1:-1,1:-1]*R
    p['core']=float((dt>=2.5).sum())/npx      # доля площади при ширине участка >=5 м
    p['width_max']=float(dt.max()*2)
    out.append(p)
pickle.dump(out,open('out12/parcels12.pkl','wb'))
import collections
print(collections.Counter((p['kind'].split(':')[0],p['core']<0.3) for p in out))
print('area strips',round(sum(p['area'] for p in out if p['kind']=='прочее' and p['core']<0.3)),'area прочее',round(sum(p['area'] for p in out if p['kind']=='прочее')))
for t in (0.1,0.25,0.5):
    print('near_path>=',t, round(sum(p['area'] for p in out if p['near_path']>=t)/sum(p['area'] for p in out),2))
