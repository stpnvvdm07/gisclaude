import sys,pickle,collections; sys.path.insert(0,'lib')
import gp,io9,numpy as np,networkx as nx
from scipy.stats import spearmanr
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
A=V+'analiz_v8.gpkg'
ngt,nf,net=io9.load(A,'network')
ent=gp.read(U+'81ecacc9-entrances_points_1.gpkg')
# graph
def key(p,tol=0.5): return (round(p[0]/tol),round(p[1]/tol))
G=nx.Graph(); edges=[]
PEDW={'дорожка':1.0,'тротуар':1.0,'переход':1.0,'тропа':1.2,'лестница':1.2,'проезд':1.4}
for i,(g,a) in enumerate(net):
    for l in gp.lines(g):
        l=np.array(l); k0,k1=key(l[0]),key(l[-1])
        if k0==k1: continue
        L=float(np.hypot(*np.diff(l,axis=0).T).sum())
        G.add_edge(k0,k1,eid=i,length=L,type=a['type'],pw=L*PEDW[a['type']],vw=L if a['type']=='проезд' else 3*L,pts=l)
        edges.append((i,k0,k1))
comp=sorted(nx.connected_components(G),key=len,reverse=True)
print('graph nodes',G.number_of_nodes(),'edges',G.number_of_edges(),'components',[len(c) for c in comp[:6]])
NP={k:np.array(k)*0.5 for k in G.nodes}
# snap entries
keys=list(G.nodes); KP=np.array([NP[k] for k in keys])
main=comp[0]
snap=[]
for r in ent:
    P=np.array(r['_g'][1]); best=None
    for u,v,d in G.edges(data=True):
        if u not in main: continue
        l=d['pts']
        for a,b in zip(l[:-1],l[1:]):
            dd=b-a;L=dd@dd+1e-9;t=np.clip(((P-a)@dd)/L,0,1);Q=a+dd*t;D=np.hypot(*(P-Q))
            if best is None or D<best[0]: best=(D,u,v,Q,d['type'])
    snap.append(best)
for r,s in zip(ent,snap): print(r['fid'],'snap dist',round(float(s[0]),1),s[4])
pickle.dump({'snap':[(float(s[0]),s[1],s[2],s[3].tolist(),s[4]) for s in snap]},open('out9/snap.pkl','wb'))
