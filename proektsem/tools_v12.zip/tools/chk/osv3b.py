import sys,pickle,collections; sys.path.insert(0,'lib')
import numpy as np
P=pickle.load(open('out10/parcels.pkl','rb'))
def cls(p,tb=1.0,tu=1.0):
    if p['man']>=0.5 and not p['kind'].startswith('площадка'): return 'неосвоенная'
    b=p['B']>=tb; u=p['U']>=tu
    return 'освоенная' if b and u else ('частично освоенная' if b or u else 'неосвоенная')
def share(tb,tu):
    c=collections.defaultdict(float)
    for p in P: c[cls(p,tb,tu)]+=p['area']
    t=sum(c.values()); return {k:round(100*v/t,1) for k,v in c.items()}
for tb in (0.8,1.0,1.2):
    for tu in (0.8,1.0,1.2): print('B>=',tb,'U>=',tu,share(tb,tu))
c0=np.array([407750,6167300.])
sect=collections.defaultdict(list)
for p in P:
    d=p['cen']-c0
    if p['cen'][1]>6167540 and p['cen'][0]>407480: s='север'
    elif d[0]>150 and p['cen'][1]>6167230: s='северо-восток'
    elif d[0]<-200: s='запад (к метро)'
    elif p['cen'][1]<6167120: s='юг (к ТЦ)'
    else: s='центр'
    sect[s].append((p['U'],p['area']))
for s,v in sect.items():
    v=np.array(v); print(s,len(v),'U mean (area-weighted)',round(float((v[:,0]*v[:,1]).sum()/v[:,1].sum()),2))
print('man parcels',[(p['kind'],round(p['area']),p['man']) for p in P if p['man']>=0.5][:20])
by=collections.Counter(); 
for p in P: by[(p['kind'].split(':')[0],cls(p))]+=p['area']
for k,v in sorted(by.items()): print(k,round(v))
