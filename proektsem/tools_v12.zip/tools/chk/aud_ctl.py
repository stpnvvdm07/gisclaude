import sys;sys.path.insert(0,'lib')
exec(open('chk/prev11.py').read().split("fig,ax=")[0])
A='out12/analiz_v12.gpkg';K='out12/konkovo_v12.gpkg'
fig,axs=plt.subplots(1,2,figsize=(32,10))
ax=axs[0]
polys(ax,gp.read(K,'cells'),'#fff',ec='#999',lw=.5,z=1)
cm={'контролируемая':'#5ec46e','частично контролируемая':'#e6d27a','неконтролируемая':'#b13840'}
for k,c in cm.items(): polys(ax,[r for r in gp.read(A,'control') if r['type']==k],c,z=2,al=.8)
polys(ax,gp.read(K,'buildings'),'#7a6a55',z=3)
fc={'с подъездом':'#1040ff','без подъезда':'#999','торец':'#f0a'}
for k,c in fc.items(): lines(ax,[r for r in gp.read(A,'facades') if r['kind']==k],c,1.5,4)
pts(ax,gp.read(K,'entrances_buildings'),s=12,c='k',zorder=6)
ax.set_aspect('equal');ax.autoscale();ax.axis('off');ax.set_title('control + facades')
ax=axs[1]
polys(ax,gp.read(K,'cells'),'#fff',ec='#999',lw=.5,z=1)
zc={'АЖ':'#2e8b57','ПЖ':'#a8d08d','АП':'#6852a0','ПП':'#c9b8e8'}
for k in ('ПП','ПЖ','АП','АЖ'): polys(ax,[r for r in gp.read(A,'control_zones') if r['type']==k],zc[k],z=2,al=.6)
polys(ax,gp.read(K,'buildings'),'#7a6a55',z=3)
pts(ax,gp.read(K,'entrances_buildings'),s=12,c='k',zorder=6)
ax.set_aspect('equal');ax.autoscale();ax.axis('off');ax.set_title('zones')
plt.savefig('chk/aud_ctl.png',dpi=50,bbox_inches='tight')
