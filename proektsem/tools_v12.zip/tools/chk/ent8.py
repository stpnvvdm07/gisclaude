import sys,pickle,cv2,collections;sys.path.insert(0,'lib')
import gp,io9,numpy as np
from scipy.optimize import linear_sum_assignment as lsa
exec(open('chk/ent5.py').read().split("ent=io9.load")[0])   # rasters, nearest(), ray(), dl(), gates etc.
ent=io9.load(K,'entries_territory')[2]
flows=io9.load(A,'flows')[2]
# --- arch clusters
L=[np.array(l) for g,a in io9.load(K,'arches')[2] for l in gp.lines(g)]
C=[]
for l in L:
    c=l.mean(0)
    for m in C:
        if np.hypot(*(m[0]-c))<8:m[1].append(l);break
    else:C.append([c,[l]])
AC=np.array([np.vstack(ls).mean(0) for c,ls in C])
rows=[]
for i,(g,a) in enumerate(ent):
    rows.append(dict(src='обследование',sid=i,pt=np.array(g[1]),podtip=a['podtip'].replace('Вход — ',''),comment=a['comment'],photo=a['photo'],author=a['author'],note=[]))
# --- dedup (1,55): same family within 6 m
drop=set()
for i in range(len(rows)):
    for j in range(i+1,len(rows)):
        if rows[i]['podtip']==rows[j]['podtip'] and rows[i]['podtip'] not in('ворота','калитка') and np.hypot(*(rows[i]['pt']-rows[j]['pt']))<6:
            drop.add(j);rows[i]['note'].append(f'объединён с обследованной точкой {j} (дубль, {np.hypot(*(rows[i]["pt"]-rows[j]["pt"])):.1f} м)')
            if rows[j]['comment'] and rows[j]['comment']!=rows[i]['comment']: rows[i]['comment']=(rows[i]['comment'] or '')+' / '+rows[j]['comment']
rows=[r for k,r in enumerate(rows) if k not in drop]
# --- arches
ar=[k for k,r in enumerate(rows) if r['podtip']=='арка']
D=np.array([[np.hypot(*(rows[k]['pt']-AC[j])) for j in range(len(AC))] for k in ar])
ri,ci=lsa(D)
used=set()
for r_,c_ in zip(ri,ci):
    k=ar[r_];sh=D[r_,c_];rows[k]['note'].append(f'перенесён в центр арки ({sh:.1f} м)');rows[k]['pt']=AC[c_].copy();rows[k]['arch']=int(c_);used.add(c_)
for j in range(len(AC)):
    if j not in used:
        rows.append(dict(src='слой arches',sid=None,pt=AC[j].copy(),podtip='арка',comment='арка в слое arches, полевой точки нет',photo=None,author=None,note=['добавлена по слою arches'],arch=j))
# --- gates & snapping
for r in rows:
    if r.get('arch') is not None: continue
    p=r['pt'];q,dn,t,ei=nearest(p)
    dgp=np.hypot(*(gates-p).T);gk=dgp.argmin()
    if r['podtip']=='ворота' and dgp[gk]<=12:
        r['pt']=gates[gk].copy();r['note'].append(f'перенесён в точку ворот ({dgp[gk]:.1f} м)')
    elif dn<=15 and dn>0.3:
        r['pt']=q.copy();r['note'].append(f'привязан к оси сети ({dn:.1f} м)')
    elif dn>15: r['note'].append(f'далеко от сети ({dn:.1f} м), не сдвигался')
# --- flow points not matched
fl=[]
for g,a in flows:
    p=np.array(g[1]);d=min(np.hypot(*(r['pt']-p)) for r in rows)
    if d>20:
        q,dn,t,ei=nearest(p)
        fl.append((a,p,q,dn,d))
for a,p,q,dn,d in fl:
    rows.append(dict(src='замер потока',sid=None,pt=q.copy(),podtip=None,comment=f"точка замера потока №{a['id']} ({a['type']}), полевой точки входа нет",photo=None,author=None,note=[f"добавлен по замеру потока (ближайший вход {d:.0f} м)"],ftype=a['type'],fid=a['id']))
# --- features
for r in rows:
    p=r['pt'];q,dn,t,ei=nearest(p);n=np.array([-t[1],t[0]]);r['t']=t
    px=(min(max(int(round((p[1]-y0)/R)),0),W.h-1),min(max(int(round((p[0]-x0)/R)),0),W.w-1))
    r['depth']=float(DT[px]);r['d_net']=dn;r['net_type']=net[ei][1]['type']
    r['d_gate']=float(np.hypot(*(gates-p).T).min());r['d_fence']=dl(p,fenc)
    for nm,m in (('B',Bm),('T',Tm)):
        r['L'+nm]=ray(m,q,n);r['R'+nm]=ray(m,q,-n)
    r['gap_B']=r['LB']+r['RB'];r['gap_T']=r['LT']+r['RT']
    # derived podtip for added flow entries
    if r['podtip'] is None:
        if r['ftype']=='смешанный' and r['net_type']=='проезд': r['podtip']='въезд'
        elif r['gap_B']<=40: r['podtip']='разрыв в застройке'
        elif r['gap_T']<=25 and r['depth']<30: r['podtip']='разрыв в насаждениях'
        else: r['podtip']='не зафиксирован'
        r['note'].append('способ фиксации определён по геометрии: '+r['podtip'])
# --- classification
for r in rows:
    cm=(r['comment'] or '').lower()
    if r['podtip']=='не зафиксирован' and 'въезд' in cm:
        r['note'].append('в комментарии «въезд» → способ фиксации изменён с «не зафиксирован» на «въезд»');r['podtip']='въезд'
    pt=r['podtip'];ev=[]
    barrier=(r['d_gate']<=8 and r['d_fence']<=10) or any(w in cm for w in('шлагбаум','ворот'))
    framed=r['gap_B']<=40
    if pt in('арка','ворота','калитка'): deg='высокая';ev.append({'арка':'проходная арка в здании','ворота':'ворота в ограждении','калитка':'калитка в ограждении'}[pt])
    elif pt=='въезд':
        if barrier: deg='высокая';ev.append('въезд с шлагбаумом/воротами')
        elif framed: deg='средняя';ev.append(f"въезд между зданиями, просвет {r['gap_B']:.0f} м")
        else: deg='низкая';ev.append('въезд обозначен только проезжей частью, зданий/ограждений по сторонам нет')
    elif pt=='разрыв в застройке':
        if framed: deg='средняя';ev.append(f"разрыв в застройке, просвет между фасадами {r['gap_B']:.0f} м")
        else: deg='нет';ev.append(f"фасады не фиксируют проход с двух сторон (слева {r['LB']:.0f} м / справа {r['RB']:.0f} м)")
    elif pt=='разрыв в насаждениях': deg='низкая';ev.append('фиксация только зелёными насаждениями')
    else: deg='нет';ev.append('вход пространственно не зафиксирован')
    r['deg']=deg;r['cls']='организован' if deg in('высокая','средняя') or (pt=='въезд') else 'не организован'
    r['ev']='; '.join(ev)
    r['level']='внутренний' if r['depth']>20 else 'внешний'
# --- nodes
n=len(rows);par=list(range(n))
def f(x):
    while par[x]!=x:par[x]=par[par[x]];x=par[x]
    return x
for i in range(n):
    for j in range(i+1,n):
        if np.hypot(*(rows[i]['pt']-rows[j]['pt']))<=12: par[f(i)]=f(j)
rk={}
for i in range(n): rows[i]['node']=rk.setdefault(f(i),len(rk)+1)
pickle.dump(rows,open('out9/ent8.pkl','wb'))
print(len(rows),collections.Counter(r['cls'] for r in rows),collections.Counter(r['deg'] for r in rows),collections.Counter((r['podtip'],r['cls']) for r in rows),collections.Counter(r['level'] for r in rows),'nodes',len(rk))
for r in []: print(r['node'],r['src'][:5],r['sid'],r['podtip'],r['cls'],r['level'],r['ev'],'|',r['note'])
