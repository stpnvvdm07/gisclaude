import sys,pickle; sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np,msk,collections
from io9 import tow
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
log=[]
def say(*a):
    s=' '.join(str(x) for x in a); print(s); log.append(s)
bgt,bf,bld=io9.load(K,'buildings')
bb=[g for g,_ in io9.load(K,'boundary')[2]][0]
bnd=np.vstack([np.array(p[0]) for p in gp.polys(bb)]); x0,y0=bnd.min(0)-40; x1,y1=bnd.max(0)+40
W=rb.Win(x0,y0,x1,y1,0.2); say('window',W.w,W.h)
Bm=W.blank()
brings=[]  # (id, ring)
for g,a in bld:
    for p in gp.polys(g): W.fill(Bm,[p[0]]); brings.append((a['id'],np.array(p[0]),g))
# ---------------- parking
pgt,pf,park=io9.load(K,'parking')
res=[]; seen=[]
for g,a in park:
    p=gp.polys(g)[0]; M=W.fill(W.blank(),[p[0]]); n=M.sum(); ov=(M&Bm).sum()/n
    # duplicate of building footprint?
    dup=None
    if ov>0.95: dup='здание-паркинг'
    res.append((a,p,M,ov,dup))
    say('parking',a.get('area'),'overlap bldg',round(float(ov),2),dup)
newpark=[]; used_foot=False
for a,p,M,ov,dup in res:
    if dup:
        if used_foot: say('  дубль контура здания — убран'); continue
        used_foot=True; polys=W.polys(M); kind='здание-паркинг (многоуровневый)'
    else:
        R=M.copy(); R[Bm>0]=0
        R=cv2_open=None
        R=(M&(1-Bm)).astype(np.uint8)
        polys=W.polys(R,minarea=4.0)
        kind='открытая'
        if ov>0.25:
            big=[1 for _,r,_g in brings if len(r)>2 and abs(rb.ringarea(r))>1500 and (W.fill(W.blank(),[r])&M).sum()>0.9*W.fill(W.blank(),[r]).sum()]
            kind='открытая (вокруг здания-паркинга)' if big else 'гаражи'
    for pl in polys:
        ar=rb.polyarea(pl)
        newpark.append((('Polygon',[r.tolist() for r in pl]),{'kind':kind,'area':round(ar,1)}))
say('parking out',len(newpark),'area',round(sum(a['area'] for _,a in newpark)))

# ---------------- loading zones
cgt,cf,comp=io9.load(U+'fc0568b7-competitions_2.gpkg','competition')
ngt,nf,net=io9.load(A,'network')
C=W.blank()
HW={'проезд':2.0,'тротуар':1.2,'дорожка':0.9,'тропа':0.7}
for g,a in net:
    if a['type'] in HW:
        for l in gp.lines(g): W.line(C,np.array(l),HW[a['type']])
for g,a in newpark: W.fill(C,[np.array(p) for p in [g[1][0]]])
import cv2
kern=np.ones((3,3),np.uint8)
lz=[]; tot0=tot1=0
for i,(g,a) in enumerate(comp,1):
    M=W.blank()
    for p in gp.polys(g): W.fill(M,[p[0]])
    a0=M.sum()*W.res**2
    Z=(M&C&(1-Bm)).astype(np.uint8)
    Z=cv2.morphologyEx(Z,cv2.MORPH_OPEN,kern)
    pls=W.polys(Z,minarea=10.0)
    a1=sum(rb.polyarea(p) for p in pls); tot0+=a0; tot1+=a1
    say('loading',i,'blob',round(a0),'-> clean',round(a1),'parts',len(pls))
    for pl in pls:
        lz.append((('Polygon',[r.tolist() for r in pl]),{'src':i,'area':round(rb.polyarea(pl),1),'function':a['function'],'danger':a['danger'],'isolation':a['isolation']}))
say('loading total',round(tot0),'->',round(tot1),'features',len(lz))
pickle.dump({'park':newpark,'lz':lz},open('out9/park.pkl','wb'))
open('out9/log1.txt','w').write('\n'.join(log))
