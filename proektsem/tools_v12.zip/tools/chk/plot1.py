import sys; sys.path.insert(0,'lib')
import gp, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
fig,ax=plt.subplots(figsize=(16,13))
def pl(rs,fc,ec='k',a=.5,lw=.4):
    for r in rs:
        for p in gp.polys(r['_g']):
            ax.add_patch(MP(np.array(p[0]),fc=fc,ec=ec,alpha=a,lw=lw))
pl(gp.read(V+'konkovo_v8.gpkg','buildings'),'#a39279')
pl(gp.read(V+'konkovo_v8.gpkg','parking'),'#8bb0b0',a=.7)
pl(gp.read(U+'fc0568b7-competitions_2.gpkg'),'#b13840',a=.5)
pl(gp.read(V+'konkovo_v8.gpkg','boundary'),'none','#6852a0',1,1.5)
for r in gp.read(V+'analiz_v8.gpkg','network'):
    for l in gp.lines(r['_g']):
        a=np.array(l); ax.plot(a[:,0],a[:,1],c='#555',lw=.5)
ax.set_aspect('equal'); ax.autoscale()
plt.savefig('chk/park_comp.png',dpi=110,bbox_inches='tight')
