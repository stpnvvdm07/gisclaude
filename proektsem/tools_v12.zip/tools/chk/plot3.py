import sys; sys.path.insert(0,'lib')
import gp, io9, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
x0,x1,y0,y1=407540,407900,6167200,6167420
fig,ax=plt.subplots(figsize=(18,11))
def poly(rows,fc,ec='k',a=.6,lw=.5):
    for r in rows:
        for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc=fc,ec=ec,alpha=a,lw=lw))
g=gp.read(K,'green')
poly([r for r in g if r['type']=='трава'],'#bddaae',ec='none'); poly([r for r in g if r['type']=='деревья'],'#8ed0ad',ec='none')
poly(gp.read(K,'playgrounds'),'#d9c35b'); poly(gp.read(K,'parking'),'#8bb0b0')
b=gp.read(K,'buildings'); poly(b,'#a39279')
for r in b:
    c=np.vstack([np.array(p[0]) for p in gp.polys(r['_g'])]).mean(0)
    if x0<c[0]<x1 and y0<c[1]<y1: ax.text(c[0],c[1],str(r['id']),fontsize=8)
for r in gp.read(A,'network'):
    for l in gp.lines(r['_g']): a=np.array(l); ax.plot(a[:,0],a[:,1],c='#555',lw=.7)
for r in gp.read(K,'fences'):
    for l in gp.lines(r['_g']): a=np.array(l); ax.plot(a[:,0],a[:,1],c='#b13840',lw=1)
for r in gp.read(A,'heights'):
    if r['_g'][0]=='Point': ax.text(*r['_g'][1],f"{r['z']:.0f}",fontsize=5,color='#06c')
ax.set_xlim(x0,x1);ax.set_ylim(y0,y1);ax.set_aspect('equal');plt.savefig('chk/zoom_misis.png',dpi=80,bbox_inches='tight')
