import sys,glob;sys.path.insert(0,'lib')
exec(open('chk/prev11.py').read().split("fig,ax=")[0])
fig,ax=plt.subplots(figsize=(22,13))
polys(ax,gp.read(K,'cells'),'#f4f1ea',ec='#999',lw=.5,z=1)
polys(ax,gp.read(K,'buildings'),'#b9ab95',z=3)
lines(ax,gp.read(K,'fences'),'#6852a0',.6,4)
lines(ax,[r for r in gp.read(A,'network') if r['veh']],'#888',1.2,2)
lines(ax,[r for r in gp.read(A,'network') if not r['veh']],'#bbb',.6,2)
polys(ax,gp.read(K,'boundary'),'none',ec='#c978d3',lw=2,z=5)
e=gp.read(K,'entries_territory')
col={'организован':'#2a9d4b','не организован':'#d62828'}
for r in e:
    q=T([r['_g'][1]])[0]
    mk={'внешний':'o','внутренний':'s'}[r['level']]
    ax.scatter(*q,s=60,marker=mk,c=col[r['fix_class']],edgecolors='k',zorder=8)
    ax.text(q[0]+3,q[1]+3,f"{r['fid']}:{r['podtip'][7:12]}/{r['degree']}",fontsize=6,zorder=9)
for r in gp.read(K,'entry_nodes'):
    q=T([r['_g'][1]])[0]; ax.scatter(*q,s=260,facecolors='none',edgecolors='#333',lw=.8,zorder=7)
    ax.text(q[0]-6,q[1]-9,f"N{r['node']}",fontsize=6,color='#333',zorder=9)
for r in gp.read(K,'cells'):
    c=T(np.array(gp.polys(r['_g'])[0][0]).mean(0));ax.text(*c,str(r['num']),fontsize=9,color='#777')
ax.set_aspect('equal');ax.autoscale();ax.axis('off')
plt.savefig('chk/aud_ent.png',dpi=70,bbox_inches='tight')
