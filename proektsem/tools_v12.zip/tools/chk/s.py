import sys; sys.path.insert(0,'lib')
import gp, numpy as np, geo
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
b8=gp.read(V+'konkovo_v8.gpkg','buildings')
for r in gp.read(U+'c21fbc75-buildings_2.gpkg'):
    if r['id'] is None:
        for p in gp.polys(r['_g']):
            a=np.array(p[0]); c=a.mean(0); print(r['fid'],'cen',c.round(1),'verts',len(a), 'bbox',np.ptp(a,0).round(1))
            # nearest v8 buildings within 40m
            for o in b8:
                for q in gp.polys(o['_g']):
                    cc=np.array(q[0]).mean(0)
                    if np.hypot(*(cc-c))<45: print('   v8',o['id'],o['Тип здания'],round(abs(geo.area(q[0])),1),np.hypot(*(cc-c)).round(1))
