import sys; sys.path.insert(0,'lib')
import gp, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
V='/mnt/user-data/uploads/proektsem/vector/'
pk=gp.read(V+'konkovo_v8.gpkg','parking'); bl=gp.read(V+'konkovo_v8.gpkg','buildings')
fig,axs=plt.subplots(1,3,figsize=(21,7))
def cen(r): return np.vstack([np.array(p[0]) for p in gp.polys(r['_g'])]).mean(0)
for ax,fids in zip(axs,[(1,15,16),(2,),(11,)]):
    P=[r for r in pk if r['fid'] in fids]; c=np.mean([cen(r) for r in P],0)
    for r in bl:
        for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc='#a39279',alpha=.4,ec='k',lw=.5))
        cc=cen(r)
        if abs(cc[0]-c[0])<120 and abs(cc[1]-c[1])<120: ax.text(*cc,str(r['id'])+' '+str(r.get('Тип здания'))+' '+str(r.get('Этажность')),fontsize=7)
    for i,r in enumerate(P):
        for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc='none',ec=['r','b','g'][i%3],lw=1.5))
    ax.set_xlim(c[0]-90,c[0]+90);ax.set_ylim(c[1]-60,c[1]+60);ax.set_aspect('equal');ax.set_title(str(fids))
plt.savefig('chk/park_det.png',dpi=80,bbox_inches='tight')
