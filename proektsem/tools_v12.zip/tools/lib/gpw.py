import sqlite3,struct,datetime,os
SRS=[(-1,'Undefined cartesian SRS','NONE',-1,'undefined',None),(0,'Undefined geographic SRS','NONE',0,'undefined',None),
 (4326,'WGS 84 geodetic','EPSG',4326,'GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563,AUTHORITY["EPSG","7030"]],AUTHORITY["EPSG","6326"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AXIS["Latitude",NORTH],AXIS["Longitude",EAST],AUTHORITY["EPSG","4326"]]',None),
 (32637,'WGS 84 / UTM zone 37N','EPSG',32637,'PROJCS["WGS 84 / UTM zone 37N",GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563,AUTHORITY["EPSG","7030"]],AUTHORITY["EPSG","6326"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4326"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",0],PARAMETER["central_meridian",39],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",500000],PARAMETER["false_northing",0],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AXIS["Easting",EAST],AXIS["Northing",NORTH],AUTHORITY["EPSG","32637"]]',None)]
def _ring(r): return struct.pack('<I',len(r))+b''.join(struct.pack('<dd',float(x),float(y)) for x,y in r)
def wkb(g):
    t,c=g
    if t=='Point': return struct.pack('<BI',1,1)+struct.pack('<dd',float(c[0]),float(c[1]))
    if t=='LineString': return struct.pack('<BI',1,2)+_ring(c)
    if t=='Polygon': return struct.pack('<BII',1,3,len(c))+b''.join(_ring(r) for r in c)
    if t=='MultiPolygon': return struct.pack('<BII',1,6,len(c))+b''.join(wkb(('Polygon',p)) for p in c)
    if t=='MultiLineString': return struct.pack('<BII',1,5,len(c))+b''.join(wkb(('LineString',p)) for p in c)
    raise ValueError(t)
def _pts(g):
    t,c=g
    if t=='Point': return [c]
    if t=='LineString': return list(c)
    if t=='Polygon': return [q for r in c for q in r]
    if t=='MultiPolygon': return [q for p in c for r in p for q in r]
    if t=='MultiLineString': return [q for l in c for q in l]
def blob(g,srs):
    P=_pts(g); xs=[p[0] for p in P]; ys=[p[1] for p in P]
    return b'GP'+bytes([0,3])+struct.pack('<i',srs)+struct.pack('<dddd',min(xs),max(xs),min(ys),max(ys))+wkb(g)
def create(path):
    if os.path.exists(path): os.remove(path)
    c=sqlite3.connect(path)
    c.execute('PRAGMA application_id=1196444487'); c.execute('PRAGMA user_version=10400')
    c.executescript('''
CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT NOT NULL, srs_id INTEGER NOT NULL PRIMARY KEY, organization TEXT NOT NULL, organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL, description TEXT);
CREATE TABLE gpkg_contents (table_name TEXT NOT NULL PRIMARY KEY, data_type TEXT NOT NULL, identifier TEXT UNIQUE, description TEXT DEFAULT '', last_change DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE, srs_id INTEGER, CONSTRAINT fk_gc_r_srs_id FOREIGN KEY (srs_id) REFERENCES gpkg_spatial_ref_sys(srs_id));
CREATE TABLE gpkg_geometry_columns (table_name TEXT NOT NULL, column_name TEXT NOT NULL, geometry_type_name TEXT NOT NULL, srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL, CONSTRAINT pk_geom_cols PRIMARY KEY (table_name, column_name), CONSTRAINT uk_gc_table_name UNIQUE (table_name), CONSTRAINT fk_gc_tn FOREIGN KEY (table_name) REFERENCES gpkg_contents(table_name), CONSTRAINT fk_gc_srs FOREIGN KEY (srs_id) REFERENCES gpkg_spatial_ref_sys (srs_id));
CREATE TABLE gpkg_ogr_contents(table_name TEXT NOT NULL PRIMARY KEY, feature_count INTEGER DEFAULT NULL);
''')
    for name,sid,org,oid,defn,desc in [(s[1],s[0],s[2],s[3],s[4],s[5]) for s in SRS]:
        c.execute('INSERT INTO gpkg_spatial_ref_sys VALUES (?,?,?,?,?,?)',(name,sid,org,oid,defn,desc))
    c.commit(); return c
def add_layer(c,name,gtype,fields,feats,srs=32637,desc=''):
    cols=', '.join(f'"{n}" {t}' for n,t in fields)
    c.execute(f'CREATE TABLE "{name}" (fid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, geom {gtype.upper()}{", "+cols if cols else ""})')
    xs=[];ys=[]
    for g,a in feats:
        P=_pts(g); xs+=[p[0] for p in P]; ys+=[p[1] for p in P]
        c.execute(f'INSERT INTO "{name}" (geom{"".join(","+chr(34)+n+chr(34) for n,_ in fields)}) VALUES ({",".join("?"*(len(fields)+1))})',[blob(g,srs)]+[a.get(n) for n,_ in fields])
    now=datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z')
    if not xs: xs=[0];ys=[0]
    c.execute('INSERT INTO gpkg_contents (table_name,data_type,identifier,description,last_change,min_x,min_y,max_x,max_y,srs_id) VALUES (?,?,?,?,?,?,?,?,?,?)',(name,'features',name,desc,now,min(xs),min(ys),max(xs),max(ys),srs))
    c.execute('INSERT INTO gpkg_geometry_columns (table_name,column_name,geometry_type_name,srs_id,z,m) VALUES (?,?,?,?,0,0)',(name,'geom',gtype.upper(),srs))
    c.execute('INSERT INTO gpkg_ogr_contents (table_name,feature_count) VALUES (?,?)',(name,len(feats)))
    c.commit()
