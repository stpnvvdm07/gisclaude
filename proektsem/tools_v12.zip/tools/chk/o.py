import sys; sys.path.insert(0,'lib')
import dxf, collections, numpy as np
E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf',layers={'PROEZDY','ULICY_PROEZZH_CHAST','DOR_DOROZHKA','ПЕШЕХОДНЫЕ_ДОРОЖКИ','AVTOSTOYANKI','ТРОТУАРЫ','ZDANIYA','ПРОЕЗДЫ'})
for L in sorted({e['layer'] for e in E}):
    es=[e for e in E if e['layer']==L]
    print(L,len(es),collections.Counter((e['type'],bool(e.get('closed')) ) for e in es), 'closed by coords',sum(1 for e in es if len(e['pts'])>3 and np.hypot(*(np.array(e['pts'][0])-e['pts'][-1]))<0.01))
