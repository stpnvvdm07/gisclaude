import collections
def pairs(path,enc='utf-8'):
    with open(path,'r',encoding=enc,errors='replace') as f:
        while True:
            c=f.readline()
            if not c: return
            yield c.strip(), f.readline().rstrip('\r\n').strip()
def read(path,layers=None,bbox=None):
    """entities of ENTITIES section: dict(type,layer,pts,closed,x,y,r,text,width)"""
    out=[]; sec=None; cur=None; poly=None
    def keep(e):
        if layers is not None and e['layer'] not in layers: return False
        if bbox is not None:
            P=e['pts'] or ([(e['x'],e['y'])] if 'x' in e else [])
            if not P: return False
            x0,y0,x1,y1=bbox
            if not any(x0<=x<=x1 and y0<=y<=y1 for x,y in P): return False
        return True
    def flush():
        nonlocal cur,poly
        if cur is None: return
        t=cur['type']
        if t=='POLYLINE': poly=cur; poly['pts']=[]; cur=None; return
        if t=='VERTEX':
            if poly is not None and 'x' in cur: poly['pts'].append((cur['x'],cur['y']))
            cur=None; return
        if t=='SEQEND':
            if poly is not None and keep(poly): out.append(poly)
            poly=None; cur=None; return
        if keep(cur): out.append(cur)
        cur=None
    it=pairs(path)
    for c,v in it:
        if c=='0':
            if sec=='ENTITIES': flush()
            if v=='SECTION': c2,v2=next(it); sec=v2; continue
            if v=='ENDSEC': sec=None; continue
            if sec=='ENTITIES': cur={'type':v,'layer':None,'pts':[],'closed':False}
            continue
        if sec!='ENTITIES' or cur is None: continue
        t=cur['type']
        if c=='8': cur['layer']=v
        elif c=='62': cur['color']=int(v)
        elif c=='70': cur['flag']=int(v); cur['closed']=bool(int(v)&1)
        elif c=='1': cur['text']=v
        elif c=='2': cur['block']=v
        elif c=='40': cur['r']=float(v)
        elif c=='43': cur['width']=float(v)
        elif t=='LWPOLYLINE':
            if c=='10': cur['_x']=float(v)
            elif c=='20': cur['pts'].append((cur.pop('_x'),float(v)))
        elif t=='LINE':
            if c=='10': cur['x1']=float(v)
            elif c=='20': cur['y1']=float(v)
            elif c=='11': cur['x2']=float(v)
            elif c=='21': cur['y2']=float(v); cur['pts']=[(cur['x1'],cur['y1']),(cur['x2'],cur['y2'])]
        else:
            if c=='10': cur['x']=float(v)
            elif c=='20': cur['y']=float(v)
    return out
def inventory(path,bbox=None):
    cnt=collections.Counter(); ext={}
    for e in read(path,bbox=bbox):
        cnt[(e['layer'],e['type'])]+=1
    return cnt
