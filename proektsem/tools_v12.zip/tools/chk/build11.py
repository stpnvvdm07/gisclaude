import sys,pickle,collections,cv2;sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np
from io9 import tow
K='out10/konkovo_v10.gpkg';A='out10/analiz_v10.gpkg'
d=pickle.load(open('out10/viol.pkl','rb'));V=d['V'];m=pickle.load(open('out10/viol2.pkl','rb'));base=m['base'];scope=set(m['scope']);ITEMS=m['ITEMS']
cls=lambda s:'высокая' if s>=6 else ('средняя' if s>=4 else 'низкая')
ck=gpw.create('out11/problems_v11.gpkg')
# viol_cells
gt,f,rows=io9.load(K,'cells');feats=[]
for g,a in rows:
    n=a['num'];v=V[n];r=base.get(n)
    o={'num':n,'in_scope':1 if n in scope else 0,'is_anal':a['is_anal'],'pod':v['pod'],'score':r[0] if r else None,'cls':cls(r[0]) if r else None,'comfort':a['comfort']}
    for it in ITEMS: o['v'+it]=(1 if r[1][it] else 0) if r else None
    o.update(ent_non=v['ent_non'],wear40=v['wear40'],loading_m2=v['loading_m2'],danger_obj=v['danger_obj'],combined_m=v['combined_m'],transit_res_m=v['transit_res_m'],biz_transit=v['biz_transit'],pg_out=v['pg_out'],competition_m2=v['competition_m2'],unc_pct=v['unc_pct'],unosv_pct=v['unosv_pct'],fav_closed=v['fav_closed'])
    feats.append((tow(g),o))
fl=[('num','INTEGER'),('in_scope','INTEGER'),('is_anal','INTEGER'),('pod','INTEGER'),('score','INTEGER'),('cls','TEXT'),('comfort','TEXT')]+[('v'+it,'INTEGER') for it in ITEMS]+[('ent_non','INTEGER'),('wear40','INTEGER'),('loading_m2','INTEGER'),('danger_obj','INTEGER'),('combined_m','INTEGER'),('transit_res_m','INTEGER'),('biz_transit','INTEGER'),('pg_out','INTEGER'),('competition_m2','INTEGER'),('unc_pct','REAL'),('unosv_pct','REAL'),('fav_closed','INTEGER')]
gpw.add_layer(ck,'viol_cells','POLYGON',fl,feats)
# 1б узлы
gt,f,rows=io9.load(K,'entry_nodes')
gpw.add_layer(ck,'p1b_entry_nodes',gt,f,[(tow(g),a) for g,a in rows if a['fix_class']=='не организован'])
gpw.add_layer(ck,'pre_entry_nodes',gt,f,[(tow(g),a) for g,a in rows if a['fix_class']=='организован' and a['degree']=='высокая'])
# 1г износ
bw={b['id']:b for b in d['bw']};gt,f,rows=io9.load(K,'buildings');bf=[];pf=[]
for g,a in rows:
    if a['id'] in bw and bw[a['id']]['w']>=0.40:
        b=bw[a['id']];bf.append((tow(g),{'id':a['id'],'addr':a['Адрес / ориентир'],'wear':round(float(b['w']),2),'src':'указан' if b['off'] is not None else 'оценка команды','wear_est':None if b['est'] is None else round(float(b['est']),2)}))
gpw.add_layer(ck,'p1g_wear',gt,[('id','INTEGER'),('addr','TEXT'),('wear','REAL'),('src','TEXT'),('wear_est','REAL')],bf)
# borderline (official 0.39..0.40, est>=.40)
bl=[(tow(g),{'id':a['id'],'addr':a['Адрес / ориентир'],'wear':round(float(bw[a['id']]['w']),2),'src':'указан','wear_est':round(float(bw[a['id']]['est']),2) if bw[a['id']]['est'] else None}) for g,a in rows if a['id'] in bw and bw[a['id']]['w']<0.40 and bw[a['id']]['w_hi']>=0.40]
gpw.add_layer(ck,'p1g_wear_border',gt,[('id','INTEGER'),('addr','TEXT'),('wear','REAL'),('src','TEXT'),('wear_est','REAL')],bl)
# 2б объекты
gpw.add_layer(ck,'p2b_objects','POINT',[('src','TEXT'),('name','TEXT'),('kind','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'src':s,'name':n,'kind':k}) for s,n,p,k in d['objs']])
gpw.add_layer(ck,'pre_fav_closed','POINT',[('name','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'name':n}) for n,p in d['fav']])
# 2в
gpw.add_layer(ck,'p2c_combined','LINESTRING',[('razdel','TEXT'),('group','TEXT'),('vgroup','TEXT'),('length','REAL')],[(('LineString',np.asarray(l).tolist()),{'razdel':a['razdel'],'group':a['group'],'vgroup':a['vgroup'],'length':a['length']}) for g,a in d['comb_edges'] for l in gp.lines(g)])
# 3а/3б/3в
tr=io9.load(A,'transit')[2]
gpw.add_layer(ck,'p3b_biz','POINT',[('name','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'name':n}) for n,p in d['biz3']])
gpw.add_layer(ck,'p3v_playgrounds','POLYGON',[('type','TEXT'),('zone','TEXT'),('control','TEXT')],[(tow(g),{'type':a['type'],'zone':a['zone'],'control':a['control']}) for g,a in d['pg3']])
# 3а: высокий транзит в личных зонах — рёбра
cz=[(g,a) for g,a in io9.load(A,'control_zones')[2] if a['type'] in('АЖ','ПЖ')]
allp=np.vstack([np.array(p[0]) for g,a in io9.load(K,'cells')[2] for p in gp.polys(g)])
W=rb.Win(*(allp.min(0)-15),*(allp.max(0)+15),0.5);PERS=W.blank()
for g,a in cz:
    for p in gp.polys(g): W.fill(PERS,[np.array(p[0])],1)
lines=[]
for g,a in tr:
    if a['cls']!='высокая':continue
    for l in gp.lines(g):
        l=np.array(l);L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))];s=np.arange(0.5,L[-1],1.0)
        if not len(s):continue
        P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])];px=np.round(W.px(P)).astype(int)
        if PERS[px[:,1],px[:,0]].mean()>=0.5: lines.append((('LineString',l.tolist()),{'mode':a['mode'],'load':a['load'],'length':a['length']}))
gpw.add_layer(ck,'p3a_transit_res','LINESTRING',[('mode','TEXT'),('load','REAL'),('length','REAL')],lines)
gpw.add_layer(ck,'pre_axes','LINESTRING',[('mode','TEXT'),('load','REAL'),('length','REAL')],[(tow(g),{'mode':a['mode'],'load':a['load'],'length':a['length']}) for g,a in tr if a['cls']=='высокая' and a['mode']=='пешеходный'])
# предпосылки: освоенные и контролируемые участки
ctl=W.blank()
for g,a in io9.load(A,'control')[2]:
    if a['type']=='контролируемая':
        for p in gp.polys(g): W.fill(ctl,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
pre=[]
for g,a in io9.load(A,'osvoennost')[2]:
    if a['cls']!='освоенная':continue
    ps=gp.polys(g);mm=W.blank()
    for p in ps: W.fill(mm,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
    ys,xs=np.nonzero(mm)
    if len(ys) and ctl[ys,xs].mean()>=0.5: pre.append((tow(g),{'kind':a['kind'],'area':a['area'],'cell':a['cell']}))
gpw.add_layer(ck,'pre_osv_ctl','POLYGON',[('kind','TEXT'),('area','INTEGER'),('cell','INTEGER')],pre)
print('pre parcels',len(pre),sum(a['area'] for g,a in pre),'p3a lines',len(lines))
# уровни комфорт
gpw.add_layer(ck,'pre_cells','POLYGON',[('num','INTEGER'),('score','REAL')],[(tow(g),{'num':a['num'],'score':a['score']}) for g,a in rows if False]) if False else None
gt,f,cr=io9.load(K,'cells')
gpw.add_layer(ck,'pre_cells',gt,[('num','INTEGER'),('score','REAL'),('comfort','TEXT')],[(tow(g),{'num':a['num'],'score':a['score'],'comfort':a['comfort']}) for g,a in cr if a['comfort']=='Комфортная' and a['is_anal']==1])
ck.close()
