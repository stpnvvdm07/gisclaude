import sys; sys.path.insert(0,'lib')
import gp, collections, math
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
f={'ent':'81ecacc9-entrances_points_1.gpkg','bld':'c21fbc75-buildings_2.gpkg','biz':'92246443-business_2.gpkg','comp':'fc0568b7-competitions_2.gpkg','pg':'5801ca10-playground_2.gpkg'}
D={}
for k,v in f.items():
    print(k,gp.layers(U+v)); D[k]=gp.read(U+v)
    print(len(D[k]), [c for c in D[k][0] if c!='_g'])
print('--- entrances')
for r in D['ent']: print(r['fid'],r['_g'][1],{k:r[k] for k in ('in_car','out_car','in_human','out_human','couriers','type')})
for k in ('bld','biz','comp','pg'):
    for fld in ('function','danger','isolation'):
        print(k,fld,collections.Counter(r.get(fld) for r in D[k]))
