import sys,pickle; sys.path.insert(0,'lib')
import gp, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
V='/mnt/user-data/uploads/proektsem/vector/'
d=pickle.load(open('out9/park.pkl','rb'))
fig,ax=plt.subplots(figsize=(18,14))
for r in gp.read(V+'konkovo_v8.gpkg','buildings'):
    for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc='#d9d0c0',ec='#a39279',lw=.5))
for r in gp.read(V+'analiz_v8.gpkg','network'):
    for l in gp.lines(r['_g']): a=np.array(l); ax.plot(a[:,0],a[:,1],c='#bbb',lw=.5)
for g,a in d['park']:
    ax.add_patch(MP(np.array(g[1][0]),fc='#8bb0b0',ec='#2a6f6f',lw=.8,alpha=.8))
    for h in g[1][1:]: ax.add_patch(MP(np.array(h),fc='white',ec='#2a6f6f',lw=.8))
for g,a in d['lz']: ax.add_patch(MP(np.array(g[1][0]),fc='#b13840',ec='#700',lw=.6,alpha=.8))
ax.set_aspect('equal');ax.autoscale();plt.savefig('chk/park_lz2.png',dpi=85,bbox_inches='tight')
