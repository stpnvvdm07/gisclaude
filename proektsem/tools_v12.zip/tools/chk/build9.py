import sys,pickle,collections,cv2,os; sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np
from io9 import tow
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
OUT='out9/'
park=pickle.load(open(OUT+'park.pkl','rb')); biz=pickle.load(open(OUT+'biz.pkl','rb')); f2=pickle.load(open(OUT+'fix2.pkl','rb')); f2b=pickle.load(open(OUT+'fix2b.pkl','rb'))
parcels=pickle.load(open(OUT+'parcels.pkl','rb')); snap=pickle.load(open(OUT+'snap.pkl','rb'))['snap']; tr=pickle.load(open(OUT+'transit.pkl','rb')); tc=pickle.load(open(OUT+'treecmp.pkl','rb'))['tree_cmp']
man=pickle.load(open(OUT+'man.pkl','rb'))['man']
lab=np.load(OUT+'lab.npy'); w=pickle.load(open(OUT+'win.pkl','rb')); R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R); W.h,W.w=lab.shape
def poly_geom(pl): return ('Polygon',[np.asarray(r).tolist() for r in pl])
# ---------- konkovo_v9
ck=gpw.create(OUT+'konkovo_v9.gpkg')
SKIP={'parking','buildings','playgrounds'}
for t in io9.__dict__ and ['arches','boundary','cells','cells_excluded','crossings','entrances_buildings','entries_territory','fences','garbage','gates','green','trees']:
    gt,f,rows=io9.load(K,t); gpw.add_layer(ck,t,gt,f,[(tow(g),a) for g,a in rows])
# buildings + assessments
gt,f=io9.meta(K,'buildings'); rows=gp.read(K,'buildings'); feats=[]
for r in rows:
    a={k:r[k] for k,_ in f}; asm=f2['bld_assess'].get(r['fid'],{})
    for k in ('function','danger','isolation'): a[k]=asm.get(k)
    feats.append((tow(r['_g']),a))
gpw.add_layer(ck,'buildings',gt,f+[('function','TEXT'),('danger','TEXT'),('isolation','TEXT')],feats)
# parking
gpw.add_layer(ck,'parking','POLYGON',[('kind','TEXT'),('area','INTEGER')],[(g,{'kind':a['kind'],'area':int(round(a['area']))}) for g,a in park['park']])
gpw.add_layer(ck,'loading_zones','POLYGON',[('src','INTEGER'),('area','INTEGER'),('function','TEXT'),('danger','TEXT'),('isolation','TEXT')],[(g,{**a,'area':int(round(a['area']))}) for g,a in park['lz']])
# playgrounds with assessments (match by v8 playgrounds_zones order == playgrounds order?)
p2=gp.read(U+'5801ca10-playground_2.gpkg'); pg_assess={}
for i,j in f2b['pg_match'].items():
    r=p2[i]; fn=r['function']; fn='сопутствующая' if fn and fn.startswith('сопутствующая') else fn
    dg=r['danger']; dg={'благоприятные':'благоприятный','неблагоприятные':'неблагоприятный'}.get(dg,dg)
    pg_assess[j]={'function':fn,'danger':dg,'isolation':r['isolation']}
gt,f,rowsz=io9.load(A,'playgrounds_zones')
zfeats=[(tow(g),{**a,**pg_assess[j]}) for j,(g,a) in enumerate(rowsz)]
# same geometry in konkovo playgrounds: match by type+area
gt2,f2_,rows_p=io9.load(K,'playgrounds'); pf=[]
for g,a in rows_p:
    jj=[j for j,(gz,az) in enumerate(rowsz) if az['type']==a['type'] and abs(az['area']-a['area'])<=1]
    asm=pg_assess[jj[0]] if jj else {}
    pf.append((tow(g),{**a,**{k:asm.get(k) for k in ('function','danger','isolation')}}))
gpw.add_layer(ck,'playgrounds',gt2,f2_+[('function','TEXT'),('danger','TEXT'),('isolation','TEXT')],pf)
# business
bz=gp.read(U+'92246443-business_2.gpkg'); bf=[]
fin={x[0]:x for x in biz['final']}
for r in bz:
    fid,b,pos,d=fin[r['fid']]
    bf.append((('Point',(float(pos[0]),float(pos[1]))),{'bld_id':int(b),'adress':r['adress'],'Назначение':r['Назначение'],'Название':r['Название'],'placement':r['характер размещения'],'function':r['function'],'danger':r['danger'],'isolation':r['isolation']}))
gpw.add_layer(ck,'business','POINT',[('bld_id','INTEGER'),('adress','TEXT'),('Назначение','TEXT'),('Название','TEXT'),('placement','TEXT'),('function','TEXT'),('danger','TEXT'),('isolation','TEXT')],bf)
gpw.add_layer(ck,'osv_manual','POLYGON',[('kind','TEXT'),('comment','TEXT')],[(('Polygon',[man+[man[0]]]),{'kind':'неосвоенная','comment':'двор МИСИС за зданиями до спортплощадок; контур предварительный'})])
ck.close()
# ---------- analiz_v9
ca=gpw.create(OUT+'analiz_v9.gpkg')
for t in ['competition','control','control_zones','facades','heights','network','ped_exits','roads_tree','roads_tree_start','veh_exits']:
    gt,f,rows=io9.load(A,t); gpw.add_layer(ca,t,gt,f,[(tow(g),a) for g,a in rows])
gpw.add_layer(ca,'playgrounds_zones',gt,f,[]) if False else None
gt,f,_=io9.load(A,'playgrounds_zones'); gpw.add_layer(ca,'playgrounds_zones',gt,f+[('function','TEXT'),('danger','TEXT'),('isolation','TEXT')],zfeats)
# flows
ent=gp.read(U+'81ecacc9-entrances_points_1.gpkg'); fl=[]
tcmap={x[0]:x for x in tc}
for r,s in zip(ent,snap):
    tot=r['in_human']+r['out_human']; cl='высокий' if tot>=30 else ('средний' if tot>=10 else 'низкий')
    fl.append((('Point',(s[3][0],s[3][1])),{'id':r['fid'],'type':r['type'],'in_car':r['in_car'],'out_car':r['out_car'],'in_human':r['in_human'],'out_human':r['out_human'],'couriers':r['couriers'],
      'sat_human':tot,'mon_est':round(tot*2.5),'mon_low':round(tot*2.0),'mon_high':round(tot*3.0),'cls':cl,'snap_dist':round(s[0],1),'tree_ped':int(tcmap[r['fid']][1]),'tree_veh':int(tcmap[r['fid']][2])}))
gpw.add_layer(ca,'flows','POINT',[('id','INTEGER'),('type','TEXT'),('in_car','INTEGER'),('out_car','INTEGER'),('in_human','INTEGER'),('out_human','INTEGER'),('couriers','INTEGER'),('sat_human','INTEGER'),('mon_est','INTEGER'),('mon_low','INTEGER'),('mon_high','INTEGER'),('cls','TEXT'),('snap_dist','REAL'),('tree_ped','INTEGER'),('tree_veh','INTEGER')],fl)
# transit
net=io9.load(A,'network')[2]; tf=[]
for mode,load in (('пешеходный',tr['lp']),('транспортный',tr['lv'])):
    vals=np.array([sum(v) for v in load.values()]); thr=np.percentile(vals,75) if len(vals) else 0
    for eid,(a_,b_) in load.items():
        g,a=net[eid]; tot=a_+b_
        for l in gp.lines(g):
            tf.append((('LineString',np.asarray(l).tolist()),{'mode':mode,'type':a['type'],'to_metro':round(a_,1),'to_tc':round(b_,1),'load':round(tot,1),'cls':'высокая' if tot>=thr else 'низкая','length':round(a['length'],1)}))
gpw.add_layer(ca,'transit','LINESTRING',[('mode','TEXT'),('type','TEXT'),('to_metro','REAL'),('to_tc','REAL'),('load','REAL'),('cls','TEXT'),('length','REAL')],tf)
# parcels / osvoennost
def cls(p,tb=1.0,tu=1.0):
    if p['man']>=0.5 and not p['kind'].startswith('площадка'): return 'неосвоенная'
    b=p['B']>=tb; u=p['U']>=tu
    return 'освоенная' if b and u else ('частично освоенная' if b or u else 'неосвоенная')
pf=[]
for p in parcels:
    c=cls(p); pl=p['poly']
    for ring_set in pl:
        rings=[np.asarray(r) for r in ring_set] if isinstance(ring_set,(list,tuple)) and len(ring_set)>0 and not isinstance(ring_set[0],(float,int)) else None
        pf.append((('Polygon',[np.asarray(r).tolist() for r in rings]),{'kind':p['kind'],'area':round(p['area']),'cell':p['cell'],'cover':p['B_cover'],'green':p['B_green'],'relief':p['B_relief'],'light':None,'urns':None,'B':p['B'],'ped':p['ped'],'T':round(p['T'],1),'U':p['U'],'cls':c,'forced':'да' if (p['man']>=0.5 and not p['kind'].startswith('площадка')) else None}))
gpw.add_layer(ca,'osvoennost','POLYGON',[('kind','TEXT'),('area','INTEGER'),('cell','INTEGER'),('cover','INTEGER'),('green','INTEGER'),('relief','INTEGER'),('light','INTEGER'),('urns','INTEGER'),('B','REAL'),('ped','INTEGER'),('T','REAL'),('U','REAL'),('cls','TEXT'),('forced','TEXT')],pf)
print('parcel features',len(pf))
# cells summary
CLr=np.zeros(lab.shape,np.int16); cells=gp.read(K,'cells')
for r in cells:
    for p in gp.polys(r['_g']): W.fill(CLr,[np.array(p[0])],r['num'],holes=[np.array(h) for h in p[1:]])
rows=[]
for r in cells:
    n=r['num']; m=CLr==n; tot=m.sum()*R*R; ar={k:sum(p['area'] for p in parcels if p['cell']==n and cls(p)==k) for k in ('освоенная','частично освоенная','неосвоенная')}
    s=sum(ar.values()); dom=max(ar,key=ar.get) if s>0 else None
    rows.append((r,n,tot,ar,s,dom,float((lab[m]==3).sum()*R*R),float((lab[m]==4).sum()*R*R),float((lab[m]==1).sum()*R*R),float((lab[m]==5).sum()*R*R)))
cf=[]; gt_cells=io9.meta(K,'cells')[0]
for r,n,tot,ar,s,dom,pk,lz,bl,rd in rows:
    a={'num':n,'is_anal':r['is_anal'],'area':round(tot),'parcels_area':round(s),'osv_m2':round(ar['освоенная']),'part_m2':round(ar['частично освоенная']),'unosv_m2':round(ar['неосвоенная']),
       'osv_pct':round(100*ar['освоенная']/s,1) if s else None,'part_pct':round(100*ar['частично освоенная']/s,1) if s else None,'unosv_pct':round(100*ar['неосвоенная']/s,1) if s else None,'dominant':dom,'parking_m2':round(pk),'loading_m2':round(lz)}
    cf.append((tow(r['_g']),a))
gpw.add_layer(ca,'osv_cells',gt_cells,[('num','INTEGER'),('is_anal','INTEGER'),('area','INTEGER'),('parcels_area','INTEGER'),('osv_m2','INTEGER'),('part_m2','INTEGER'),('unosv_m2','INTEGER'),('osv_pct','REAL'),('part_pct','REAL'),('unosv_pct','REAL'),('dominant','TEXT'),('parking_m2','INTEGER'),('loading_m2','INTEGER')],cf)
ca.close()
pickle.dump({'cells':[(a,) for _,a in cf]},open(OUT+'cellrows.pkl','wb'))
