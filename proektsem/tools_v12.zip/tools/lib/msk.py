import math,numpy as np
W84=(6378137.0,1/298.257223563); BES=(6377397.155,1/299.1528128)
def _M(p,a,e2): return a*((1-e2/4-3*e2**2/64-5*e2**3/256)*p-(3*e2/8+3*e2**2/32+45*e2**3/1024)*np.sin(2*p)+(15*e2**2/256+45*e2**3/1024)*np.sin(4*p)-(35*e2**3/3072)*np.sin(6*p))
def tm_fwd(lon,lat,ell,lon0,lat0,k0,x0,y0):
    a,f=ell; e2=f*(2-f); ep2=e2/(1-e2); lon=np.radians(lon); lat=np.radians(lat); l0=math.radians(lon0)
    N=a/np.sqrt(1-e2*np.sin(lat)**2); T=np.tan(lat)**2; C=ep2*np.cos(lat)**2; A=(lon-l0)*np.cos(lat)
    x=k0*N*(A+(1-T+C)*A**3/6+(5-18*T+T**2+72*C-58*ep2)*A**5/120)+x0
    y=k0*(_M(lat,a,e2)-_M(math.radians(lat0),a,e2)+N*np.tan(lat)*(A**2/2+(5-T+9*C+4*C**2)*A**4/24+(61-58*T+T**2+600*C-330*ep2)*A**6/720))+y0
    return x,y
def tm_inv(x,y,ell,lon0,lat0,k0,x0,y0):
    a,f=ell; e2=f*(2-f); ep2=e2/(1-e2); x=np.asarray(x,float)-x0; y=np.asarray(y,float)-y0
    M1=_M(math.radians(lat0),a,e2)+y/k0; mu=M1/(a*(1-e2/4-3*e2**2/64-5*e2**3/256)); e1=(1-math.sqrt(1-e2))/(1+math.sqrt(1-e2))
    p1=mu+(3*e1/2-27*e1**3/32)*np.sin(2*mu)+(21*e1**2/16-55*e1**4/32)*np.sin(4*mu)+(151*e1**3/96)*np.sin(6*mu)+(1097*e1**4/512)*np.sin(8*mu)
    N1=a/np.sqrt(1-e2*np.sin(p1)**2); T1=np.tan(p1)**2; C1=ep2*np.cos(p1)**2; R1=a*(1-e2)/(1-e2*np.sin(p1)**2)**1.5; D=x/(N1*k0)
    lat=p1-(N1*np.tan(p1)/R1)*(D**2/2-(5+3*T1+10*C1-4*C1**2-9*ep2)*D**4/24+(61+90*T1+298*C1+45*T1**2-252*ep2-3*C1**2)*D**6/720)
    lon=math.radians(lon0)+(D-(1+2*T1+C1)*D**3/6+(5-2*C1+28*T1-3*C1**2+8*ep2+24*T1**2)*D**5/120)/np.cos(p1)
    return np.degrees(lon),np.degrees(lat)
def geod2ecef(lon,lat,h,ell):
    a,f=ell; e2=f*(2-f); lon=np.radians(lon); lat=np.radians(lat); N=a/np.sqrt(1-e2*np.sin(lat)**2)
    return np.array([(N+h)*np.cos(lat)*np.cos(lon),(N+h)*np.cos(lat)*np.sin(lon),(N*(1-e2)+h)*np.sin(lat)])
def ecef2geod(X,ell):
    a,f=ell; e2=f*(2-f); x,y,z=X; lon=np.arctan2(y,x); p=np.hypot(x,y); lat=np.arctan2(z,p*(1-e2))
    for _ in range(8):
        N=a/np.sqrt(1-e2*np.sin(lat)**2); h=p/np.cos(lat)-N; lat=np.arctan2(z,p*(1-e2*N/(N+h)))
    return np.degrees(lon),np.degrees(lat),h
def helmert(X,p,inverse=False):
    tx,ty,tz,rx,ry,rz,s=p; rx,ry,rz=[math.radians(v/3600) for v in (rx,ry,rz)]; m=1+s*1e-6
    R=np.array([[1,-rz,ry],[rz,1,-rx],[-ry,rx,1]]); T=np.array([tx,ty,tz])[:,None]
    if not inverse: return T+m*(R@X)
    return np.linalg.solve(m*R,X-T)
TOW=(316.151,78.924,589.65,-1.57273,2.69209,2.34693,8.4507)
def utm2msk(e,n,h=180.0):
    lon,lat=tm_inv(e,n,W84,39.0,0.0,0.9996,500000,0)
    X=geod2ecef(lon,lat,np.full_like(np.asarray(lon,float),h),W84); Xb=helmert(X,TOW,inverse=True)
    lo,la,_=ecef2geod(Xb,BES); return tm_fwd(lo,la,BES,37.5,55.66666666667,1.0,0,0)
def msk2utm(x,y,h=180.0):
    lo,la=tm_inv(x,y,BES,37.5,55.66666666667,1.0,0,0)
    X=geod2ecef(lo,la,np.full_like(np.asarray(lo,float),h),BES); Xw=helmert(X,TOW)
    lon,lat,_=ecef2geod(Xw,W84); return tm_fwd(lon,lat,W84,39.0,0.0,0.9996,500000,0)
def utm37(lon,lat): return tm_fwd(np.asarray(lon,float),np.asarray(lat,float),W84,39.0,0.0,0.9996,500000,0)
def utm2ll(e,n): return tm_inv(e,n,W84,39.0,0.0,0.9996,500000,0)
