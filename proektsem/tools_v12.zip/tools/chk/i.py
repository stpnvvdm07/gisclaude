import sys; sys.path.insert(0,'lib')
import gp, numpy as np
from scipy.stats import spearmanr
V='/mnt/user-data/uploads/proektsem/vector/'
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
ent=gp.read(U+'81ecacc9-entrances_points_1.gpkg'); net=gp.read(V+'analiz_v8.gpkg','network'); et=gp.read(V+'konkovo_v8.gpkg','entries_territory')
E=np.array([r['_g'][1] for r in et])
segs=[(np.array(l[0]),np.array(l[-1]),r) for r in net for l in gp.lines(r['_g'])]
def dseg(P,A,B):
    d=B-A;L=d@d+1e-9;t=np.clip(((P-A)@d)/L,0,1);return np.hypot(*(P-(A+t*d)))
rows=[]
for r in ent:
    P=np.array(r['_g'][1]); de=np.hypot(*(E-P).T); j=de.argmin()
    near=[(dseg(P,A,B),s) for A,B,s in segs]; near=[x for x in near if x[0]<=8]
    ped=max([s['ped'] or 0 for d,s in near],default=0); veh=max([s['veh'] or 0 for d,s in near],default=0)
    rows.append((r['fid'],round(float(de[j]),1),et[j]['podtip'],ped,veh,r['in_human']+r['out_human'],r['in_car']+r['out_car'],r['couriers'],r['type']))
    print(rows[-1])
a=np.array([[x[3],x[4],x[5],x[6]] for x in rows],float)
print('spearman ped-tree vs human flow',spearmanr(a[:,0],a[:,2]))
print('spearman veh-tree vs car flow',spearmanr(a[:,1],a[:,3]))
print('sum human',a[:,2].sum(),'car',a[:,3].sum(),'entries without counts',(a[:,2]==0).sum())
