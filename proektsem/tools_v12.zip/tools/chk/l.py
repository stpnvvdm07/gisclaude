import sys; sys.path.insert(0,'lib')
import dxf, gp, xf, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf',layers={'AVTOSTOYANKI','ZDANIYA','PROEZDY','ULICY_PROEZZH_CHAST','СТАДИОНЫ_СПОРТКОМПЛЕКСЫ','OGRAZHDENIYA'})
V='/mnt/user-data/uploads/proektsem/vector/'
fig,ax=plt.subplots(figsize=(16,13))
col={'AVTOSTOYANKI':'#2a9d8f','ZDANIYA':'#a39279','PROEZDY':'#777','ULICY_PROEZZH_CHAST':'#333','СТАДИОНЫ_СПОРТКОМПЛЕКСЫ':'#d9c35b','OGRAZHDENIYA':'#b13840'}
for e in E:
    P=np.array(e['pts'])
    if len(P)<2: continue
    U=np.array(xf.cad2utm(P)); ax.plot(U[:,0],U[:,1],c=col[e['layer']],lw=1.2 if e['layer']=='AVTOSTOYANKI' else .5)
for r in gp.read(V+'konkovo_v8.gpkg','parking'):
    for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc='#2a9d8f',alpha=.25,ec='none'))
ax.set_aspect('equal'); ax.autoscale(); plt.savefig('chk/park_dxf.png',dpi=100,bbox_inches='tight')
