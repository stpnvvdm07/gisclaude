import sys,pickle;sys.path.insert(0,'lib')
import gp,io9,numpy as np
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
bnd=io9.load(K,'boundary')[2][0][0]
ring=np.array(gp.polys(bnd)[0][0]); print('ring pts',len(ring), 'holes',len(gp.polys(bnd)[0])-1)
net=io9.load(A,'network')[2]
def segint(p,q,a,b):
    r=q-p;s=b-a;d=r[0]*s[1]-r[1]*s[0]
    if abs(d)<1e-12:return None
    w=a-p
    t=(w[0]*s[1]-w[1]*s[0])/d
    u=(w[0]*r[1]-w[1]*r[0])/d
    if 0<=t<=1 and 0<=u<=1:return p+t*r
X=[]
for i,(g,a) in enumerate(net):
    for l in gp.lines(g):
        l=np.array(l)
        for j in range(len(l)-1):
            for k in range(len(ring)-1):
                x=segint(l[j],l[j+1],ring[k],ring[k+1])
                if x is not None:X.append((x,i,a['type'],a['ped'],a.get('veh') if 'veh' in a else None))
print(len(X))
ent=io9.load(K,'entries_territory')[2]
EP=np.array([g[1] for g,a in ent])
# merge crossings by 3 m
M=[]
for x,i,t,p,v in X:
    for m in M:
        if np.hypot(*(m[0]-x))<3: m[1].append((i,t));break
    else:M.append([x,[(i,t)]])
print('merged crossings',len(M))
d=[np.hypot(*(EP-m[0]).T).min() for m in M]
print('crossing->nearest entry dist',np.round(sorted(d),1))
d2=[]
for e in EP:
    dist=np.hypot(*(np.array([m[0] for m in M])-e).T).min() if M else -1; 
    # dist to ring
    dr=min(np.abs(((ring[k+1]-ring[k])[0]*(e-ring[k])[1]-(ring[k+1]-ring[k])[1]*(e-ring[k])[0]))/np.hypot(*(ring[k+1]-ring[k])) if 0<=np.dot(e-ring[k],ring[k+1]-ring[k])/np.dot(ring[k+1]-ring[k],ring[k+1]-ring[k])<=1 else 1e9 for k in range(len(ring)-1))
    d2.append((round(dist,1),round(dr,1)))
print('entry->nearest crossing, dist to boundary',d2)
pickle.dump((M,ring),open('out9/ent_cross.pkl','wb'))
