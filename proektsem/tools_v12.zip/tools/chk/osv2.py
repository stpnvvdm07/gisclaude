import sys,pickle,collections,cv2; sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
O='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
lab=np.load('out9/lab.npy'); w=pickle.load(open('out9/win.pkl','rb')); R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R)
W.h,W.w=lab.shape
# rasters
cells=io9.load(K,'cells')[2]; CL=np.zeros(lab.shape,np.int16)
for g,a in cells:
    for p in gp.polys(g): W.fill(CL,[np.array(p[0])],a['num'],holes=[np.array(h) for h in p[1:]])
net=io9.load(A,'network')[2]
PD=np.zeros(lab.shape,np.uint8)
for g,a in sorted(net,key=lambda x:(x[1]['ped'] or 0)):
    for l in gp.lines(g): W.line(PD,np.array(l),6.0,val=min((a['ped'] or 0)+1,60))
pol=gp.read(O+'proektbase/polyefull.gpkg')
SL=W.blank()
for r in pol:
    if r['object'] in ('Откос','Подпорная стенка') and r['_g'] and r['_g'][0]=='Point':
        x,y=r['_g'][1]; px=((x-W.x0)/R,(y-W.y0)/R); cv2.circle(SL,(int(px[0]),int(px[1])),int(3/R),1,-1)
wat=gp.read('/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/basemap/Moscow_water.gpkg')
LK=W.blank()
for r in wat:
    g=r['_g']
    if g is None: continue
    for p in gp.polys(g):
        a=np.array(p[0])
        if 407700<a[:,0].mean()<408000 and 6167150<a[:,1].mean()<6167350: W.fill(LK,[a],1)
LK=cv2.dilate(LK,np.ones((int(2*60/R)|1,)*2,np.uint8)) if LK.any() else LK
MAN=W.blank(); man=[(407385,6167552),(407462,6167702),(407585,6167628),(407562,6167521),(407430,6167530)]
W.fill(MAN,[np.array(man+[man[0]],float)],1)
# transit load raster
tr=pickle.load(open('out9/transit.pkl','rb')); lp=tr['lp']
TL=np.zeros(lab.shape,np.float32)
for eid,(a_,b_) in sorted(lp.items(),key=lambda kv:sum(kv[1])):
    g=net[eid][0]
    for l in gp.lines(g): cv2.polylines(TL,[np.round(W.px(np.array(l))*16).astype(np.int32)],False,float(a_+b_),thickness=int(2*10/R),lineType=cv2.LINE_8,shift=4)
# flows
ent=gp.read(U+'81ecacc9-entrances_points_1.gpkg'); EP=np.array([r['_g'][1] for r in ent]); EF=np.array([r['in_human']+r['out_human'] for r in ent],float)
pickle.dump({'man':man},open('out9/man.pkl','wb'))
parcels=[]
for cls,name in ((6,'деревья'),(7,'трава'),(8,'прочее')):
    n,cc,stats,cent=cv2.connectedComponentsWithStats((lab==cls).astype(np.uint8),connectivity=4)
    for i in range(1,n):
        x,y,wd,ht,ar=stats[i]
        if ar*R*R<20: continue
        m0=max(0,y-2);m1=min(lab.shape[0],y+ht+2);n0=max(0,x-2);n1=min(lab.shape[1],x+wd+2)
        sub=(cc[m0:m1,n0:n1]==i).astype(np.uint8)
        sw=rb.Win(W.x0+n0*R,W.y0+m0*R,W.x0+n1*R,W.y0+m1*R,R)
        pl=sw.polys(sub,eps=0.15,minarea=20)
        if not pl: continue
        cl=CL[m0:m1,n0:n1][sub>0]; cell=int(np.bincount(cl).argmax()) if cl.size else 0
        dil=cv2.dilate(sub,np.ones((7,7),np.uint8))
        touch=bool((lab[m0:m1,n0:n1][dil>0]==5).any())
        ped=int(PD[m0:m1,n0:n1][sub>0].max()); ped=max(ped-1,0) if ped>0 else 0
        slope=bool(SL[m0:m1,n0:n1][sub>0].any()); lake=bool(LK[m0:m1,n0:n1][sub>0].any())
        man_f=MAN[m0:m1,n0:n1][sub>0].mean()
        c=np.array([W.x0+cent[i][0]*R,W.y0+cent[i][1]*R])
        parcels.append(dict(kind=name,poly=pl,area=ar*R*R,cell=cell,touch=touch,ped=ped,slope=slope,lake=lake,man=float(man_f),cen=c,T=float(TL[m0:m1,n0:n1][sub>0].max()))) 
print('parcels',len(parcels),collections.Counter(p['kind'] for p in parcels))
# playgrounds as parcels
pg=io9.load(A,'playgrounds_zones')[2]
for g,a in pg:
    ps=gp.polys(g); c=np.vstack([np.array(p[0]) for p in ps]).mean(0)
    m=W.blank()
    for p in ps: W.fill(m,[np.array(p[0])],1)
    ys,xs=np.nonzero(m); 
    if len(ys)==0: continue
    ped=int(PD[ys,xs].max()); ped=max(ped-1,0) if ped>0 else 0
    cl=CL[ys,xs]; cell=int(np.bincount(cl).argmax())
    parcels.append(dict(kind='площадка:'+a['type'],poly=[[np.array(r) for r in p] for p in ps],area=len(ys)*R*R,cell=cell,touch=True,ped=ped,slope=bool(SL[ys,xs].any()),lake=bool(LK[ys,xs].any()),man=float(MAN[ys,xs].mean()),cen=c,T=float(TL[ys,xs].max())))
# scoring
Ecap=None
def Ecount(c): return float((EF*np.exp(-np.hypot(*(EP-c).T)/120)).sum())
E=np.array([Ecount(p['cen']) for p in parcels]); Ecap=np.percentile(E,75)
Tcap=np.percentile([p['T'] for p in parcels if p['T']>0],75)
print('Tcap',round(Tcap,1))
for p,e in zip(parcels,E):
    p['E']=e
    k=p['kind']
    # благоустроенность: критерии 0-2
    cover=2 if k.startswith('площадка') else (1 if (p['touch'] or k=='прочее') else 0)
    green=2 if k in('деревья',) else (1 if k=='трава' else (2 if k.startswith('площадка') else 0))
    relief=0 if p['slope'] else 2
    p['B_cover'],p['B_green'],p['B_relief']=cover,green,relief
    p['B']=round((cover+green+relief)/3,2)       # 0..2
    u=0.4*min(p['ped']/5,1)+0.3*min(e/Ecap,1)+0.3*min(p['T']/Tcap,1)
    u=2*u+(0.5 if p['lake'] else 0)
    p['U']=round(min(u,2),2)
pickle.dump(parcels,open('out9/parcels.pkl','wb'))
Bs=np.array([p['B'] for p in parcels]);Us=np.array([p['U'] for p in parcels])
print('B quantiles',np.percentile(Bs,[10,25,50,75,90]).round(2),'U quantiles',np.percentile(Us,[10,25,50,75,90]).round(2),'Ecap',round(Ecap,1))
