import sys,pickle,collections,cv2; sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
V='/mnt/user-data/uploads/proektsem/vector/'
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
d=pickle.load(open('out9/park.pkl','rb'))
bnd=[g for g,_ in io9.load(K,'boundary')[2]][0]
bpts=np.vstack([np.array(p[0]) for p in gp.polys(bnd)]); x0,y0=bpts.min(0)-10; x1,y1=bpts.max(0)+10
W=rb.Win(x0,y0,x1,y1,0.2)
lab=W.blank()
def fillg(g,val,holes=True):
    for p in (gp.polys(g) if g[0] in('Polygon','MultiPolygon') and not isinstance(g[1][0][0],float) and False else []): pass
def fillgp(g,val):
    if g[0]=='Polygon': pl=[g[1]]
    else: pl=g[1]
    for rings in pl:
        W.fill(lab,[np.array(rings[0])],val,holes=[np.array(h) for h in rings[1:]])
fillgp_gp=lambda g,val:[W.fill(lab,[np.array(p[0])],val,holes=[np.array(h) for h in p[1:]]) for p in gp.polys(g)]
fillgp_gp(bnd,8)
for g,a in io9.load(K,'green')[2]: fillgp_gp(g,7 if a['type']=='трава' else 6)
wat=gp.read('/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/basemap/Moscow_water.gpkg')
for r in wat:
    g=r['_g']
    if g is None: continue
    for p in gp.polys(g):
        a=np.array(p[0])
        if 407700<a[:,0].mean()<408000 and 6167150<a[:,1].mean()<6167350: W.fill(lab,[a],9)
HW={'проезд':1.9,'тротуар':0.9,'дорожка':0.65,'тропа':0.5,'лестница':0.8,'переход':1.5}
net=io9.load(A,'network')[2]
CM=W.blank()
for g,a in net:
    for l in gp.lines(g): W.line(CM,np.array(l),HW[a['type']])
m=(CM>0)&(lab>0); lab[m]=5
for g,a in io9.load(K,'parking')[2]:
    if a['kind']!='здание-паркинг (многоуровневый)': fillgp_gp(g,3)
for g,a in io9.load(K,'loading_zones')[2]: fillgp_gp(g,4)
for g,a in io9.load(K,'playgrounds')[2]: fillgp_gp(g,2)
for g,a in io9.load(K,'buildings')[2]: fillgp_gp(g,1)
inside=W.blank(); fillgp_gp(bnd,1) if False else None
for p in gp.polys(bnd): W.fill(inside,[np.array(p[0])],1)
lab[inside==0]=0
cnt=collections.Counter(lab.ravel().tolist()); 
names={0:'вне',1:'здания',2:'площадки',3:'парковки',4:'загрузка',5:'проезды/дорожки',6:'деревья',7:'трава',8:'прочее',9:'вода'}
tot=sum(v for k,v in cnt.items() if k)*0.04
for k in sorted(cnt): print(names[k],round(cnt[k]*0.04),round(100*cnt[k]*0.04/tot,1) if k else '')
np.save('out10/lab.npy',lab); pickle.dump({'x0':x0,'y0':y0,'res':0.2},open('out10/win.pkl','wb'))
