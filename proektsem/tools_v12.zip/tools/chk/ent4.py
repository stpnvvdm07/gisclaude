import sys,pickle,cv2;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
d=pickle.load(open('out9/ent3.pkl','rb'));U=d['U'];x0,y0,x1,y1,R=d['win'];W=rb.Win(x0,y0,x1,y1,R)
DT=cv2.distanceTransform(U,cv2.DIST_L2,5)*R
net=io9.load(A,'network')[2]
def depth(p): 
    px=np.round(W.px([p])[0]).astype(int);return DT[px[1],px[0]]
# per crossing: maximum inside-depth reached by incident network edges within 15 m path
res=[]
for j,m in enumerate(d['M']):
    best=0;tp=set()
    for (i,t) in m['n']:
        tp.add(t)
        for l in gp.lines(net[i][0]):
            l=np.array(l)
            L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))]
            s=np.arange(0,L[-1],0.5);P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])]
            dd=np.hypot(*(P-m['p']).T)
            if dd.min()>2: continue
            for q in P[dd<20]: best=max(best,depth(q))
    res.append((j,round(float(best),1),sorted(tp),m['near']))
    print(j,np.round(m['p']),round(float(best),1),sorted(tp),m['near'])
