import sys; sys.path.insert(0,'lib')
import gp, collections
V='/mnt/user-data/uploads/proektsem/vector/'
n=gp.read(V+'analiz_v8.gpkg','network')
print(collections.Counter(r['type'] for r in n)); 
import numpy as np
for t in set(r['type'] for r in n): print(t,round(sum(r['length'] for r in n if r['type']==t)))
print(gp.layers(V+'konkovo_v8.gpkg'),gp.layers(V+'analiz_v8.gpkg'))
print(open(V+'README_v8.txt').read())
