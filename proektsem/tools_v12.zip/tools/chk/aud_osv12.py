import sys,glob,pickle;sys.path.insert(0,'lib')
exec(open('chk/prev11.py').read().split("fig,ax=")[0])
exec(open('chk/osv12rule.py').read())
P=pickle.load(open('out12/parcels12.pkl','rb'))
fig,ax=plt.subplots(figsize=(18,10))
polys(ax,gp.read(K,'cells'),'#fff',ec='#999',lw=.5,z=1)
cm={'освоенная':'#5ec46e','частично освоенная':'#e6d27a','неосвоенная':'#b13840','полоса':'#dddddd'}
for p in P:
    c=cm[cls12(p)]
    for rings in p['poly']:
        V=[];C=[]
        for ring in rings:
            ring=T(ring);V+=list(ring)+[ring[0]];C+=[MPath.MOVETO]+[MPath.LINETO]*(len(ring)-1)+[MPath.CLOSEPOLY]
        ax.add_patch(PathPatch(MPath(V,C),fc=c,ec='none',zorder=2))
polys(ax,gp.read(K,'buildings'),'#7a6a55',z=3)
polys(ax,gp.read(K,'people_dens'),'none',ec='#1040ff',lw=2,z=5)
polys(ax,gp.read(K,'osv_manual'),'none',ec='k',lw=2,z=5)
for r in gp.read(K,'cells'):
    c=T(np.array(gp.polys(r['_g'])[0][0]).mean(0));ax.text(*c,str(r['num']),fontsize=9,color='#333',zorder=8)
ax.set_aspect('equal');ax.autoscale();ax.axis('off')
plt.savefig('chk/aud_osv12.png',dpi=60,bbox_inches='tight')
