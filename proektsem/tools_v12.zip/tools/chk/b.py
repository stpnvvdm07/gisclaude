import sys; sys.path.insert(0,'lib')
import gp
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
for r in gp.read(U+'c21fbc75-buildings_2.gpkg'): print({k:v for k,v in r.items() if k!='_g'}, r['_g'][0])
print()
for r in gp.read(U+'92246443-business_2.gpkg'): print(r['fid'],r['_g'][1],[r[k] for k in ('adress','Назначение','Название','характер размещения','function','danger','isolation')])
print()
for r in gp.read(U+'fc0568b7-competitions_2.gpkg'): print(r['fid'],round(r['area'],1),r['function'],r['danger'],r['isolation'])
print()
for r in gp.read(U+'5801ca10-playground_2.gpkg'): print(r['fid'],r['type'],r['area'],r['zone'],r['control'],r['problem'],r['function'],r['danger'],r['isolation'])
