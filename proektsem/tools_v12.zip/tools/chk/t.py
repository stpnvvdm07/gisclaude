import sys; sys.path.insert(0,'lib')
import dxf,gp,xf,numpy as np,collections
E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf',layers={'ТРОПЫ','DOR_TROPA_GRUNT','ZEL_GAZON_LUG','ZEL_LES_DREVESNYE','БЕГОВЫЕ_ДОРОЖКИ','ВЕЛОПЕШЕХОДНЫЕ','ПЕШЕХОДНЫЕ_ЗОНЫ','ЛЕСТНИЦЫ','DOR_LESTNICA'})
for L in sorted({e['layer'] for e in E}):
    es=[e for e in E if e['layer']==L]; tl=0
    for e in es:
        P=np.array(e['pts']); 
        if len(P)>1: tl+=np.hypot(*np.diff(P,axis=0).T).sum()
    print(L,len(es),'total length',round(tl),'closed',sum(1 for e in es if e.get('closed')))
V='/mnt/user-data/uploads/proektsem/vector/'
O='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/proektbase/'
for n in ('polyefull.gpkg','slopesandwalls.gpkg','roads_countsss.gpkg'):
    rs=gp.read(O+n); print(n,len(rs),{k:v for k,v in rs[0].items() if k!='_g'},rs[0]['_g'][0])
rs=gp.read(O+'polyefull.gpkg')
import rb
for r in rs[:15]: print({k:v for k,v in r.items() if k!='_g'}, round(sum(abs(rb.ringarea(p[0])) for p in gp.polys(r['_g']))))
