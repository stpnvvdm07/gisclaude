import sys,pickle,cv2;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
cells=[g for g,a in io9.load(K,'cells')[2]]+[g for g,a in io9.load(K,'cells_excluded')[2]]
allp=np.vstack([np.array(p[0]) for g in cells for p in gp.polys(g)])
x0,y0=allp.min(0)-40;x1,y1=allp.max(0)+40;R=0.25
W=rb.Win(x0,y0,x1,y1,R);U=W.blank()
for g in cells:
    for p in gp.polys(g): W.fill(U,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
U=cv2.morphologyEx(U,cv2.MORPH_CLOSE,np.ones((9,9),np.uint8))
print('cells union area',U.sum()*R*R)
net=io9.load(A,'network')[2]
pts=[]
for i,(g,a) in enumerate(net):
    for l in gp.lines(g):
        l=np.array(l)
        L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))]
        s=np.arange(0,L[-1],0.25)
        if len(s)<2: continue
        P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])]
        px=np.round(W.px(P)).astype(int)
        ins=U[px[:,1].clip(0,W.h-1),px[:,0].clip(0,W.w-1)]>0
        for k in np.nonzero(ins[1:]!=ins[:-1])[0]:
            T=(P[k+1]-P[k]);T/=np.hypot(*T)+1e-9
            pts.append((P[k],i,a['type'],bool(ins[k]),T))
print('raw crossings',len(pts))
M=[]
for p,i,t,inn,T in pts:
    for m in M:
        if np.hypot(*(m['p']-p))<6: m['n'].append((i,t));break
    else:M.append({'p':p.copy(),'n':[(i,t)],'T':T})
print('clusters',len(M))
ent=io9.load(K,'entries_territory')[2]; EP=np.array([g[1] for g,a in ent])
for j,m in enumerate(M):
    d=np.hypot(*(EP-m['p']).T); k=d.argmin()
    m['near']=(int(k),round(float(d[k]),1))
pickle.dump({'M':M,'U':U,'win':(x0,y0,x1,y1,R)},open('out9/ent3.pkl','wb'))
d=[m['near'][1] for m in M];print('crossing->nearest entry: >20m:',sum(x>20 for x in d),'of',len(M))
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(22,18))
ax.imshow(U,extent=(x0,x1,y0,y1),origin='lower',cmap='Greys',alpha=.2)
for g,a in net:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='#c80' if a['type']=='проезд' else '#06c',lw=.6)
for j,m in enumerate(M): 
    c='r' if m['near'][1]>20 else 'g'; ax.plot(*m['p'],'o',c=c,ms=7); ax.text(m['p'][0]+3,m['p'][1]+3,f"c{j}",fontsize=8,color=c)
ax.plot(EP[:,0],EP[:,1],'k+',ms=9)
for i,e in enumerate(EP): ax.text(e[0]-12,e[1]-9,str(i),fontsize=8)
ax.set_aspect('equal');ax.set_xlim(407200,408230);ax.set_ylim(6166900,6167750)
plt.savefig('chk/ent_cross.png',dpi=60,bbox_inches='tight')
