import sys,pickle,collections,itertools;sys.path.insert(0,'lib')
import numpy as np
d=pickle.load(open('out10/viol.pkl','rb'));V=d['V']
V[20]['iso_koef']=0.3499  # хранится округлённым 0.35, но класс в cells = «Низкий» (значение чуть ниже порога 0.35)
BASE=dict(comfort_cut=0.67,ent_non=1,loading_m2=50,wear_n=1,danger_obj=1,combined_m=20,transit_res_m=20,biz_transit=1,pg_out=1,comp_m2=50,unc_pct=50,unos_pct=25,
          vl=0.6,vh=1.4,vu=2.0,il=0.35,ih=0.65,size_T=None)
ITEMS=['1а','1б','1в','1г','2а','2б','2в','3а','3б','3в','3г']
NAMES={'1а':'размеры / пропорции / фиксация границ ячейки','1б':'не организованные входы','1в':'вне зафиксированных границ','1г':'износ зданий ≥40 %','2а':'зоны загрузки','2б':'опасные открытые объекты',
 '2в':'совмещение транзитных потоков на проездах','3а':'транзит через придомовые территории','3б':'обслуживающие объекты с внешним транзитом','3в':'места поведения вне контроля','3г':'конкуренция / неконтролируемые / заброшенные'}
def comfort(v,T):
    k=v['vert_koef'];s=0
    vv=0 if (k is None or k<T['vl'] or k>=T['vu']) else (2 if k>=T['vh'] else 1)
    i=v['iso_koef'];ii=0 if i<T['il'] else (2 if i>=T['ih'] else 1)
    if T['size_T'] is None: pl=2 if v['planning']=='Комфортная' else 0
    else: pl=2 if v['size']<=T['size_T'] else 0
    return (vv+ii+pl)/6,(vv,ii,pl)
def flags(n,T):
    v=V[n];sc,(vv,ii,pl)=comfort(v,T);f={}
    f['1а']=sc<T['comfort_cut']-0.005
    f['1б']=v['ent_non']>=T['ent_non']
    f['1в']=not v['is_anal']
    f['1г']=v['wear40']>=T['wear_n']
    f['2а']=v['loading_m2']>=T['loading_m2']
    f['2б']=v['danger_obj']>=T['danger_obj']
    f['2в']=v['combined_m']>=T['combined_m']
    f['3а']=v['pod']>0 and v['transit_res_m']>=T['transit_res_m']
    f['3б']=v['biz_transit']>=T['biz_transit']
    f['3в']=v['pg_out']>=T['pg_out']
    f['3г']=(v['competition_m2']>=T['comp_m2']) or (v['unc_pct']>=T['unc_pct']) or ((v['unosv_pct'] or 0)>=T['unos_pct'])
    return f,sc
scope=[n for n in V if V[n]['is_anal'] or V[n]['pod']>0]
print('scope',len(scope),'of',len(V))
def table(T):
    rows={}
    for n in scope:
        f,sc=flags(n,T);rows[n]=(sum(f.values()),f,sc)
    return rows
base=table(BASE)
sc=sorted(r[0] for r in base.values());print('score dist',collections.Counter(sc))
cls=lambda s:'высокая' if s>=6 else ('средняя' if s>=4 else 'низкая')
print(collections.Counter(cls(r[0]) for r in base.values()))
print({it:sum(r[1][it] for r in base.values()) for it in ITEMS})
# чувствительность счёта
sens=[]
def run(name,T):
    t=table(T);s={n:t[n][0] for n in scope}
    hi=sum(1 for x in s.values() if cls(x)=='высокая');flip=sum(1 for n in scope if cls(s[n])!=cls(base[n][0]))
    from scipy.stats import spearmanr
    rho=spearmanr([base[n][0] for n in scope],[s[n] for n in scope])[0]
    comf=sum(1 for n in scope if t[n][2]>=T['comfort_cut']-0.005)
    sens.append((name,T,sum(s.values()),hi,flip,round(float(rho),3),comf))
run('базовые пороги',BASE)
for k,vals in [('comfort_cut',[0.5,0.83]),('loading_m2',[25,100]),('combined_m',[10,40]),('transit_res_m',[10,40]),('comp_m2',[25,100]),('unc_pct',[30,70]),('unos_pct',[10,50]),('ent_non',[2]),('wear_n',[2]),('biz_transit',[2]),
               ('vl',[0.5,0.7]),('vh',[1.2,1.6]),('vu',[1.8,2.2]),('il',[0.30,0.40]),('ih',[0.60,0.70]),('size_T',[130,140,150])]:
    for x in vals:
        T=dict(BASE);T[k]=x;run(f'{k} = {x}',T)
for r in sens: print(r[0],r[2:])
pickle.dump(dict(BASE=BASE,base=base,scope=scope,sens=sens,ITEMS=ITEMS,NAMES=NAMES),open('out10/viol2.pkl','wb'))
