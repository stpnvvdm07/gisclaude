# -*- coding: utf-8 -*-
import sqlite3, os, re
SP='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/'
F={'K':SP+'out10/konkovo_v10.gpkg','A':SP+'out10/analiz_v10.gpkg','P':SP+'out11/problems_v11.gpkg'}
def q(f,sql):
    c=sqlite3.connect("file:%s?immutable=1"%F[f],uri=True); return c.execute(sql).fetchall()
def n(f,sql): return q(f,sql)[0][0]
tpl=open(SP+'chk/prelude.py',encoding='utf-8').read()

# --- общие наборы слоёв (src, layer, legend title, style-code, subset)
def L(src,name,title,style,sub=None): return '    (%r, %r, %r, %s, %r),'%(src,name,title,style,sub)
WATER=L('BM','Moscow_water','Вода','single(fill(C["water"]))')
ROADS=L('BM','Moscow_roads','Дороги (OSM)','single(line(C["white"], 0.6))')
BLDM=L('BM','Moscow_building','Застройка вне территории','single(fill(C["beige"]))')
BASE=[WATER,BLDM,ROADS]
GRN=L('K','green','Озеленение','GREEN')
BLD=L('K','buildings','Здания','BLD')
CELLS=L('K','cells','Границы ячеек','CELL_LINES')
CELLS_LAB=L('K','cells','Номера ячеек','combo(CELL_LINES, labels("num", 8))')
BND=L('K','boundary','Граница территории','BND')
def cellsby(field,title): return L('K','cells',title,'cells_by("%s")'%field)
def pt(col,size=2.2,shape='circle',out='C["black"]'): return 'mark(C["%s"], %s, "%s", %s)'%(col,size,shape,out)
TOP_LAB=lambda extra='': L('K','cells','Номера ячеек (анализ)','combo(single(fill(C["white"],0,C["black"],0.3)), labels("num", 8))')

maps=[]
def add(num,slug,title,sub,note,layers,slide):
    maps.append(dict(num=num,slug=slug,title=title,sub=sub,note=note,layers=layers,slide=slide))

n_cells=n('K','select count(*) from cells'); n_an=n('K','select count(*) from cells where is_anal=1')
n_scope=n('P','select count(*) from viol_cells where in_scope=1')
add('01','ситуационный_план','Ситуационный план','Положение территории в городе: вода, дороги, застройка',
 'Территория: Коньково №2. Контур разбит на %d ячеек; в границы анализа входят %d, с учётом ячеек, куда выходят подъезды, — %d.'%(n_cells,n_an,n_scope),
 BASE+[GRN,BLD,BND,CELLS_LAB],'Территория и постановка задачи')
add('02','застройка_и_барьеры','Застройка, ограждения и рельеф','Здания по типу, ограждения, откосы и подпорные стенки, арки',
 'Здания: %d; ограждений: %d (решётчатых высоких %d). Арки: %d. Откосы и стенки — барьеры для пешеходной связности.'%(n('K','select count(*) from buildings'),n('K','select count(*) from fences'),n('K',"select count(*) from fences where podtip like '%решётчатое'"),n('K','select count(*) from arches')),
 BASE+[GRN,
  L('K','buildings','Здания по типу','cats(\'coalesce("Тип здания",\\\'без данных\\\')\', [("Жилое", fill(C["brown"]), "жилое"), ("Нежилое", fill(C["teal"]), "нежилое"), ("Смешанное", fill(C["lavender"]), "смешанное"), ("Не определено", fill(C["grey"],150), "не определено")], (fill(C["beige"], 255, C["brown"], 0.2), "без данных"))'),
  L('S','slopesandwalls','Откосы и подпорные стенки','cats(\'"object"\', [("Откос", line(C["orange"],0.7,"dash"), "откос"), ("Подпорная стенка", line(C["dark"],1.0), "подпорная стенка")])'),
  L('K','fences','Ограждения','cats(\'"podtip"\', [("Ограждение — высокое решётчатое", line(C["purple"],0.6), "высокое решётчатое"), ("Ограждение — высокое сплошное", line(C["black"],0.9), "высокое сплошное"), ("Ограждение — низкое", line(C["blue"],0.5,"dash"), "низкое")])'),
  L('K','arches','Арки','single(line(C["pink"],1.4))'), L('K','gates','Ворота и калитки','single(%s)'%pt('yellow',2.2,'square')),
  BND],'Территория и постановка задачи')
add('03','входы_на_территорию','Входы на территорию и узлы входов','Входы по типу, узлы по фиксации (организован / не организован)',
 'Входов: %d (организованных %d, не организованных %d). Узлов входа: %d (не организованных %d). Организованный вход — арка, ворота, калитка, въезд; не организованный — разрыв, не зафиксирован.'%(n('K','select count(*) from entries_territory'),n('K',"select count(*) from entries_territory where fix_class='организован'"),n('K',"select count(*) from entries_territory where fix_class='не организован'"),n('K','select count(*) from entry_nodes'),n('K',"select count(*) from entry_nodes where fix_class='не организован'")),
 BASE+[GRN,BLD,CELLS,
  L('K','entries_territory','Входы по типу','cats(\'"podtip"\', [("Вход — въезд", %s, "въезд"), ("Вход — арка", %s, "арка"), ("Вход — калитка", %s, "калитка"), ("Вход — ворота", %s, "ворота"), ("Вход — разрыв в застройке", %s, "разрыв в застройке"), ("Вход — разрыв в насаждениях", %s, "разрыв в насаждениях"), ("Вход — не зафиксирован", %s, "не зафиксирован")])'%tuple(pt(c,2.4,s) for c,s in [('blue','square'),('pink','circle'),('green','circle'),('teal','square'),('red','triangle'),('orange','triangle'),('grey','diamond')])),
  L('K','entry_nodes','Узлы входа','cats(\'"fix_class"\', [("организован", ring(C["green"],4.2,0.7), "узел организован"), ("не организован", ring(C["red"],4.2,0.9), "узел не организован")])'),
  L('K','entry_candidates','Кандидаты на вход (не принятые)','single(%s)'%pt('white',2.4,'cross','C["red"]')),BND],'Границы, входы, ячейки')
add('04','границы_анализа','Границы анализа и ячейки','Ячейки в анализе, вне зафиксированных границ, исключённые',
 'Ячеек всего %d; is_anal=1: %d; ещё %d включены, так как к ним обращены подъезды домов. Прочие ячейки — вне зафиксированных границ (нарушение 1.1.в).'%(n_cells,n_an,n_scope-n_an),
 BASE+[BLD,L('K','cells_excluded','Исключённые участки','single(hatch(C["grey"],150))'),
  L('K','cells','Ячейки','cats(\'CASE WHEN "is_anal"=1 THEN \\\'в анализе\\\' ELSE \\\'вне границ\\\' END\', [("в анализе", fill(C["green"],140,C["black"],0.3), "в анализе"), ("вне границ", fill(C["beige"],220,C["black"],0.3), "вне зафиксированных границ")])'),
  L('P','viol_cells','Ячейки, включённые из-за подъездов','single(hatch(C["orange"],200))','"in_scope"=1 AND "is_anal"=0'),
  L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 8))'),BND],'Границы, входы, ячейки')
add('05','вертикальный_каркас','Комфортность: вертикальные пропорции','Вертикальный коэффициент ячейки (отношение высоты застройки к ширине)',
 'Пороги коэффициента: 0,6 и 1,4 / 2,0. Низкий <0,6 или ≥2,0; средний 0,6–1,4; высокий 1,4–2,0. Ячеек: низкий %d, средний %d, высокий %d.'%tuple(n('K',"select count(*) from cells where vertical='%s'"%v) for v in ('Низкий','Средний','Высокий')),
 BASE+[cellsby('vertical','Вертикальные пропорции'),BLD,L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0.3)), labels("num", 8))')],'Комфортность ячеек')
add('06','изолированность','Комфортность: изолированность','Степень замкнутости ячейки (iso_koef: 0,35 / 0,65)',
 'Ячеек: низкая изолированность %d, средняя %d, высокая %d.'%tuple(n('K',"select count(*) from cells where isolation='%s'"%v) for v in ('Низкий','Средний','Высокий')),
 BASE+[cellsby('isolation','Изолированность'),BLD,L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0.3)), labels("num", 8))')],'Комфортность ячеек')
add('07','планировочные_размеры','Комфортность: планировочные размеры','Планировочный критерий по таблице команды (размер ячейки)',
 'Планировочный критерий: комфортных %d, некомфортных %d. Критерий воспроизведён по таблице; чисто функциональной зависимости не имеет.'%(n('K',"select count(*) from cells where planning='Комфортная'"),n('K',"select count(*) from cells where planning='Некомфортная'")),
 BASE+[L('K','cells','Планировочные размеры','cells_comf("planning")'),BLD,L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0.3)), labels("num", 8))')],'Комфортность ячеек')
add('08','комфортность_итог','Комфортность ячеек: итог','Итоговый балл = (вертикаль + изолированность + планировка) / 6; комфортна при балле ≥ 0,67',
 'Комфортных ячеек в базе: %d из %d ячеек анализа. Балл показан на ячейке (номер / балл).'%(n('P',"select count(*) from viol_cells where in_scope=1 and trim(comfort)='Комфортная'"),n_scope),
 BASE+[L('K','cells','Комфортность','cells_comf("comfort")'),BLD,L('K','cells','Номер и балл','combo(single(fill(C["white"],0,C["black"],0.3)), labels("num||\\\' / \\\'||round(\\"score\\",2)", 7, expr=True))')],'Комфортность ячеек')
add('09','износ_зданий','Износ зданий','Степень изношенности: указана в данных или оценка команды',
 'Критерий 1.1.г: износ ≥40 %%. Зданий с износом ≥40 %%: %d (данные %d, оценка команды %d).'%(n('P','select count(*) from p1g_wear'),n('P',"select count(*) from p1g_wear where src='указан'"),n('P',"select count(*) from p1g_wear where src='оценка команды'")),
 BASE+[GRN,L('K','buildings','Износ','cats(WEAR, [("40% и более", fill(C["red"]), "40 % и более"), ("менее 40%", fill(C["green_m"]), "менее 40 %"), ("нет данных", fill(C["beige"],255,C["brown"],0.2), "нет данных")])'),CELLS,BND],'Здания: износ и функции')
add('10','функции_и_размещение','Обслуживающие объекты и размещение','Здания по типу, объекты бизнеса по размещению',
 'Объектов бизнеса %d: встроенных %d, встроенно-пристроенных %d, отдельно стоящих %d.'%(n('K','select count(*) from business'),n('K',"select count(*) from business where placement='встроенный'"),n('K',"select count(*) from business where placement='встроенно-пристроенный'"),n('K',"select count(*) from business where placement='отдельно стоящий'")),
 BASE+[GRN,L('K','buildings','Здания по типу','cats(\'coalesce("Тип здания",\\\'без данных\\\')\', [("Жилое", fill(C["brown"]), "жилое"), ("Нежилое", fill(C["teal"]), "нежилое"), ("Смешанное", fill(C["lavender"]), "смешанное")], (fill(C["beige"],255,C["brown"],0.2), "без данных"))'),
  CELLS,L('K','business','Бизнес по размещению','cats(\'"placement"\', [("встроенный", %s, "встроенный"), ("встроенно-пристроенный", %s, "встроенно-пристроенный"), ("отдельно стоящий", %s, "отдельно стоящий")])'%tuple(pt(c,2.4,s) for c,s in [('blue','circle'),('yellow','square'),('red','diamond')])),BND],'Здания: износ и функции')
add('11','опасные_объекты','Опасные и благоприятные объекты','Объекты по признаку danger: опасный, индифферентный, благоприятный',
 'В счёт 2.1.б вошло %d опасных открытых объектов (из них %d — мусорные точки, приравненные к опасным по допущению). Зон загрузки %d (учтены отдельно, 2.1.а). Благоприятные закрытые объекты — предпосылки, не нарушения.'%(n('P','select count(*) from p2b_objects'),n('K','select count(*) from garbage'),n('K','select count(*) from loading_zones')),
 BASE+[GRN,BLD,CELLS,L('K','loading_zones','Зоны загрузки (опасные)','single(fill(C["purple"],200))'),
  L('K','playgrounds','Площадки','cats(\'"danger"\', [("благоприятный", fill(C["green"],200), "благоприятная"), ("опасный", fill(C["red"],220), "опасная")])'),
  L('K','business','Бизнес по danger','cats(\'"danger"\', [("опасный", %s, "опасный"), ("индифферентный", %s, "индифферентный"), ("благоприятный", %s, "благоприятный")])'%tuple(pt(c,2.4) for c in ('red','yellow','green'))),
  L('K','garbage','Мусорные точки','single(%s)'%pt('dark',2.2,'square')),BND],'Опасные и благоприятные объекты')
add('12','парковки_и_загрузка','Парковки и зоны загрузки','Парковки по виду, зоны загрузки',
 'Парковок: %d (открытых %d), зон загрузки: %d, общая площадь зон загрузки %d м².'%(n('K','select count(*) from parking'),n('K',"select count(*) from parking where kind='открытая'"),n('K','select count(*) from loading_zones'),n('K','select round(sum(area)) from loading_zones')),
 BASE+[GRN,BLD,CELLS,L('K','parking','Парковки','cats(\'"kind"\', [("открытая", fill(C["blue"],200), "открытая"), ("гаражи", fill(C["lavender"],200), "гаражи"), ("открытая (вокруг здания-паркинга)", fill(C["teal"],200), "вокруг здания-паркинга"), ("здание-паркинг (многоуровневый)", fill(C["purple"],200), "здание-паркинг")])'),
  L('K','loading_zones','Зоны загрузки','single(fill(C["orange"],220,C["dark"],0.3))'),BND],'Опасные и благоприятные объекты')
add('13','пешеходная_сеть','Пешеходная сеть: загруженность','Группы сети по загруженности (дерево путей от входов)',
 'Группы: высокая загруженность, низкая, один путь. Загруженность — по числу путей, проходящих по участку.',
 BASE+[GRN,BLD,CELLS,L('A','network','Пешеходная сеть','cats(\'"group"\', [("высокая", line(C["red"],1.6), "высокая"), ("низкая", line(C["blue"],0.9), "низкая"), ("один путь", line(C["grey"],0.5,"dash"), "один путь")])','"group" IS NOT NULL'),BND],'Сети, потоки, совмещение')
add('14','транспортная_сеть','Транспортная сеть: загруженность','Группы сети по загруженности транспортом',
 'Группы: высокая, низкая, один путь. Проезды — основа для анализа совмещения потоков.',
 BASE+[GRN,BLD,CELLS,L('A','network','Транспортная сеть','cats(\'"vgroup"\', [("высокая", line(C["red"],1.8), "высокая"), ("низкая", line(C["orange"],1.0), "низкая"), ("один путь", line(C["grey"],0.5,"dash"), "один путь")])','"vgroup" IS NOT NULL'),BND],'Сети, потоки, совмещение')
add('15','совмещение_потоков','Совмещение пешеходных и транспортных потоков','Раздельность движения: по проезжей части / по тротуару / отдельно от проезда',
 'Участки пешеходных путей по проезжей части: %d; совмещение транзитных потоков (2.1.в) — %d участков, %d м.'%(n('A',"select count(*) from network where razdel='по проезжей части'"),n('P','select count(*) from p2c_combined'),n('P','select round(sum(length)) from p2c_combined')),
 BASE+[GRN,BLD,CELLS,L('A','network','Раздельность','cats(\'"razdel"\', [("отдельно от проезда", line(C["green"],0.9), "отдельно от проезда"), ("по тротуару", line(C["blue"],0.9), "по тротуару"), ("по проезжей части", line(C["red"],1.2), "по проезжей части")])','"razdel" IS NOT NULL'),
  L('P','p2c_combined','Совмещение транзитных потоков','single(line(C["orange"],2.6))'),BND],'Сети, потоки, совмещение')
CZ=lambda t,s: L('A','control_zones',t,'cats(\'"type"\', [%s])'%s)
add('16','контроль_жилой','Зоны контроля: жилые здания','Активный (АЖ) и пассивный (ПЖ) контроль со стороны жилых зданий',
 'Зон АЖ: %d, ПЖ: %d (типы зон — по полю type в analiz_v10).'%(n('A',"select count(*) from control_zones where type='АЖ'"),n('A',"select count(*) from control_zones where type='ПЖ'")),
 BASE+[GRN,L('A','control_zones','Контроль жилых','cats(\'"type"\', [("АЖ", fill(C["green"],150), "АЖ — активный, жилой"), ("ПЖ", fill(C["green_m"],110), "ПЖ — пассивный, жилой")])','"type" IN (\'АЖ\',\'ПЖ\')'),BLD,BND],'Контроль и освоенность')
add('17','контроль_нежилой','Зоны контроля: нежилые объекты','Активный (АП) и пассивный (ПП) контроль со стороны нежилых объектов',
 'Зон АП: %d, ПП: %d.'%(n('A',"select count(*) from control_zones where type='АП'"),n('A',"select count(*) from control_zones where type='ПП'")),
 BASE+[GRN,L('A','control_zones','Контроль нежилых','cats(\'"type"\', [("АП", fill(C["purple"],150), "АП — активный, нежилой"), ("ПП", fill(C["lavender"],110), "ПП — пассивный, нежилой")])','"type" IN (\'АП\',\'ПП\')'),BLD,BND],'Контроль и освоенность')
add('18','контролируемость','Контролируемость территории и конкуренция','Контролируемая, частично контролируемая, неконтролируемая; конкуренция контролей',
 'Полигонов: контролируемых %d, частично %d, неконтролируемых %d; зон конкуренции %d (%d м²).'%(n('A',"select count(*) from control where type='контролируемая'"),n('A',"select count(*) from control where type='частично контролируемая'"),n('A',"select count(*) from control where type='неконтролируемая'"),n('A','select count(*) from competition'),n('A','select round(sum(area)) from competition')),
 BASE+[GRN,L('A','control','Контролируемость','cats(\'"type"\', [("контролируемая", fill(C["green"],170), "контролируемая"), ("частично контролируемая", fill(C["yellow"],150), "частично контролируемая"), ("неконтролируемая", fill(C["red"],170), "неконтролируемая")])'),
  L('A','competition','Конкуренция контролей','single(fill(C["pink"],200,C["black"],0.3))'),BLD,BND],'Контроль и освоенность')
add('19','детские_площадки','Детские площадки и зоны контроля','Ближняя и средняя зоны, конфликт, контроль',
 'Площадок %d; в неконтролируемой зоне %d; площадка с проблемой «ближняя зона вне активного контроля» — %d.'%(n('A','select count(*) from playgrounds_zones'),n('A',"select count(*) from playgrounds_zones where control='неконтролируемая'"),n('A',"select count(*) from playgrounds_zones where problem is not null")),
 BASE+[GRN,BLD,L('A','playgrounds_zones','Площадки по зоне','cats(\'"zone"\', [("ближняя", fill(C["green"],200,C["black"],0.4), "ближняя зона"), ("средняя", fill(C["yellow"],200,C["black"],0.4), "средняя зона")])'),
  L('A','playgrounds_zones','Площадка с проблемой','single(fill(C["red"],230,C["black"],0.8))','"problem" IS NOT NULL'),BND],'Контроль и освоенность')
add('20','потоки_людей','Потоки людей и машин','Точки учёта потоков; подпись — число людей в субботу',
 'Точек учёта: %d. Классы: низкий %d, средний %d, высокий %d. Понедельник — оценка (mon_est), не наблюдение.'%(n('A','select count(*) from flows'),n('A',"select count(*) from flows where cls='низкий'"),n('A',"select count(*) from flows where cls='средний'"),n('A',"select count(*) from flows where cls='высокий'")),
 BASE+[GRN,BLD,CELLS,L('A','flows','Потоки (класс)','combo(cats(\'"cls"\', [("высокий", mark(C["red"],5,"circle",C["black"]), "высокий"), ("средний", mark(C["yellow"],3.8,"circle",C["black"]), "средний"), ("низкий", mark(C["green"],2.6,"circle",C["black"]), "низкий")]), labels("sat_human", 7))'),BND],'Сети, потоки, совмещение')
add('21','транзит','Транзитные потоки','Транзит к метро и ТЦ: пешеходный и транспортный, по загрузке',
 'Участков транзита %d: пешеходных %d, транспортных %d; высокая загрузка %d.'%(n('A','select count(*) from transit'),n('A',"select count(*) from transit where mode='пешеходный'"),n('A',"select count(*) from transit where mode='транспортный'"),n('A',"select count(*) from transit where cls='высокая'")),
 BASE+[GRN,BLD,CELLS,L('A','transit','Транзит','cats(\'"mode"||\\\' / \\\'||"cls"\', [("пешеходный / высокая", line(C["red"],1.8), "пешеходный, высокая"), ("пешеходный / низкая", line(C["orange"],0.8), "пешеходный, низкая"), ("транспортный / высокая", line(C["purple"],1.8,"dash"), "транспортный, высокая"), ("транспортный / низкая", line(C["blue"],0.8,"dash"), "транспортный, низкая")])'),BND],'Транзит')
add('22','освоенность','Освоенность территории','Классы освоенности участков, ручные поправки, плотность людей',
 'Участков %d: освоенных %d, частично %d, неосвоенных %d. Контур «неосвоенная» нарисован вручную; полигоны «много/мало людей» — наблюдения команды.'%(n('A','select count(*) from osvoennost'),n('A',"select count(*) from osvoennost where cls='освоенная'"),n('A',"select count(*) from osvoennost where cls='частично освоенная'"),n('A',"select count(*) from osvoennost where cls='неосвоенная'")),
 BASE+[L('A','osvoennost','Освоенность','cats(\'"cls"\', [("освоенная", fill(C["green"],190), "освоенная"), ("частично освоенная", fill(C["yellow"],170), "частично освоенная"), ("неосвоенная", fill(C["red"],190), "неосвоенная")])'),
  L('K','people_dens','Плотность людей','cats(\'"dens"\', [("много", fill(C["blue"],0,C["blue"],1.4,"dash"), "много людей"), ("мало", fill(C["pink"],0,C["pink"],1.4,"dash"), "мало людей")])'),
  L('K','osv_manual','Контур неосвоенной (вручную)','single(fill(C["red"],0,C["red"],1.6))'),BLD,CELLS,BND],'Контроль и освоенность')
add('23','контроль_и_неосвоенность','Контроль × освоенность','Неосвоенные участки поверх контролируемых зон',
 'Сопоставление: неосвоенные и неконтролируемые участки — основа критерия 3.4. Предпосылка: освоенные контролируемые участки (зелёная заливка).',
 BASE+[L('P','pre_osv_ctl','Освоенное и контролируемое (предпосылка)','single(fill(C["green"],150))'),
  L('A','control','Неконтролируемая территория','single(fill(C["red"],0,C["red"],1.0,"dash"))','"type"=\'неконтролируемая\''),
  L('A','osvoennost','Неосвоенная территория','single(fill(C["red"],170))','"cls"=\'неосвоенная\''),
  L('A','competition','Конкуренция контролей','single(fill(C["pink"],200))'),BLD,BND],'Контроль и освоенность')
V=lambda col,t: L('P','viol_cells',t,'single(hatch(C["%s"],120))'%col,'"%s"=1')
cell_bg=L('P','viol_cells','Ячейки анализа','single(fill(C["cream"],255,C["grey"],0.3))','"in_scope"=1')
add('24','проблемы_группа_1','Проблемы 1: границы, входы, износ','Занятие 4, п. 1.1.а–г',
 'Ячеек с нарушением 1.1.а: %d; 1.1.в (вне границ): %d; не организованных узлов входа: %d; зданий с износом ≥40 %%: %d.'%(n('P','select count(*) from viol_cells where v1а=1'),n('P','select count(*) from viol_cells where v1в=1'),n('P','select count(*) from p1b_entry_nodes'),n('P','select count(*) from p1g_wear')),
 BASE+[cell_bg,L('P','viol_cells','1.1.в вне границ','single(hatch(C["grey"],200))','"v1в"=1'),L('P','viol_cells','1.1.а размеры/пропорции','single(fill(C["lavender"],110))','"v1а"=1'),BLD,
  L('P','p1g_wear','1.1.г износ ≥40 %','single(fill(C["dark"]))'),L('P','p1g_wear_border','1.1.г износ ≥40 % (на границе ячеек)','single(fill(C["dark"],255,C["red"],0.8))'),
  L('P','p1b_entry_nodes','1.1.б не организованный узел входа','single(%s)'%pt('red',4,'triangle')),L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 8))'),BND],'Проблемы: группа 1')
add('25','проблемы_группа_2','Проблемы 2: загрузка, опасные объекты, совмещение','Занятие 4, п. 2.1.а–в',
 'Ячеек с зоной загрузки: %d; опасных открытых объектов: %d; участков совмещения транзитных потоков: %d (%d м).'%(n('P','select count(*) from viol_cells where v2а=1'),n('P','select count(*) from p2b_objects'),n('P','select count(*) from p2c_combined'),n('P','select round(sum(length)) from p2c_combined')),
 BASE+[cell_bg,L('K','loading_zones','2.1.а зона загрузки','single(fill(C["purple"],220))'),BLD,L('P','p2c_combined','2.1.в совмещение потоков','single(line(C["orange"],2.8))'),
  L('P','p2b_objects','2.1.б опасный открытый объект','single(%s)'%pt('red',4,'cross')),L('P','pre_fav_closed','Благоприятный закрытый (предпосылка)','single(%s)'%pt('green',3,'circle')),
  L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 8))'),BND],'Проблемы: группа 2')
add('26','проблемы_группа_3','Проблемы 3: транзит, обслуживание, вне контроля, конкуренция','Занятие 4, п. 3.1.а–г',
 'Участков транзита через жилые территории: %d; обслуживающих объектов с внешним транзитом: %d; площадка вне контроля: %d; конкуренция контролей: %d м².'%(n('P','select count(*) from p3a_transit_res'),n('P','select count(*) from p3b_biz'),n('P','select count(*) from p3v_playgrounds'),n('A','select round(sum(area)) from competition')),
 BASE+[cell_bg,L('A','competition','3.1.г конкуренция контролей','single(fill(C["pink"],200))'),L('A','osvoennost','3.1.г неосвоенная территория','single(fill(C["red"],150))','"cls"=\'неосвоенная\''),BLD,
  L('P','p3a_transit_res','3.1.а транзит через жилые территории','single(line(C["red"],1.8,"dash"))'),L('P','p3v_playgrounds','3.1.в место вне контроля','single(fill(C["yellow"],230,C["black"],1.0))'),
  L('P','p3b_biz','3.1.б обслуживающий объект с внешним транзитом','single(ring(C["blue"],4.4,0.9))'),L('K','cells','Номера','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 8))'),BND],'Проблемы: группа 3')
cl=[n('P',"select count(*) from viol_cells where cls='%s'"%c) for c in ('низкая','средняя','высокая')]
top=q('P','select num,score from viol_cells where in_scope=1 order by score desc, num limit 6')
add('27','сводный_счёт','Сводный счёт нарушений по ячейкам','Число нарушений из 11 критериев на ячейку; подпись: номер / счёт',
 'Классы: 0–3 низкая (%d), 4–5 средняя (%d), ≥6 высокая (%d). Наибольший счёт: %s.'%(cl[0],cl[1],cl[2],', '.join('№%d — %d'%t for t in top)),
 BASE+[L('P','viol_cells','Счёт нарушений','cats(\'CASE WHEN "in_scope"=0 THEN \\\'вне анализа\\\' ELSE "cls" END\', [("высокая", fill(C["red"],210), "высокий (≥6)"), ("средняя", fill(C["yellow"],200), "средний (4–5)"), ("низкая", fill(C["green"],190), "низкий (0–3)"), ("вне анализа", fill(C["beige"],200), "вне анализа")])'),
  BLD,L('P','viol_cells','Номер / счёт','combo(single(fill(C["white"],0,C["black"],0.3)), labels("CASE WHEN \\"in_scope\\"=1 THEN \\"num\\"||\\\' / \\\'||\\"score\\" END", 8, expr=True))'),BND],'Сводный счёт и чувствительность')
add('28','финальная_схема_проблем','Финальная схема проблем','Все группы нарушений занятия 4 и предпосылки на одной карте',
 'Сводная схема: слои групп 1–3 и предпосылки (организованные входы, освоенные и контролируемые участки, благоприятные закрытые объекты).',
 BASE+[L('P','viol_cells','Ячейки анализа','single(fill(C["cream"],255,C["grey"],0.3))','"in_scope"=1'),
  L('P','pre_osv_ctl','Предпосылка: освоенное и контролируемое','single(fill(C["green"],115))'),
  L('P','viol_cells','1.1.в вне границ','single(hatch(C["grey"],200))','"v1в"=1'),L('P','viol_cells','1.1.а размеры/пропорции','single(fill(C["lavender"],90))','"v1а"=1'),
  L('A','osvoennost','3.1.г неосвоенная территория','single(fill(C["red"],120))','"cls"=\'неосвоенная\''),L('A','competition','3.1.г конкуренция контролей','single(fill(C["pink"],200))'),
  L('K','loading_zones','2.1.а зона загрузки','single(fill(C["purple"],220))'),BLD,L('P','p1g_wear','1.1.г износ ≥40 %','single(fill(C["dark"]))'),L('P','p3v_playgrounds','3.1.в место вне контроля','single(fill(C["yellow"],230,C["black"],1.0))'),
  L('P','p2c_combined','2.1.в совмещение потоков','single(line(C["orange"],2.8))'),L('P','p3a_transit_res','3.1.а транзит через жилые территории','single(line(C["red"],1.8,"dash"))'),
  L('P','p3b_biz','3.1.б обслуживающий объект с внешним транзитом','single(ring(C["blue"],4.4,0.9))'),L('P','p2b_objects','2.1.б опасный открытый объект','single(%s)'%pt('red',4,'cross')),
  L('P','pre_entry_nodes','Предпосылка: организованный вход','single(%s)'%pt('green',3.4,'triangle')),L('P','p1b_entry_nodes','1.1.б не организованный узел входа','single(%s)'%pt('red',4,'triangle')),
  L('P','viol_cells','Номера','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 8))','"in_scope"=1'),BND],'Итог: финальная схема проблем')

out=SP+'maps/'; os.makedirs(out,exist_ok=True)
for f in os.listdir(out):
    if f.endswith('.py'): os.remove(out+f)
def esc(s): return s.replace('\\','\\\\').replace('"','\\"')
for m in maps:
    s=tpl
    for k,v in (('@@NUM@@',m['num']),('@@TITLE@@',esc(m['title'])),('@@SUBTITLE@@',esc(m['sub'])),('@@SCALE@@','3000'),('@@NOTE@@',m['note'].replace('"""',"'''"))):
        s=s.replace(k,v)
    s=s.replace('@@LAYERS@@','\n'.join(m['layers']))
    open(out+'%s_%s.py'%(m['num'],m['slug']),'w',encoding='utf-8').write(s)
import json; json.dump(maps,open(SP+'maps_meta.json','w'),ensure_ascii=False,indent=1)
print(len(maps),'скриптов')
