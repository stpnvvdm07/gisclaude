import sys,pickle,cv2;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
d=pickle.load(open('out9/ent3.pkl','rb'));U=d['U'];x0,y0,x1,y1,R=d['win'];W=rb.Win(x0,y0,x1,y1,R)
DT=cv2.distanceTransform(U,cv2.DIST_L2,5)*R
def fillg(t,m,filt=None):
    for g,a in io9.load(K,t)[2]:
        if filt and not filt(a):continue
        for p in gp.polys(g): W.fill(m,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
Bm=W.blank();fillg('buildings',Bm)
Tm=W.blank();fillg('green',Tm,lambda a:a['type']=='деревья')
Fm=W.blank()
for g,a in io9.load(K,'fences')[2]:
    if a['podtip'] and 'низкое' in a['podtip']:continue
    for l in gp.lines(g): W.line(Fm,np.array(l),0.3)
Am=W.blank()
for g,a in io9.load(K,'arches')[2]:
    for l in gp.lines(g): W.line(Am,np.array(l),0.5)
net=io9.load(A,'network')[2]
segs=[]
for i,(g,a) in enumerate(net):
    for l in gp.lines(g):
        l=np.array(l)
        for j in range(len(l)-1):segs.append((l[j],l[j+1],i))
S0=np.array([s[0] for s in segs]);S1=np.array([s[1] for s in segs]);SI=np.array([s[2] for s in segs])
def nearest(p):
    v=S1-S0;L2=(v**2).sum(1)+1e-12;t=np.clip(((p-S0)*v).sum(1)/L2,0,1);Q=S0+t[:,None]*v;dd=np.hypot(*(Q-p).T);k=dd.argmin()
    return Q[k],dd[k],v[k]/np.sqrt(L2[k]),SI[k]
gates=np.array([g[1] for g,a in io9.load(K,'gates')[2]])
fenc=[np.array(l) for g,a in io9.load(K,'fences')[2] for l in gp.lines(g)]
arch=[np.array(l) for g,a in io9.load(K,'arches')[2] for l in gp.lines(g)]
def dl(p,lines):
    best=1e9
    for l in lines:
        v=l[1:]-l[:-1];L2=(v**2).sum(1)+1e-12;t=np.clip(((p-l[:-1])*v).sum(1)/L2,0,1);Q=l[:-1]+t[:,None]*v;best=min(best,np.hypot(*(Q-p).T).min())
    return best
def ray(m,p,n,mx=60):
    for r in np.arange(0.5,mx,0.25):
        q=p+n*r;px=np.round(W.px([q])[0]).astype(int)
        if 0<=px[1]<W.h and 0<=px[0]<W.w and m[px[1],px[0]]:return r
    return np.inf
ent=io9.load(K,'entries_territory')[2]
rows=[]
for i,(g,a) in enumerate(ent):
    p=np.array(g[1]);q,dn,t,ei=nearest(p);n=np.array([-t[1],t[0]])
    f={'i':i,'podtip':a['podtip'].replace('Вход — ',''),'comment':a['comment'],'d_net':dn,'net_type':net[ei][1]['type'],
       'depth':DT[int(round(W.px([p])[0][1])).__index__() if False else min(max(int(round((p[1]-y0)/R)),0),W.h-1),min(max(int(round((p[0]-x0)/R)),0),W.w-1)],
       'd_gate':np.hypot(*(gates-p).T).min(),'d_fence':dl(p,fenc),'d_arch':dl(p,arch)}
    for nm,m in (('B',Bm),('T',Tm),('F',Fm)):
        a1=ray(m,q,n);a2=ray(m,q,-n);f['L'+nm]=a1;f['R'+nm]=a2
    rows.append(f)
pickle.dump(rows,open('out9/ent5.pkl','wb'))
for f in rows:
    print(f"{f['i']:2d} {f['podtip'][:12]:12s} net={f['net_type'][:6]:6s} dn={f['d_net']:4.1f} depth={f['depth']:5.1f} gate={f['d_gate']:5.1f} fence={f['d_fence']:5.1f} arch={f['d_arch']:5.1f} B={f['LB']:5.1f}/{f['RB']:5.1f} T={f['LT']:5.1f}/{f['RT']:5.1f} F={f['LF']:5.1f}/{f['RF']:5.1f}  {f['comment']}")
