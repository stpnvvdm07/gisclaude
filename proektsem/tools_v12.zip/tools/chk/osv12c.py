import sys,pickle,collections,cv2;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
O='in/proektsem/vector/proektbase/'
P=pickle.load(open('out12/parcels12.pkl','rb'))
lab=np.load('out10/lab.npy');w=pickle.load(open('out10/win.pkl','rb'));R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R);W.h,W.w=lab.shape
SL=W.blank();n=collections.Counter()
for r in gp.read(O+'polyefull.gpkg'):
    if r['object'] in ('Откос','Подпорная стенка') and r['_g']:
        g=r['_g'];n[g[0]]+=1
        if g[0]=='Point':
            x,y=g[1];cv2.circle(SL,(int((x-W.x0)/R),int((y-W.y0)/R)),int(6/R),1,-1)
        else:
            for l in gp.lines(g): W.line(SL,np.array(l),6.0)
for r in gp.read(O+'slopesandwalls.gpkg'):
    for l in gp.lines(r['_g']): W.line(SL,np.array(l),6.0);n['sw']+=1
print(n)
pickle.dump(SL,open('out12/slope6.pkl','wb'))
for p in P:
    allr=np.vstack([np.array(r) for rings in p['poly'] for r in rings[:1]])
    x0,y0=allr.min(0)-1;x1,y1=allr.max(0)+1;sw=rb.Win(x0,y0,x1,y1,R);m=sw.blank()
    for rings in p['poly']: sw.fill(m,[np.array(rings[0])],1,holes=[np.array(h) for h in rings[1:]])
    i0=int(round((x0-W.x0)/R));j0=int(round((y0-W.y0)/R));sub=SL[j0:j0+m.shape[0],i0:i0+m.shape[1]]
    p['slope_sh']=float((sub[m>0]>0).sum())/max(int(m.sum()),1) if sub.shape==m.shape else 0.0
    p['slope']=p['slope_sh']>=0.3
pickle.dump(P,open('out12/parcels12.pkl','wb'))
print('slope parcels',sum(p['slope'] for p in P),round(sum(p['area'] for p in P if p['slope'])))
