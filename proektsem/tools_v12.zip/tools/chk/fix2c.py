import sys,pickle; sys.path.insert(0,'lib')
exec(open('chk/fix2.py').read().split('# ---- business: shift')[0].split("bgt,bf,bld")[0])
import gp,io9,rb,numpy as np,msk
bgt,bf,bld=io9.load(K,'buildings')
v8=gp.read(K,'buildings'); bz=gp.read(U+'92246443-business_2.gpkg')
rings=[np.array(p[0]) for r in v8 for p in gp.polys(r['_g'])]
rid=[r['id'] for r in v8 for p in gp.polys(r['_g'])]
A_=np.vstack([r[:-1] for r in rings]);B_=np.vstack([r[1:] for r in rings])
SID=np.concatenate([[rid[i]]*(len(rings[i])-1) for i in range(len(rings))])
def nearest(P):
    d=B_-A_;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A_)*d).sum(1)/L,0,1);Q=A_+d*t[:,None];D=np.hypot(*(P-Q).T);j=D.argmin();return D[j],SID[j]
P0=np.array([[float(x) for x in msk.utm37(np.array(r['_g'][1][0]),np.array(r['_g'][1][1]))] for r in bz])
grp=[('Профсоюзная' if r['adress'].startswith('Проф') else 'Миклухо' if r['adress'].startswith('Мик') else 'Введ') for r in bz]
for gname in ('Профсоюзная','Миклухо'):
    idx=[i for i,g in enumerate(grp) if g==gname]
    best=None
    for dx in np.arange(-15,15.01,0.5):
      for dy in np.arange(-15,15.01,0.5):
        c=sum(min(nearest(P0[i]+[dx,dy])[0],6) for i in idx)
        if best is None or c<best[0]: best=(c,dx,dy)
    print(gname,len(idx),'best shift',best[1],best[2],'robust mean',round(best[0]/len(idx),2),'| residual list',[round(nearest(P0[i]+[best[1],best[2]])[0],1) for i in idx])
