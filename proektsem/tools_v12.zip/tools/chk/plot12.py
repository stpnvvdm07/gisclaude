import sys,glob;sys.path.insert(0,'lib')
import gp,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
import matplotlib.patches as mp
from matplotlib.lines import Line2D
from matplotlib import font_manager as fm
for f in glob.glob('/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/*SF-Pro*.otf'): fm.fontManager.addfont(f)
plt.rcParams['font.family']='SF Pro Display'
plt.rcParams['hatch.linewidth']=0.6
K='out12/konkovo_v12.gpkg';A='out12/analiz_v12.gpkg';P='out12/problems_v12.gpkg';S='in/proektsem/vector/proektbase/slopesandwalls.gpkg'
ROT=26.75;a=np.radians(ROT);Rm=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
C0=np.array([407724.5,6167314.9])
T=lambda p:(np.asarray(p,float)-C0)@Rm.T
COL=dict(water='#5bbccf',green_l='#dde9d0',green_m='#8ed0ad',cream='#f7f0e6',beige='#e1d8c7',brown='#a39279',red='#b13840',purple='#6852a0',yellow='#d9c35b',
         orange='#e08a2b',blue='#4a74c9',lavender='#a68cc6',grey='#333338',pink='#c978d3',dark='#5a3d2b',green='#5ec46e',bld='#d3cabd',line='#9a948a')
def path_of(geom):
    V=[];Cd=[]
    for p in gp.polys(geom):
        for ring in p:
            ring=T(ring);V+=list(ring)+[ring[0]];Cd+=[MPath.MOVETO]+[MPath.LINETO]*(len(ring)-1)+[MPath.CLOSEPOLY]
    return MPath(V,Cd) if V else None
def polys(ax,rows,fc='none',ec='none',al=1,lw=.3,z=1,hatch=None,ls='-'):
    for r in rows:
        pth=path_of(r['_g'])
        if pth is None: continue
        if hatch: ax.add_patch(PathPatch(pth,fc='none',ec=ec,lw=0,hatch=hatch,alpha=al,zorder=z))
        else: ax.add_patch(PathPatch(pth,fc=fc,ec=ec,alpha=al,lw=lw,zorder=z,ls=ls))
def outline(ax,rows,ec,lw,z,ls='-',al=1):
    for r in rows:
        pth=path_of(r['_g'])
        if pth: ax.add_patch(PathPatch(pth,fc='none',ec=ec,lw=lw,ls=ls,zorder=z,alpha=al,joinstyle='round'))
def lines(ax,rows,c,lw,z,ls='-',al=1):
    for r in rows:
        for l in gp.lines(r['_g']): q=T(l);ax.plot(*q.T,c=c,lw=lw,zorder=z,ls=ls,alpha=al,solid_capstyle='round',dash_capstyle='round')
def pts(ax,rows,**k):
    if not rows: return
    q=T([r['_g'][1] for r in rows]);ax.scatter(*q.T,**k)
def basemap(ax):
    cells=gp.read(K,'cells')
    polys(ax,gp.read('in/proektsem/vector/basemap/Moscow_water.gpkg'),COL['water'],z=0.5)
    polys(ax,cells,'#fbfaf7',ec='none',z=1)
    outline(ax,cells,'#b8b2a7',.4,6)
    polys(ax,gp.read(K,'buildings'),COL['bld'],z=7)
    return cells
def frame(ax,title=None):
    ax.set_xlim(-450,450);ax.set_ylim(-270,270);ax.set_aspect('equal');ax.axis('off')
    for s in ax.spines.values(): s.set_visible(False)
def labels(ax,cells,which=None,fs=6.5,col='#6d685f',z=20,text=None):
    for r in cells:
        if which is not None and r['num'] not in which: continue
        ps=gp.polys(r['_g']);ring=np.array(ps[0][0]);ar=0.5*(ring[:-1,0]*ring[1:,1]-ring[1:,0]*ring[:-1,1])
        cx=((ring[:-1,0]+ring[1:,0])*(ring[:-1,0]*ring[1:,1]-ring[1:,0]*ring[:-1,1])).sum()/(6*ar.sum());cy=((ring[:-1,1]+ring[1:,1])*(ring[:-1,0]*ring[1:,1]-ring[1:,0]*ring[:-1,1])).sum()/(6*ar.sum())
        q=T([[cx,cy]])[0];ax.text(*q,(text(r) if text else str(r['num'])),fontsize=fs,color=col,ha='center',va='center',zorder=z)
def sheet(title,sub):
    fig=plt.figure(figsize=(16.54,11.69))
    fig.text(0.024,0.955,title,fontsize=22,fontweight='semibold',color='#16161c')
    fig.text(0.024,0.928,sub,fontsize=11,color='#55524c')
    ax=fig.add_axes([0.024,0.30,0.714,0.606]);lg=fig.add_axes([0.75,0.10,0.235,0.81]);lg.axis('off')
    lg.set_xlim(0,1);lg.set_ylim(0,1)
    return fig,ax,lg
class Legend:
    def __init__(s,ax,y=0.985): s.ax=ax;s.y=y
    def head(s,t): s.y-=0.012;s.ax.text(0,s.y,t,fontsize=10.5,fontweight='semibold',color='#16161c',va='top');s.y-=0.034
    def item(L,kind,t,**k):
        nl=t.count('\n')+1
        ax=L.ax;y=L.y-0.012-0.0095*(nl-1);x0,x1=0.0,0.085
        if kind=='fill': ax.add_patch(mp.Rectangle((x0,y-0.011),x1-x0,0.022,fc=k.get('fc','none'),ec=k.get('ec','none'),lw=k.get('lw',.6),hatch=k.get('hatch'),alpha=k.get('al',1),ls=k.get('ls','-')))
        if kind=='fill2':
            ax.add_patch(mp.Rectangle((x0,y-0.011),x1-x0,0.022,fc=k['fc'],ec='none'));ax.add_patch(mp.Rectangle((x0,y-0.011),x1-x0,0.022,fc='none',ec=k['hc'],lw=0,hatch=k['hatch']))
            if k.get('ec'): ax.add_patch(mp.Rectangle((x0,y-0.011),x1-x0,0.022,fc='none',ec=k['ec'],lw=k.get('lw',.6),ls=k.get('ls','-')))
        if kind=='line': ax.plot([x0,x1],[y,y],c=k['c'],lw=k['lw'],ls=k.get('ls','-'),solid_capstyle='round',dash_capstyle='round')
        if kind=='mark': ax.scatter([(x0+x1)/2],[y],s=k.get('s',60),marker=k['m'],c=k.get('c'),edgecolors=k.get('ec','none'),linewidths=k.get('lw',.8),facecolors=k.get('fcs',None))
        ax.text(0.115,y,t,fontsize=9,va='center',color='#25231f',linespacing=1.15)
        L.y-=0.036+0.019*(nl-1)
    def note(s,t,fs=8.5): s.y-=0.01;s.ax.text(0,s.y,t,fontsize=fs,va='top',color='#55524c',linespacing=1.3);s.y-=0.022*(t.count('\n')+1)
def scalebar(fig,ax):
    # 100 м сегменты: ось axes в метрах
    x0,y0=-430,-255
    for i in range(4):
        ax.add_patch(mp.Rectangle((x0+i*50,y0),50,5,fc='#16161c' if i%2==0 else 'white',ec='#16161c',lw=.6,zorder=30))
        ax.text(x0+i*50,y0+9,str(i*50),fontsize=7,ha='center',zorder=30)
    ax.text(x0+200,y0+9,'200 м',fontsize=7,ha='center',zorder=30)
    # север
    n=Rm@np.array([0.,1.])
    c=np.array([425,240]);ax.annotate('',xy=c+n*22,xytext=c-n*6,arrowprops=dict(arrowstyle='-|>',color='#16161c',lw=1.2),zorder=30)
    ax.text(*(c+n*30),'С',fontsize=9,ha='center',va='center',fontweight='semibold',zorder=30)
def foot(fig,t='Проектный семинар «Городское планирование», БГП251, команда 2. Коньково №2. Карта повёрнута на 26,75°: южная граница территории горизонтальна. Данные: konkovo_v12, analiz_v12, problems_v12.'):
    fig.text(0.024,0.03,t,fontsize=8,color='#7a766e')
