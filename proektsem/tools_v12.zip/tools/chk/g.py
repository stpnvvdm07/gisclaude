import sys; sys.path.insert(0,'lib')
import gp, numpy as np, geo
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
b8=gp.read(V+'konkovo_v8.gpkg','buildings')
pg8=gp.read(V+'analiz_v8.gpkg','playgrounds_zones'); pg2=gp.read(U+'5801ca10-playground_2.gpkg')
def cen(g): return np.vstack([np.array(p[0]) for p in gp.polys(g)]).mean(0)
# systematic shift pg2->pg8 via nearest by area pairing
pairs=[]
for r in pg2:
    c=cen(r['_g']); j=min(range(30),key=lambda j:np.hypot(*(cen(pg8[j]['_g'])-c)) + 0.01*abs(sum(geo.area(p[0]) for p in gp.polys(pg8[j]['_g']))-r['area']))
    pairs.append(cen(pg8[j]['_g'])-c)
pairs=np.array(pairs); print('pg shift v8-pg2 mean',pairs.mean(0).round(2),'std',pairs.std(0).round(2))
# building overlap test via rasterized grid points
rings=[p[0] for o in b8 for p in gp.polys(o['_g'])]
def pipt(P,ring):
    x,y=P;c=False
    for i in range(len(ring)-1):
        x1,y1=ring[i];x2,y2=ring[i+1]
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1:c=not c
    return c
from matplotlib.path import Path
bp=[Path(np.array(r)) for r in rings]
def overlap(polyset,shift=(0,0)):
    tot=ov=0
    for r in polyset:
        for pr in gp.polys(r['_g']):
            ring=np.array(pr[0])+shift; mn=ring.min(0);mx=ring.max(0)
            xs=np.arange(mn[0],mx[0],1.0);ys=np.arange(mn[1],mx[1],1.0)
            G=np.array([(x,y) for x in xs for y in ys]);
            if len(G)==0: continue
            ins=Path(ring).contains_points(G); G=G[ins]
            tot+=len(G)
            m=np.zeros(len(G),bool)
            for p in bp: m|=p.contains_points(G)
            ov+=m.sum()
    return tot,ov
c2=gp.read(U+'fc0568b7-competitions_2.gpkg'); c8=gp.read(V+'analiz_v8.gpkg','competition')
print('comp2 vs bld overlap (m2 total, overlapped):',overlap(c2)); print('comp8:',overlap(c8))
print('pg2:',overlap(pg2),'pg8:',overlap(pg8))
sh=pairs.mean(0)
print('pg2 shifted:',overlap(pg2,sh))
print('comp2 shifted by pg shift:',overlap(c2,sh))
