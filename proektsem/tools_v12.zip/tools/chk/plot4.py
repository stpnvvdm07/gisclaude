import sys; sys.path.insert(0,'lib')
import gp, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
x0,x1,y0,y1=407260,407720,6167380,6167740
fig,ax=plt.subplots(figsize=(17,13))
def poly(rows,fc,ec='k',a=.6,lw=.5):
    for r in rows:
        for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc=fc,ec=ec,alpha=a,lw=lw))
g=gp.read(K,'green')
poly([r for r in g if r['type']=='трава'],'#bddaae',ec='none'); poly([r for r in g if r['type']=='деревья'],'#8ed0ad',ec='none')
pg=gp.read(K,'playgrounds'); poly(pg,'#d9c35b')
for r in pg:
    c=np.vstack([np.array(p[0]) for p in gp.polys(r['_g'])]).mean(0)
    if x0<c[0]<x1 and y0<c[1]<y1: ax.text(*c,r['type'],fontsize=7)
b=gp.read(K,'buildings'); poly(b,'#a39279')
for r in b:
    c=np.vstack([np.array(p[0]) for p in gp.polys(r['_g'])]).mean(0)
    if x0<c[0]<x1 and y0<c[1]<y1: ax.text(c[0],c[1],f"{r['id']} {r.get('Адрес / ориентир') or ''}"[:34],fontsize=8,color='k')
for r in gp.read(A,'network'):
    for l in gp.lines(r['_g']): a=np.array(l); ax.plot(a[:,0],a[:,1],c='#777',lw=.6)
for r in gp.read(K,'fences'):
    for l in gp.lines(r['_g']): a=np.array(l); ax.plot(a[:,0],a[:,1],c='#b13840',lw=1.6)
ax.set_xlim(x0,x1);ax.set_ylim(y0,y1);ax.set_aspect('equal');plt.savefig('chk/nw.png',dpi=70,bbox_inches='tight')
