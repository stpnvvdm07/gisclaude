import sys,collections; sys.path.insert(0,'lib')
import gp,numpy as np,matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
from matplotlib import font_manager as fm
import glob
for f in glob.glob('fonts/*.ttf'): fm.fontManager.addfont(f)
plt.rcParams['font.family']='Inter' 
K='out9/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
def polys(ax,rows,fc,ec='none',a=1,lw=.3,z=1):
    for r in rows:
        for p in gp.polys(r['_g']):
            V=[];C=[]
            for ring in p:
                ring=np.array(ring); V+=list(ring)+[ring[0]]; C+=[MPath.MOVETO]+[MPath.LINETO]*(len(ring)-1)+[MPath.CLOSEPOLY]
            ax.add_patch(PathPatch(MPath(V,C),fc=fc,ec=ec,alpha=a,lw=lw,zorder=z))
def base(ax):
    polys(ax,gp.read(K,'buildings'),'#a39279',z=5)
    for r in gp.read(K,'boundary'):
        for p in gp.polys(r['_g']): ax.plot(*np.array(p[0]).T,c='#6852a0',lw=1.2,ls='--',zorder=9)
    ax.set_aspect('equal'); ax.axis('off')
# 1 osvoennost
fig,ax=plt.subplots(figsize=(16,12)); col={'освоенная':'#5ec46e','частично освоенная':'#d9c35b','неосвоенная':'#b13840'}
o=gp.read(A,'osvoennost')
for k,c in col.items(): polys(ax,[r for r in o if r['cls']==k],c,z=2)
polys(ax,gp.read(K,'parking'),'#8bb0b0',z=3); polys(ax,gp.read(K,'loading_zones'),'#6852a0',z=4)
for r in gp.read(K,'osv_manual'):
    for p in gp.polys(r['_g']): ax.plot(*np.array(p[0]).T,c='#16161c',lw=1.5,ls=':',zorder=8)
for r in gp.read(K,'cells'):
    for p in gp.polys(r['_g']): ax.plot(*np.array(p[0]).T,c='#333338',lw=.4,zorder=6)
    c=np.vstack([np.array(p[0]) for p in gp.polys(r['_g'])]).mean(0); ax.text(*c,str(r['num']),fontsize=8,ha='center',color='#333338',zorder=10)
base(ax)
import matplotlib.patches as mp
ax.legend(handles=[mp.Patch(fc=v,label=k) for k,v in col.items()]+[mp.Patch(fc='#8bb0b0',label='парковки'),mp.Patch(fc='#6852a0',label='зоны загрузки')],loc='lower left',fontsize=11,frameon=False)
plt.savefig('out9/prev_osvoennost.png',dpi=90,bbox_inches='tight'); plt.close()
# 2 transit + flows
fig,ax=plt.subplots(figsize=(16,12)); base(ax)
for r in gp.read(A,'network'):
    for l in gp.lines(r['_g']): ax.plot(*np.array(l).T,c='#ddd',lw=.5,zorder=1)
tr=gp.read(A,'transit'); mx=max(r['load'] for r in tr if r['mode']=='пешеходный')
for r in tr:
    if r['mode']!='пешеходный': continue
    for l in gp.lines(r['_g']): ax.plot(*np.array(l).T,c='#b13840' if r['cls']=='высокая' else '#e8a0a5',lw=1+5*r['load']/mx,zorder=3,solid_capstyle='round')
for r in tr:
    if r['mode']!='транспортный' or r['cls']!='высокая': continue
    for l in gp.lines(r['_g']): ax.plot(*np.array(l).T,c='#6852a0',lw=2,ls='--',zorder=4)
for r in gp.read(A,'flows'):
    x,y=r['_g'][1]; ax.scatter(x,y,s=20+r['sat_human']*6,c='#94acd6',ec='#16161c',lw=.8,zorder=7); ax.text(x+8,y+8,str(r['id']),fontsize=8,zorder=8)
ax.legend(handles=[mp.Patch(fc='#b13840',label='транзит пеш., высокая нагрузка'),mp.Patch(fc='#e8a0a5',label='транзит пеш., низкая'),mp.Patch(fc='#6852a0',label='транзит авто, высокая'),mp.Patch(fc='#94acd6',label='замер потока (размер = люди, сб 17:00)')],loc='lower left',fontsize=11,frameon=False)
plt.savefig('out9/prev_transit.png',dpi=90,bbox_inches='tight')
