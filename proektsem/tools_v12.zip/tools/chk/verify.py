import sys,collections; sys.path.insert(0,'lib')
import gp,rb,io9,numpy as np
from matplotlib.path import Path
K='out10/konkovo_v10.gpkg'; A='out10/analiz_v10.gpkg'
b=gp.read(K,'buildings'); print('buildings with assessment',sum(1 for r in b if r['function']),collections.Counter((r['function'],r['danger'],r['isolation']) for r in b if r['function']))
rings=[(r['id'],np.array(p[0])) for r in b for p in gp.polys(r['_g'])]
paths=[Path(r) for _,r in rings]
def overlap(rows,skip=lambda a:False):
    tot=ov=0
    for r in rows:
        if skip(r): continue
        for p in gp.polys(r['_g']):
            ring=np.array(p[0]);mn=ring.min(0);mx=ring.max(0)
            G=np.array([(x,y) for x in np.arange(mn[0],mx[0],.5) for y in np.arange(mn[1],mx[1],.5)])
            if not len(G): continue
            ins=Path(ring).contains_points(G)
            for h in p[1:]: ins&=~Path(np.array(h)).contains_points(G)
            G=G[ins]; tot+=len(G)*.25
            m=np.zeros(len(G),bool)
            for pa in paths: m|=pa.contains_points(G)
            ov+=m.sum()*.25
    return round(tot),round(ov)
pk=gp.read(K,'parking'); print('parking (excl. building-parking) area/overlap',overlap(pk,lambda r:r['kind'].startswith('здание')),collections.Counter(r['kind'] for r in pk))
print('loading zones area/overlap',overlap(gp.read(K,'loading_zones')))
# business
bz=gp.read(K,'business'); byid=collections.defaultdict(list)
for i,r in rings: byid[i].append(r)
def dmin(P,i):
    best=1e9
    for r in byid[i]:
        A_,B_=r[:-1],r[1:];d=B_-A_;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A_)*d).sum(1)/L,0,1);Q=A_+d*t[:,None];best=min(best,np.hypot(*(P-Q).T).min())
    return best
dd=np.array([dmin(np.array(r['_g'][1]),r['bld_id']) for r in bz]); print('business: n',len(bz),'dist to own building median',round(float(np.median(dd)),2),'max',round(float(dd.max()),2),'<=0.5m',int((dd<=0.5).sum()))
pg=gp.read(K,'playgrounds'); print('playgrounds',collections.Counter((r['function'],r['danger'],r['isolation']) for r in pg))
fl=gp.read(A,'flows'); print('flows sums human',sum(r['sat_human'] for r in fl),'cars',sum(r['in_car']+r['out_car'] for r in fl))
tr=gp.read(A,'transit'); print('transit',collections.Counter((r['mode'],r['cls']) for r in tr)); 
print('transit length by mode/cls',{k:round(v) for k,v in collections.Counter({(r['mode'],r['cls']):0 for r in tr}).items()})
L=collections.defaultdict(float)
for r in tr: L[(r['mode'],r['cls'])]+=r['length']
print({k:round(v) for k,v in L.items()})
o=gp.read(A,'osvoennost'); S=collections.defaultdict(float)
for r in o: S[r['cls']]+=r['area']
t=sum(S.values()); print('osvoennost',{k:(round(v),round(100*v/t,1)) for k,v in S.items()},'total',round(t))
print(collections.Counter((r['kind'].split(':')[0],r['cls']) for r in o))
