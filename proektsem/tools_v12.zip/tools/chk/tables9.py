import sys,pickle,collections,cv2; sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
OUT='out9/'; V='/mnt/user-data/uploads/proektsem/vector/'; U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
parcels=pickle.load(open(OUT+'parcels.pkl','rb')); lab=np.load(OUT+'lab.npy'); w=pickle.load(open(OUT+'win.pkl','rb')); R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R); W.h,W.w=lab.shape
def cls(p,tb=1.0,tu=1.0):
    if p['man']>=0.5 and not p['kind'].startswith('площадка'): return 'неосвоенная'
    b=p['B']>=tb; u=p['U']>=tu
    return 'освоенная' if b and u else ('частично освоенная' if b or u else 'неосвоенная')
wb=Workbook(); hdr=PatternFill('solid',fgColor='D9D0C0'); bold=Font(bold=True)
def sheet(name,head,rows,widths=None):
    ws=wb.create_sheet(name); ws.append(head)
    for c in ws[1]: c.font=bold; c.fill=hdr; c.alignment=Alignment(wrap_text=True,vertical='top')
    for r in rows: ws.append(r)
    for i in range(1,len(head)+1): ws.column_dimensions[get_column_letter(i)].width=(widths[i-1] if widths else 16)
    ws.freeze_panes='A2'; return ws
wb.remove(wb.active)
# cells
cr=pickle.load(open(OUT+'cellrows.pkl','rb'))['cells']
sheet('Освоенность по ячейкам',['Ячейка','В анализе','Площадь, м²','Участки, м²','Освоенные, м²','Частично, м²','Неосвоенные, м²','Освоенные, %','Частично, %','Неосвоенные, %','Преобладает','Парковки, м²','Загрузка, м²'],
 [[a['num'],a['is_anal'],a['area'],a['parcels_area'],a['osv_m2'],a['part_m2'],a['unosv_m2'],a['osv_pct'],a['part_pct'],a['unosv_pct'],a['dominant'],a['parking_m2'],a['loading_m2']] for (a,) in sorted(cr,key=lambda x:x[0]['num'])])
# balance
names={1:'Здания',2:'Площадки',3:'Парковки',4:'Зоны загрузки',5:'Проезды и дорожки',6:'Деревья',7:'Трава',8:'Прочие поверхности',9:'Вода'}
tot=sum((lab==k).sum() for k in names)*R*R
sheet('Баланс территории',['Категория','Площадь, м²','Доля, %'],[[names[k],round((lab==k).sum()*R*R),round(100*(lab==k).sum()*R*R/tot,1)] for k in names]+[['Итого в границе',round(tot),100.0]],[28,14,10])
# sensitivity
rows=[]
for tb in (1.0,1.2):
    for tu in (0.8,1.0,1.2):
        c=collections.defaultdict(float)
        for p in parcels: c[cls(p,tb,tu)]+=p['area']
        t=sum(c.values()); rows.append([tb,tu]+[round(100*c[k]/t,1) for k in ('освоенная','частично освоенная','неосвоенная')])
sheet('Чувствительность к порогам',['Порог B','Порог U','Освоенные, %','Частично, %','Неосвоенные, %'],rows)
# control x osv
ctl=np.zeros(lab.shape,np.uint8); code={'контролируемая':1,'частично контролируемая':2,'неконтролируемая':3}
for g,a in io9.load(V+'analiz_v8.gpkg','control')[2]:
    for p in gp.polys(g): W.fill(ctl,[np.array(p[0])],code[a['type']],holes=[np.array(h) for h in p[1:]])
cross=collections.defaultdict(float)
for p in parcels:
    if p['kind'].startswith('площадка'):
        pass
    for rs in p['poly']:
        rings=[np.asarray(r) for r in rs]; x0_,y0_=np.vstack(rings).min(0); x1_,y1_=np.vstack(rings).max(0)
        sw=rb.Win(x0_-1,y0_-1,x1_+1,y1_+1,R); m=sw.blank(); sw.fill(m,[rings[0]],1,holes=rings[1:])
        ys,xs=np.nonzero(m); gx=((sw.x0+xs*R)-W.x0)/R; gy=((sw.y0+ys*R)-W.y0)/R
        gx=np.clip(gx.astype(int),0,lab.shape[1]-1); gy=np.clip(gy.astype(int),0,lab.shape[0]-1)
        v=ctl[gy,gx]; c=cls(p)
        for k in (0,1,2,3): cross[(k,c)]+=(v==k).sum()*R*R
inv={0:'вне зон контроля (не классифицировано)',1:'контролируемая',2:'частично контролируемая',3:'неконтролируемая'}
sheet('Контролируемость × освоенность',['Контролируемость','Освоенные, м²','Частично, м²','Неосвоенные, м²'],[[inv[k]]+[round(cross[(k,c)]) for c in ('освоенная','частично освоенная','неосвоенная')] for k in (1,2,3,0)],[40,16,16,16])
pickle.dump(dict(cross),open(OUT+'cross.pkl','wb'))
# flows
fl=gp.read(OUT+'analiz_v9.gpkg','flows')
sheet('Потоки (замеры)',['Точка','Тип','Авто вх','Авто вых','Люди вх','Люди вых','Курьеры','Люди всего (сб 17:00)','Пн ~8:00, оценка (×2,5)','Пн, нижняя (×2,0)','Пн, верхняя (×3,0)','Класс','Путей в дереве (пеш.)','Путей в дереве (авто)','Привязка к сети, м'],
 [[r['id'],r['type'],r['in_car'],r['out_car'],r['in_human'],r['out_human'],r['couriers'],r['sat_human'],r['mon_est'],r['mon_low'],r['mon_high'],r['cls'],r['tree_ped'],r['tree_veh'],r['snap_dist']] for r in fl],[8,14]+[12]*13)
# issues
iss=[
 ['business_2','Точки оцифрованы на старой растровой подложке: аффинное смещение (масштаб ≈0,98–0,99, сдвиг ≈11 м, 2 м). Исправлено подгонкой под здание по адресу; медиана расстояния 0,4 м.','Исправлено'],
 ['business_2','Не удалось привязать к своему зданию точнее 4 м: fid 6 (СберБанк, Профсоюзная 83А), 35, 36, 49, 51 (Миклухо-Маклая 55), 55 (Введенского 16) — проверить на карте.','Проверить'],
 ['business_2','fid 31 «Бушери выпечка» по адресу 55с3, по геометрии стоит у дома 53к1 (id 37) — привязана к id 37.','Проверить'],
 ['business_2','Нет fid 14, 15, 22, 54 (в файле 51 точка, не 53).','Уточнить'],
 ['business_2','Разные оценки у одинаковых объектов: СберБанк fid 6, 50 «не связан» и fid 38 «обслуживающий»; «Около» fid 4 «открытый», fid 13 «закрытый».','Уточнить'],
 ['business_2','Дом 83А: Шаурма, Кафе, Столовая — «отдельно стоящий», СберБанк — «встроенный».','Уточнить'],
 ['business_2','Значение «пристроенный» отсутствует в списке задания 2.1 (встроенный, встроенно-пристроенный, отдельно стоящий).','Уточнить'],
 ['business_2','Название «-» у 16 точек, Назначение «-» у «Бюро переводов» и «Ломбарда».','Заполнить'],
 ['buildings_2','Оценены 5 из 91 зданий: id 30, 32, 35 и два здания без id (площадь 89,5 и 81,6 м²). Детсад id 10 не оценён.','Дополнить'],
 ['competitions_2','Это зоны загрузки, а не слой competition (АЖ∩АП). Контуры — скруглённые пятна с заходом на здания и газоны; пересобраны по проездам/дорожкам/парковкам без зданий: 24 032 → 7 451 м². Fid 13: function «м». Все 20 «опасный».','Пересобрано, проверить'],
 ['playground_2','Геометрия смещена на 5,7 м на юг относительно чертежа; поля dist/zone/control/problem устаревшие. Атрибуты function/danger/isolation перенесены на геометрию v8 (30 из 30, площадь совпала). Исправлены «сопутствующаясопутствующая» (fid 26), «благоприятные» → «благоприятный».','Исправлено'],
 ['playground_2','Собачья площадка: «неблагоприятный» — в шкале задания 2.2 три значения (опасный / индифферентный / благоприятный).','Уточнить'],
 ['parking','Было 17 контуров: три копии контура здания 24 (многоуровневый паркинг), два контура гаражей накрывали здания. Теперь 16 объектов, пересечений со зданиями нет (кроме самого здания-паркинга).','Исправлено'],
 ['entrances_points_1','Нет времени и длительности замера; 3 точки с нулями (10, 14, 16); 6 точек «смешанный» без авто (14, 17, 18, 19, 23, 24).','Уточнить'],
 ['entrances_points_1','Дерево путей и замеры: ρ Спирмена 0,37 для людей (n=25, p=0,07), 0,05 для машин (p=0,80).','Для интерпретации'],
 ['osvoennost','Благоустроенность: освещения и урн нет, колонки light/urns пустые и не входят в расчёт. Покрытие/озеленение/рельеф — косвенные признаки.','Дополнить после съёмки'],
 ['osvoennost','Неосвоенная территория МИСИС: контур osv_manual предварительный (по забору в СЗ), нужно подтвердить.','Подтвердить'],
]
sheet('Замечания к данным',['Слой','Замечание','Статус'],iss,[22,120,24])
wb.save(OUT+'Освоенность, потоки, транзит v9.xlsx'); print('saved')
for k,v in sorted(cross.items()): print(k,round(v))
