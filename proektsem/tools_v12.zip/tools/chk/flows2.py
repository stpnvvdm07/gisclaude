import sys,pickle,collections; sys.path.insert(0,'lib')
exec(open('chk/flows.py').read().split("# snap entries")[0])
sn=pickle.load(open('out9/snap.pkl','rb'))['snap']
B='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/basemap/'
metro=np.array([407207.,6167309.]); TC={'Капитолий':np.array([407480.,6167120.]),'Ашан Сити':np.array([407520.,6167092.]),'МЦ':np.array([407645.,6167010.])}
Gp=G.copy()
nodeid={}
for r,s in zip(ent,sn):
    D,u,v,Q,ty=s; Q=np.array(Q); d=Gp[u][v]; L=d['length']; l=d['pts']
    t=float(np.hypot(*(Q-l[0]))/max(np.hypot(*(l[-1]-l[0])),1e-6)); t=min(max(t,0),1)
    n=('e',r['fid']); nodeid[r['fid']]=n
    Gp.add_edge(n,u,pw=L*t*PEDW[d['type']]+D,vw=(L*t+D),length=L*t,type='virt',eid=None,pts=np.array([Q,l[0]]))
    Gp.add_edge(n,v,pw=L*(1-t)*PEDW[d['type']]+D,vw=(L*(1-t)+D),length=L*(1-t),type='virt',eid=None,pts=np.array([Q,l[-1]]))
EP={r['fid']:np.array(r['_g'][1]) for r in ent}
ex_metro=sorted(EP,key=lambda f:np.hypot(*(EP[f]-metro)))[:3]
ex_tc={k:min(EP,key=lambda f:np.hypot(*(EP[f]-v))) for k,v in TC.items()}
print('exits metro',ex_metro,'exits TC',ex_tc)
tc_exits=sorted(set(ex_tc.values()))
cnt={r['fid']:r for r in ent}
def route(mode):
    load=collections.defaultdict(lambda:[0.,0.])  # eid -> [metro,tc]
    for f,r in cnt.items():
        w=(r['in_human']+r['out_human']) if mode=='ped' else (r['in_car']+r['out_car'])
        if w<=0: continue
        for di,(ex) in enumerate((ex_metro,tc_exits)):
            cand=[e for e in ex if e!=f]
            if not cand: continue
            if mode=='veh':
                H=nx.Graph(); 
                for u,v,d in Gp.edges(data=True):
                    if d['vw'] is not None: H.add_edge(u,v,w=d['vw'],eid=d['eid'])
                Hh=H
            else:
                Hh=None
            best=None
            for e in cand:
                try:
                    if mode=='ped': p=nx.shortest_path(Gp,nodeid[f],nodeid[e],weight='pw'); L=nx.path_weight(Gp,p,'pw')
                    else: p=nx.shortest_path(Hh,nodeid[f],nodeid[e],weight='w'); L=nx.path_weight(Hh,p,'w')
                except Exception: continue
                if best is None or L<best[0]: best=(L,p)
            if best is None: continue
            for a,b in zip(best[1][:-1],best[1][1:]):
                eid=Gp[a][b].get('eid')
                if eid is not None: load[eid][di]+=w*0.5
    return load
lp=route('ped'); lv=route('veh')
print('ped segments',len(lp),'veh segments',len(lv))
pickle.dump({'lp':dict(lp),'lv':dict(lv),'ex_metro':ex_metro,'ex_tc':ex_tc},open('out9/transit.pkl','wb'))
# per-entry tree comparison
rows=[]
for r,s in zip(ent,sn):
    D,u,v,Q,ty=s; d=G[u][v]; a=net[d['eid']][1]
    near=[]; 
    for (g,aa) in net:
        for l in gp.lines(g):
            l=np.array(l)
            for p,q in zip(l[:-1],l[1:]):
                dd=q-p;L=dd@dd+1e-9;t=np.clip(((np.array(Q)-p)@dd)/L,0,1);if_=np.hypot(*(np.array(Q)-(p+dd*t)))
                if if_<=6: near.append(aa)
    ped=max([x['ped'] or 0 for x in near]+[0]); veh=max([x['veh'] or 0 for x in near]+[0])
    rows.append((r['fid'],ped,veh,r['in_human']+r['out_human'],r['in_car']+r['out_car']))
a=np.array(rows,float)
print('Spearman ped tree vs people:',spearmanr(a[:,1],a[:,3]))
print('Spearman veh tree vs cars:',spearmanr(a[:,2],a[:,4]))
pickle.dump({'tree_cmp':rows},open('out9/treecmp.pkl','wb'))
