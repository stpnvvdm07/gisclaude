import sys,glob;sys.path.insert(0,'lib')
import gp,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
import matplotlib.patches as mp
from matplotlib import font_manager as fm
for f in glob.glob('fonts/*.ttf'): fm.fontManager.addfont(f)
plt.rcParams['font.family']='Inter'
K='out10/konkovo_v10.gpkg';A='out10/analiz_v10.gpkg';P='out11/problems_v11.gpkg'
a=np.radians(26.75);Rm=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
T=lambda p:np.asarray(p,float)@Rm.T
def polys(ax,rows,fc,ec='none',al=1,lw=.3,z=1,hatch=None):
    for r in rows:
        for p in gp.polys(r['_g']):
            V=[];C=[]
            for ring in p:
                ring=T(ring);V+=list(ring)+[ring[0]];C+=[MPath.MOVETO]+[MPath.LINETO]*(len(ring)-1)+[MPath.CLOSEPOLY]
            ax.add_patch(PathPatch(MPath(V,C),fc=fc,ec=ec,alpha=al,lw=lw,zorder=z,hatch=hatch))
def lines(ax,rows,c,lw,z,ls='-'):
    for r in rows:
        for l in gp.lines(r['_g']): q=T(l);ax.plot(*q.T,c=c,lw=lw,zorder=z,ls=ls,solid_capstyle='round')
def pts(ax,rows,**k):
    q=T([r['_g'][1] for r in rows]);ax.scatter(*q.T,**k)
fig,ax=plt.subplots(figsize=(17,9.5))
vc=gp.read(P,'viol_cells')
polys(ax,vc,'#fbf9f4',ec='#aaa',lw=.4,z=1)
polys(ax,[r for r in vc if r['v1в']==1],'#d8d4cc',al=.9,z=2,hatch='////',ec='#aaa')
polys(ax,[r for r in vc if r['v1а']==1],'#a68cc6',al=.28,z=2)
polys(ax,gp.read(P,'pre_osv_ctl'),'#5ec46e',al=.45,z=2)
polys(ax,[r for r in gp.read(A,'osvoennost') if r['cls']=='неосвоенная'],'#b13840',al=.5,z=3)
polys(ax,gp.read(A,'competition'),'#c978d3',al=.7,z=3)
polys(ax,gp.read(K,'loading_zones'),'#6852a0',al=.85,z=4)
polys(ax,gp.read(K,'buildings'),'#a39279',z=5)
polys(ax,gp.read(P,'p1g_wear'),'#5a3d2b',z=6)
polys(ax,gp.read(P,'p3v_playgrounds'),'#d9c35b',ec='#16161c',lw=1,z=6)
lines(ax,gp.read(P,'p2c_combined'),'#e08a2b',2.6,7)
lines(ax,gp.read(P,'p3a_transit_res'),'#b13840',1.6,8,'--')
pts(ax,gp.read(P,'p3b_biz'),s=70,facecolors='none',edgecolors='#2a6fdb',linewidths=1.6,zorder=9)
pts(ax,gp.read(P,'p2b_objects'),s=60,marker='X',c='#b13840',edgecolors='#16161c',linewidths=.6,zorder=10)
pts(ax,gp.read(P,'p1b_entry_nodes'),s=90,marker='^',c='#b13840',edgecolors='#16161c',linewidths=.8,zorder=11)
pts(ax,gp.read(P,'pre_entry_nodes'),s=60,marker='^',c='#5ec46e',edgecolors='#16161c',linewidths=.6,zorder=11)
for r in vc:
    if r['in_scope']:
        c=T(np.array(gp.polys(r['_g'])[0][0]).mean(0));ax.text(*c,f"{r['num']}",fontsize=7,ha='center',color='#333',zorder=12)
ax.set_aspect('equal');ax.autoscale();ax.axis('off')
H=[mp.Patch(fc='#a68cc6',alpha=.4,label='1.1 ячейка: размеры / пропорции / границы (балл < 0,67)'),mp.Patch(fc='#d8d4cc',hatch='////',ec='#aaa',label='1.3 вне зафиксированных границ'),mp.Patch(fc='#5a3d2b',label='1.4 износ здания ≥ 40 %'),
 plt.Line2D([],[],marker='^',ls='',c='#b13840',label='1.2 не организованный узел входа'),mp.Patch(fc='#6852a0',label='2.1 зона загрузки'),plt.Line2D([],[],marker='X',ls='',c='#b13840',label='2.2 опасный открытый объект'),
 plt.Line2D([],[],c='#e08a2b',lw=3,label='2.3 совмещение транзитных потоков на проезде'),plt.Line2D([],[],c='#b13840',ls='--',label='3.1 транзит через придомовые территории'),plt.Line2D([],[],marker='o',ls='',mfc='none',mec='#2a6fdb',label='3.2 обслуживающий объект с внешним транзитом'),
 mp.Patch(fc='#d9c35b',ec='#16161c',label='3.3 место поведения вне контроля'),mp.Patch(fc='#c978d3',label='3.4 конкуренция контролей'),mp.Patch(fc='#b13840',alpha=.5,label='3.4 неосвоенная территория'),
 mp.Patch(fc='#5ec46e',alpha=.5,label='предпосылка: освоенная и контролируемая'),plt.Line2D([],[],marker='^',ls='',c='#5ec46e',label='предпосылка: организованный вход (арка, ворота, калитка)')]
ax.legend(handles=H,loc='center left',bbox_to_anchor=(1.0,.5),fontsize=9,frameon=False)
plt.savefig('out11/prev_problems_v11.png',dpi=80,bbox_inches='tight')
