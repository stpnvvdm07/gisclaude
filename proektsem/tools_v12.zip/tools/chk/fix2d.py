import sys,pickle; sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np,msk
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'
v8=gp.read(K,'buildings'); bz=gp.read(U+'92246443-business_2.gpkg')
ADDR={'Профсоюзная 83к1':1,'Профсоюзная 83к2':2,'Профсоюзная 83А':4,'Профсоюзная 83к3':5,'Миклухо-Маклая 53к1':37,'Миклухо-Маклая 55с3':26,'Миклухо-Маклая 55':26,'Введенского 16':13}
segs={}
for r in v8:
    if r['id'] is None: continue
    for p in gp.polys(r['_g']):
        a=np.array(p[0]); segs.setdefault(r['id'],[]).append((a[:-1],a[1:]))
SG={k:(np.vstack([s[0] for s in v]),np.vstack([s[1] for s in v])) for k,v in segs.items()}
def dproj(P,bid):
    A_,B_=SG[bid]; d=B_-A_;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A_)*d).sum(1)/L,0,1);Q=A_+d*t[:,None];D=np.hypot(*(P-Q).T);j=D.argmin();return D[j],Q[j]
P0=np.array([[float(x) for x in msk.utm37(np.array(r['_g'][1][0]),np.array(r['_g'][1][1]))] for r in bz])
bid=[37 if r['fid']==31 else ADDR[r['adress']] for r in bz]
grp=['Проф' if r['adress'].startswith('Проф') else 'Мик' if r['adress'].startswith('Мик') else 'Вв' for r in bz]
best={}
for g in ('Проф','Мик'):
    idx=[i for i,x in enumerate(grp) if x==g]; b=None
    for dx in np.arange(-20,20.01,0.5):
      for dy in np.arange(-20,20.01,0.5):
        c=sum(min(dproj(P0[i]+[dx,dy],bid[i])[0],8) for i in idx)
        if b is None or c<b[0]: b=(c,dx,dy)
    best[g]=b; print(g,len(idx),b[1],b[2],'robust mean',round(b[0]/len(idx),2))
# global too
idx=[i for i,x in enumerate(grp) if x!='Вв']; b=None
for dx in np.arange(-20,20.01,0.5):
  for dy in np.arange(-20,20.01,0.5):
    c=sum(min(dproj(P0[i]+[dx,dy],bid[i])[0],8) for i in idx)
    if b is None or c<b[0]: b=(c,dx,dy)
print('global',b[1],b[2],round(b[0]/len(idx),2))
print('--- affine ICP')
def fit(P,Q,w=None):
    X=np.c_[P,np.ones(len(P))]; 
    if w is None: w=np.ones(len(P))
    W=np.sqrt(w)[:,None]; M,_,_,_=np.linalg.lstsq(X*W,Q*W,rcond=None); return M
def apply(M,P): return np.c_[P,np.ones(len(P))]@M
idx=[i for i in range(len(P0)) if grp[i]!='Вв']
c0=P0[idx].mean(0)
for start in [(12,5),(7.5,-4.5),(5,9.5),(11,6)]:
    M=np.array([[1,0],[0,1],[start[0],start[1]]],float)
    # centre the coords to keep conditioning
    Pc=P0-c0
    M=np.array([[1,0],[0,1],list(np.array(start)+0)],float)
    for it in range(30):
        cur=apply(M,Pc)+c0*0
        # projections to own building (in centred frame => shift building coords)
        T=[];ds=[]
        for i in idx:
            d,q=dproj(cur[i]+c0,bid[i]); T.append(q-c0); ds.append(d)
        ds=np.array(ds); w=1/np.maximum(ds,0.5)
        M=fit(Pc[idx],np.array(T),w)
    res=np.array([dproj(apply(M,Pc)[i]+c0,bid[i])[0] for i in idx])
    print(start,'median',round(float(np.median(res)),2),'mean',round(float(res.mean()),2),'>4m',int((res>4).sum()),'linear part',M[:2].round(3).tolist(),'shift',M[2].round(1))
