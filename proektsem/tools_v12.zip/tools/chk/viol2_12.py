import sys,pickle,collections;sys.path.insert(0,'lib')
import numpy as np
d=pickle.load(open('out12/viol12.pkl','rb'));V=d['V']
V[20]['iso_koef']=0.3499  # хранится округлённым 0.35, класс в cells — «Низкий» (≤0,35 — низкая)
BASE=dict(comfort_cut=0.67,ent_non=1,loading_m2=50,wear_n=1,danger_obj=1,combined_m=20,transit_res_m=20,biz_transit=1,pg_out=1,comp_pct=5,unc_pct=50,unos_pct=25,
          vl=0.6,vh=1.4,vu=2.0,il=0.35,ih=0.65,size_T=None)
ITEMS=['1.1','1.2','1.3','1.4','2.1','2.2','2.3','3.1','3.2','3.3','3.4']
NAMES={'1.1':'размеры, пропорции, фиксация границ ячейки','1.2':'неорганизованные узлы входов','1.3':'вне зафиксированных границ','1.4':'износ зданий ≥ 40 %','2.1':'загрузка с заездом грузового транспорта','2.2':'опасные открытые объекты',
 '2.3':'совмещение транзитных потоков на проездах','3.1':'транзит через придомовые территории','3.2':'обслуживающие объекты с внешним транзитом','3.3':'места поведения вне контроля','3.4':'конкуренция контролей, неконтролируемые и заброшенные'}
def comfort(v,T):
    k=v['vert_koef']
    vv=0 if (k is None or k<T['vl'] or k>=T['vu']) else (2 if k>=T['vh'] else 1)
    i=v['iso_koef'];ii=0 if i<T['il'] else (2 if i>=T['ih'] else 1)
    pl=(2 if v['planning']=='Комфортная' else 0) if T['size_T'] is None else (2 if v['size']<=T['size_T'] else 0)
    return (vv+ii+pl)/6,(vv,ii,pl)
def flags(n,T):
    v=V[n];sc,_=comfort(v,T);f={}
    f['1.1']=sc<T['comfort_cut']-0.005
    f['1.2']=v['ent_non']>=T['ent_non']
    f['1.3']=not v['is_anal']
    f['1.4']=v['wear40']>=T['wear_n']
    f['2.1']=v['loading_m2']>=T['loading_m2']
    f['2.2']=v['danger_obj']>=T['danger_obj']
    f['2.3']=v['combined_m']>=T['combined_m']
    f['3.1']=v['pod']>0 and v['transit_res_m']>=T['transit_res_m']
    f['3.2']=v['biz_transit']>=T['biz_transit']
    f['3.3']=v['pg_out']>=T['pg_out']
    f['3.4']=(v['comp_pct']>=T['comp_pct']) or (v['unc_pct']>=T['unc_pct']) or ((v['unosv_pct'] or 0)>=T['unos_pct'])
    return f,sc
scope=[n for n in V if V[n]['is_anal'] or V[n]['pod']>0]
def table(T): return {n:(lambda f,sc:(sum(f.values()),f,sc))(*flags(n,T)) for n in scope}
cls=lambda s:'высокая' if s>=6 else ('средняя' if s>=4 else 'низкая')
base=table(BASE)
sens=[]
from scipy.stats import spearmanr
def run(name,T):
    t=table(T);s={n:t[n][0] for n in scope}
    sens.append((name,T,sum(s.values()),sum(1 for x in s.values() if cls(x)=='высокая'),sum(1 for n in scope if cls(s[n])!=cls(base[n][0])),round(float(spearmanr([base[n][0] for n in scope],[s[n] for n in scope])[0]),3),sum(1 for n in scope if t[n][2]>=T['comfort_cut']-0.005)))
run('базовые пороги',BASE)
for k,vals in [('comfort_cut',[0.5,0.83]),('ent_non',[2]),('wear_n',[2]),('loading_m2',[25,100]),('danger_obj',[2]),('combined_m',[10,40]),('transit_res_m',[10,40]),('biz_transit',[2]),('comp_pct',[2,10]),('unc_pct',[30,70]),('unos_pct',[10,50]),
               ('vl',[0.5,0.7]),('vh',[1.2,1.6]),('vu',[1.8,2.2]),('il',[0.30,0.40]),('ih',[0.60,0.70]),('size_T',[130,140,150])]:
    for x in vals:
        T=dict(BASE);T[k]=x;run(f'{k} = {x}',T)
ranges={n:[base[n][0],base[n][0]] for n in scope}
for name,T,*_ in sens:
    for n in scope:
        s=sum(flags(n,T)[0].values());ranges[n][0]=min(ranges[n][0],s);ranges[n][1]=max(ranges[n][1],s)
unstable=[n for n in sorted(scope) if len({cls(ranges[n][0]),cls(base[n][0]),cls(ranges[n][1])})>1]
pickle.dump(dict(BASE=BASE,base=base,scope=scope,sens=sens,ITEMS=ITEMS,NAMES=NAMES,ranges=ranges,unstable=unstable),open('out12/viol2_12.pkl','wb'))
if __name__=='__main__':
    print('scope',len(scope));print('classes',collections.Counter(cls(r[0]) for r in base.values()))
    print('items',{it:sum(r[1][it] for r in base.values()) for it in ITEMS},'sum',sum(r[0] for r in base.values()))
    print('top',sorted(((r[0],n) for n,r in base.items()),reverse=True)[:12])
    print('comfortable',sum(1 for r in base.values() if not r[1]['1.1']))
    for r in sens: print(r[0],r[2:])
    print('unstable',unstable)
    print('1.3 all cells',sum(1 for n in V if not V[n]['is_anal']))
