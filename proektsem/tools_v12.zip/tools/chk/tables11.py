import sys,pickle,collections;sys.path.insert(0,'lib')
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
d=pickle.load(open('out10/viol.pkl','rb'));V=d['V'];m=pickle.load(open('out10/viol2.pkl','rb'));base=m['base'];scope=m['scope'];ITEMS=m['ITEMS'];NAMES=m['NAMES'];sens=m['sens'];BASE=m['BASE']
exec(open('chk/viol2.py').read().split("scope=[n")[0].split("d=pickle.load")[1].split("\n",1)[1]) if False else None
cls=lambda s:'высокая' if s>=6 else ('средняя' if s>=4 else 'низкая')
wb=Workbook();wb.remove(wb.active);hdr=PatternFill('solid',fgColor='D9D0C0');bold=Font(bold=True)
red=PatternFill('solid',fgColor='E8B4B8')
def sheet(name,head,rows,widths=None):
    ws=wb.create_sheet(name);ws.append(head)
    for c in ws[1]:c.font=bold;c.fill=hdr;c.alignment=Alignment(wrap_text=True,vertical='top')
    for r in rows:ws.append(r)
    for i in range(1,len(head)+1):ws.column_dimensions[get_column_letter(i)].width=(widths[i-1] if widths else 12)
    ws.freeze_panes='A2';return ws
rank={n:i+1 for i,n in enumerate(sorted(base,key=lambda n:-base[n][0]))}
rows=[]
for n in sorted(V):
    v=V[n];r=base.get(n)
    rows.append([n,'да' if r else 'нет','да' if v['is_anal'] else 'нет',v['pod']]+([int(r[1][it]) for it in ITEMS]+[r[0],cls(r[0]),rank[n]] if r else [None]*11+[None,None,None]))
ws=sheet('Сводный счёт',['Ячейка','В анализе (с подъездами)','В исходном анализе','Подъездов']+[f'{it} {NAMES[it]}' for it in ITEMS]+['Счёт (0–11)','Класс','Ранг'],rows,[8,12,12,10]+[16]*11+[9,10,7])
ws.row_dimensions[1].height=75
for row in ws.iter_rows(min_row=2):
    for c in row[4:15]:
        if c.value==1:c.fill=red
tot=[['Итого флагов','','','']+[sum(base[n][1][it] for n in base) for it in ITEMS]+[sum(r[0] for r in base.values()),'','']]
ws.append([]);ws.append(tot[0])
rows=[]
for n in sorted(V):
    v=V[n];rows.append([n,v['area'],v['pod'],v['score'],v['comfort'],v['vertical'],v['isolation'],v['planning'],v['ent_n'],v['ent_non'],v['wear40'],v['wear40_alt'],v['loading_m2'],v['danger_obj'],v['fav_closed'],v['combined_m'],v['transit_res_m'],v['biz_transit'],v['pg_out'],v['competition_m2'],v['unc_m2'],v['unc_pct'],v['unosv_pct']])
sheet('Показатели',['Ячейка','Площадь, м²','Подъездов','Балл комфорта','Комфорт','Вертикальные','Замкнутость','Размеры','Входов','Не организ. входов','Зданий ≥40 % (указанный/оценка)','то же, максимум из двух источников','Загрузка, м²','Опасных открытых объектов','Благоприятных закрытых','Совмещение потоков, м','Транзит в жилых зонах, м','Обсл. объектов с транзитом','Мест поведения вне контроля','Конкуренция, м²','Неконтролир., м²','Неконтролир., %','Неосвоен., %'],rows,[8]+[13]*22)
# чувствительность комфорта
rows=[]
for name,T,tot_,hi,flip,rho,comf in sens:
    if name.split(' ')[0] in('comfort_cut','vl','vh','vu','il','ih','size_T') or name=='базовые пороги': rows.append([name,comf,len(scope)-comf])
sheet('Чувствительность комфорта',['Порог','Комфортных ячеек (из 42 в анализе)','Некомфортных'],rows,[28,28,16])
ws=wb['Чувствительность комфорта'];ws.append([]);ws.append(['Расшифровка: vl, vh, vu — границы коэффициента вертикальных пропорций (низкий < vl; высокий vh…vu; ≥ vu — низкий); il, ih — границы коэффициента замкнутости; comfort_cut — порог балла (базовый 0,67); size_T — порог размера ячейки, м (по правилу «размер ≤ T», базовые классы взяты из таблицы команды).'])
rows=[[n,T and None] for n,T,*_ in []]
rows=[[name,tot_,hi,flip,rho,comf] for name,T,tot_,hi,flip,rho,comf in sens]
sheet('Чувствительность счёта',['Вариант порога','Сумма флагов','Ячеек класса «высокая»','Ячеек сменили класс','ρ Спирмена с базовым рангом','Комфортных ячеек'],rows,[28,14,16,16,18,16])
# устойчивость ячеек: min/max счёта по одиночным вариантам (по sens не хранится) — пересчёт
import importlib
src=open('chk/viol2.py').read().split("scope=[n")[0]
g={}
exec(src,g)
flags=g['flags'];scope_=scope
ranges={n:[base[n][0],base[n][0]] for n in scope_}
for name,T,*_ in sens:
    for n in scope_:
        s=sum(flags(n,T)[0].values());ranges[n][0]=min(ranges[n][0],s);ranges[n][1]=max(ranges[n][1],s)
sheet('Устойчивость ячеек',['Ячейка','Счёт (базовый)','Минимум по вариантам','Максимум по вариантам','Размах','Класс устойчив'],[[n,base[n][0],ranges[n][0],ranges[n][1],ranges[n][1]-ranges[n][0],'да' if len({cls(ranges[n][0]),cls(base[n][0]),cls(ranges[n][1])})==1 else 'нет'] for n in sorted(scope_)],[8,14,16,16,10,14])
pickle.dump(ranges,open('out10/ranges.pkl','wb'))
print('unstable',[n for n in scope_ if len({cls(ranges[n][0]),cls(base[n][0]),cls(ranges[n][1])})>1])
meth=[['Набор ячеек','is_anal = 1 или к ячейке выходят подъезды (entrances_buildings в пределах 8 м от ячейки). Добавлено 8 ячеек: 14, 15, 22, 28, 29, 39, 47, 51.'],
['1а','Балл комфорта ячейки < 0,67 (вертикальные пропорции + размеры + замкнутость, 0–2 каждый, среднее /2). Источник — таблицы команды (cells).'],
['1б','В 12 м от границы ячейки есть ≥1 не организованный вход (entries_territory.fix_class).'],
['1в','is_anal = 0: ячейка вне пространственно зафиксированных границ жилого образования (полоса вдоль улиц за фасадами).'],
['1г','Здание в 8 м от ячейки с износом ≥40 %: указанный (Степень изношенности), при его отсутствии — середина оценки команды. Источник и альтернатива (максимум двух значений) — в «Показатели».'],
['2а','Зоны загрузки в ячейке ≥50 м².'],
['2б','Опасный открытый объект в 6 м от ячейки: точки business (danger = опасный, isolation = открытый) и мусорные площадки (допущение: оценки нет, приняты опасными открытыми). Благоприятные закрытые объекты учтены как предпосылки (fav_closed), в счёт не входят.'],
['2в','Участки сети «по проезжей части» с высокой интенсивностью пешеходного или транспортного дерева ≥20 м в ячейке.'],
['3а','Только ячейки с подъездами: высокий транзит (пешеходный или транспортный) в зонах АЖ/ПЖ ≥20 м.'],
['3б','Обслуживающие объекты (business.function = обслуживающий) в 6 м от ячейки с высоким пешеходным транзитом в 15 м.'],
['3в','Места поведения ближней зоны вне АЖ и периферийной зоны вне ПЖ/ПП (playgrounds_zones: zone, control). Средняя зона заданием не оценивается.'],
['3г','Конкуренция АЖ∩АП ≥50 м² или неконтролируемая территория ≥50 % площади ячейки или неосвоенные участки ≥25 % площади участков.'],
['Счёт','Число нарушенных пунктов из 11. Классы: 0–3 низкая, 4–5 средняя, ≥6 высокая. Все флаги по порогам, пороги — в «Чувствительность счёта».'],
['Ограничения','Здания на границе двух ячеек учитываются в обеих. Влияние нарушений на контролируемость и освоенность (часть II занятия 4) — отдельной таблицей, здесь не считается. Пороги 2а, 2в, 3а, 3г заданы нами, в задании не определены.']]
sheet('Методика счёта',['Пункт','Правило'],meth,[16,150])
wb.save('out11/Сводный счёт нарушений, чувствительность v11.xlsx')
