# -*- coding: utf-8 -*-
import os,sqlite3,pickle,collections
SP='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/'
src=open(SP+'chk/gen_maps.py',encoding='utf-8').read().split("out=SP+'maps/'")[0]
exec(src)   # базовый список 28 карт (v11); ниже — замены по итогам аудита v12
F={'K':SP+'out12/konkovo_v12.gpkg','A':SP+'out12/analiz_v12.gpkg','P':SP+'out12/problems_v12.gpkg'}
fmt=lambda x:f'{x:,.0f}'.replace(',',' ')
byn={m['num']:i for i,m in enumerate(maps)}
def put(num,slug,title,sub,note,layers,slide):
    d=dict(num=num,slug=slug,title=title,sub=sub,note=note,layers=layers,slide=slide)
    if num in byn: maps[byn[num]]=d
    else: maps.append(d);byn[num]=len(maps)-1
# 15: новое имя слоя
m15=maps[byn['15']];m15['layers']=[x.replace("'p2c_combined'","'p2_3_combined'") for x in m15['layers']]
CELLNUM=L('P','viol_cells','Номера ячеек анализа','combo(single(fill(C["white"],0,C["black"],0)), labels("num", 7, C["grey"]))','"in_scope"=1')
CELLBG=L('P','viol_cells','Ячейка анализа','single(fill(C["white"],255,"#b8b2a7",0.2))','"in_scope"=1')
# ---------- 03 входы
SHAPE="CASE substr(\"podtip\",8) WHEN 'арка' THEN 'square' WHEN 'ворота' THEN 'diamond' WHEN 'калитка' THEN 'octagon' WHEN 'разрыв в застройке' THEN 'circle' WHEN 'въезд' THEN 'pentagon' WHEN 'разрыв в насаждениях' THEN 'hexagon' ELSE 'cross2' END"
ext=q('K',"select fix_class,count(*) from entries_territory where level='внешний' group by 1")
ec=dict(ext);nn=dict(q('K',"select fix_class,count(*) from entry_nodes where level='внешний' group by 1"))
put('03','входы_на_территорию','Входы на внутриквартальную территорию','Места входа с внешних территорий общего пользования и способ их пространственной фиксации',
 'Внешних входов %d: организовано %d, не организовано %d; внутренних проходов %d (в п. 1.2 не входят). Организован = фиксация высокая или средняя (арка, ворота, калитка, разрыв между фасадами, въезд между зданиями или со шлагбаумом). Узел = входы ближе 12 м; узел организован, только если организованы все его входы: %d из %d. В v12 16 въездов «только проезжая часть» переведены в неорганизованные.'%(
  ec.get('организован',0)+ec.get('не организован',0),ec.get('организован',0),ec.get('не организован',0),n('K',"select count(*) from entries_territory where level='внутренний'"),nn.get('организован',0),nn.get('организован',0)+nn.get('не организован',0)),
 BASE+[L('K','cells','Территория вне зафиксированных границ','single(fill("#ebe8e1"))','"is_anal"=0'),L('K','cells','Ячейки','CELL_LINES'),L('K','buildings','Здания','single(fill("#d3cabd"))'),
  L('K','fences','Ограждения','single(line("#8a7fb0",0.3))'),
  L('K','entries_territory','Способ фиксации входа','cats(\'substr("podtip",8)\', [%s])'%', '.join('("%s", mark("#8b877f",3.0,"%s"), "%s")'%(t,sh,t) for t,sh in [('арка','square'),('ворота','diamond'),('калитка','octagon'),('разрыв в застройке','circle'),('въезд','pentagon'),('разрыв в насаждениях','hexagon'),('не зафиксирован','cross2')]),'"level"=\'внешний\''),
  L('K','entries_territory','Организованность входа','cats(\'CASE WHEN "level"=\\\'внутренний\\\' THEN \\\'внутренний проход\\\' ELSE "fix_class" END\', [("организован", shape_dd(mark("#2a9d4b",3.0,"circle",C["white"]), %r), "организован"), ("не организован", shape_dd(mark("#d62828",3.0,"circle",C["white"]), %r), "не организован"), ("внутренний проход", shape_dd(mark("#b9b4ab",2.0,"circle",C["white"]), %r), "внутренний проход (не в п. 1.2)")])'%(SHAPE,SHAPE,SHAPE)),
  CELLNUM],'Границы, входы, ячейки')
# ---------- 22 освоенность
ar=dict(q('A',"select cls,round(sum(area)) from osvoennost group by 1"));tot=sum(ar.get(k,0) for k in ('освоенная','частично освоенная','неосвоенная'))
put('22','освоенность','Освоенность внутриквартальных территорий','Освоенная = благоустроена и используется; частично = одно из двух; неосвоенная (заброшенная) = ни того, ни другого',
 'Освоенная %s м² (%d %%), частично %s м² (%d %%), неосвоенная %s м² (%d %%). Благоустроено: площадка, газон/насаждения, иная поверхность ≥5 м (принята как покрытие); не благоустроено: откос (≥30 %% участка) или контур команды. Используется: наблюдение «много людей», площадка, ≥25 %% участка в 10 м от связи с ≥2 путями дерева или в 30 м от подъезда; «мало людей» — не используется. Не оцениваются полосы уже 5 м, участки школ и детсадов, территории вне ячеек анализа.'%(
  fmt(ar['освоенная']),round(100*ar['освоенная']/tot),fmt(ar['частично освоенная']),round(100*ar['частично освоенная']/tot),fmt(ar['неосвоенная']),round(100*ar['неосвоенная']/tot)),
 BASE+[L('A','osvoennost','Освоенность','cats(\'"cls"\', [("освоенная", fill(C["green"]), "освоенная"), ("частично освоенная", fill("#e9d68a"), "частично освоенная"), ("неосвоенная", fill(C["red"]), "неосвоенная (заброшенная)"), ("не оценивается", fill("#ece9e3"), "не оценивается")])'),
  L('K','buildings','Здания','single(fill("#d3cabd"))'),L('K','cells','Ячейки','CELL_LINES'),
  L('S','slopesandwalls','Откосы и подпорные стенки','single(line(C["black"],0.4,"dot"))'),
  L('K','people_dens','Наблюдения команды','cats(\'"dens"\', [("много", fill(C["white"],0,"#4a74c9",0.6,"dash"), "много людей (используется)"), ("мало", fill(C["white"],0,C["black"],0.6,"dash"), "мало людей (не используется)")])'),
  L('K','osv_manual','Неосвоенная, контур команды','single(fill(C["red"],0,C["red"],0.8))'),CELLNUM],'Контроль и освоенность')
# ---------- 23 контроль × освоенность
put('23','контроль_и_неосвоенность','Контролируемость × освоенность','Где неконтролируемые территории совпадают с неосвоенными; где освоенное контролируется',
 'Освоенные и контролируемые участки (предпосылка): %s м². Неосвоенные в ячейках анализа: %s м², неконтролируемые (без неосвоенных): %s м², конкуренция контролей: %s м².'%(fmt(n('P','select sum(area) from pre_osv_ctl')),fmt(n('P','select sum(area) from p3_4_abandoned')),fmt(n('P','select sum(area) from p3_4_uncontrolled')),fmt(n('P','select sum(area) from p3_4_competition'))),
 BASE+[CELLBG,L('P','pre_osv_ctl','Освоенная и контролируемая','single(fill(C["green"],200))'),L('P','p3_4_uncontrolled','Неконтролируемая','single(hatch(C["red"],160,"f_diagonal"))'),
  L('P','p3_4_competition','Конкуренция контролей','single(fill(C["pink"],190))'),L('P','p3_4_abandoned','Неосвоенная (заброшенная)','single(fill(C["red"],230))'),
  L('K','buildings','Здания','single(fill("#d3cabd"))'),CELLNUM],'Контроль и освоенность')
# ---------- общие слои проблем
PL=dict(
 p11=L('P','p1_1_cells','1.1 ячейка: размеры, пропорции, фиксация границ (балл < 0,67)','single(fill(C["white"],0,"#1f6f78",0.6,"dash"))'),
 p12=L('P','p1_2_nodes','1.2 неорганизованный узел входа','single(mark("#d62828",3.6,"triangle",C["white"]))'),
 p13=L('P','p1_3_cells','1.3 территория вне зафиксированных границ','single(hatch("#a09a8f",255,"b_diagonal"))'),
 p13f=L('P','p1_3_cells','1.3 (фон)','single(fill("#e7e4dd"))'),
 p14=L('P','p1_4_wear','1.4 здание с износом ≥ 40 %','single(fill(C["dark"]))'),
 p21=L('P','p2_1_loading','2.1 зона загрузки с заездом грузового транспорта','single(fill(C["purple"]))'),
 p22=L('P','p2_2_objects','2.2 опасный открытый объект','single(mark(C["black"],3.0,"cross2",C["white"]))'),
 p23=L('P','p2_3_combined','2.3 совмещение транзитных пешеходных и транспортных потоков','single(line(C["orange"],1.1))'),
 p31=L('P','p3_1_transit','3.1 транзит через придомовую территорию','single(line("#7a1f27",0.5,"dash"))'),
 p32=L('P','p3_2_service','3.2 территория обслуживающих объектов с внешним транзитом','single(fill("#c9d6f2",255,"#4a74c9",0.3))'),
 p33=L('P','p3_3_places','3.3 место поведения вне зоны контроля','single(fill(C["yellow"],255,C["black"],0.35))'),
 p34c=L('P','p3_4_competition','3.4 конкуренция активного публичного и персонального контроля','single(fill(C["pink"],190))'),
 p34u=L('P','p3_4_uncontrolled','3.4 неконтролируемая территория','single(hatch(C["red"],150,"f_diagonal"))'),
 p34a=L('P','p3_4_abandoned','3.4 заброшенная (неосвоенная) территория','single(fill(C["red"],230))'))
BLDL=L('K','buildings','Здания','single(fill("#d3cabd"))')
m2=pickle.load(open(SP+'out12/viol2_12.pkl','rb'));BS=m2['base'];cnt={i:sum(r[1][i] for r in BS.values()) for i in m2['ITEMS']}
put('24','проблемы_группа_1','Проблемы 1: пространственно-планировочные','Занятие 4, п. 1.1–1.4',
 '1.1: %d ячеек (балл комфорта < 0,67). 1.2: %d неорганизованных узлов, %d ячеек. 1.3: %d ячеек вне зафиксированных границ (в счёте %d с подъездами). 1.4: %d зданий с износом ≥ 40 %%.'%(cnt['1.1'],n('P','select count(*) from p1_2_nodes'),cnt['1.2'],n('P','select count(*) from p1_3_cells'),cnt['1.3'],n('P','select count(*) from p1_4_wear')),
 BASE+[CELLBG,PL['p13f'],PL['p13'],BLDL,PL['p14'],PL['p11'],PL['p12'],CELLNUM],'Проблемы: группа 1')
put('25','проблемы_группа_2','Проблемы 2: функционально-планировочные','Занятие 4, п. 2.1–2.3',
 '2.1: %d зон загрузки (%s м²), %d ячеек. 2.2: %d опасных открытых объектов (из них %d мусорных площадок — допущение), %d ячеек. 2.3: %s м участков проездов с совмещением транзитных потоков, %d ячеек.'%(n('P','select count(*) from p2_1_loading'),fmt(n('P','select sum(area) from p2_1_loading')),cnt['2.1'],n('P','select count(*) from p2_2_objects'),n('P',"select count(*) from p2_2_objects where src='garbage'"),cnt['2.2'],fmt(n('P','select sum(length) from p2_3_combined')),cnt['2.3']),
 BASE+[CELLBG,BLDL,PL['p21'],PL['p23'],PL['p22'],CELLNUM],'Проблемы: группа 2')
put('26','проблемы_группа_3','Проблемы 3: социально-планировочные','Занятие 4, п. 3.1–3.4',
 '3.1: %s м высокого транзита в зонах АЖ/ПЖ, %d ячеек с подъездами. 3.2: %d обслуживающих объектов с внешним транзитом. 3.3: %d место поведения вне зоны контроля. 3.4: конкуренция %s м², неконтролируемые %s м², заброшенные %s м²; %d ячеек.'%(fmt(n('P','select sum(length) from p3_1_transit')),cnt['3.1'],n('P','select count(*) from p3_2_objects'),n('P','select count(*) from p3_3_places'),fmt(n('P','select sum(area) from p3_4_competition')),fmt(n('P','select sum(area) from p3_4_uncontrolled')),fmt(n('P','select sum(area) from p3_4_abandoned')),cnt['3.4']),
 BASE+[CELLBG,PL['p34u'],PL['p34c'],PL['p34a'],PL['p32'],BLDL,PL['p33'],PL['p31'],CELLNUM],'Проблемы: группа 3')
cl=collections.Counter(r[0]>=6 and 'в' or (r[0]>=4 and 'с' or 'н') for r in BS.values())
top=sorted(((r[0],k) for k,r in BS.items()),reverse=True)
put('27','сводный_счёт','Сводный счёт нарушений по ячейкам','Число нарушенных пунктов из 11 на ячейку анализа; подпись — номер / счёт',
 'Классы: 0–3 низкий (%d), 4–5 средний (%d), ≥ 6 высокий (%d). Наибольший счёт: %s.'%(cl['н'],cl['с'],cl['в'],', '.join('№%d — %d'%(k,s) for s,k in top if s>=6)),
 BASE+[L('P','viol_cells','Счёт нарушений','cats(\'CASE WHEN "in_scope"=0 THEN \\\'вне анализа\\\' ELSE "cls" END\', [("высокая", fill(C["red"],210), "высокий (≥ 6)"), ("средняя", fill(C["yellow"],200), "средний (4–5)"), ("низкая", fill(C["green"],190), "низкий (0–3)"), ("вне анализа", fill(C["beige"],200), "вне анализа")])'),
  BLDL,L('P','viol_cells','Номер / счёт','combo(single(fill(C["white"],0,C["black"],0.3)), labels("CASE WHEN \\"in_scope\\"=1 THEN \\"num\\"||\\\' / \\\'||\\"score\\" END", 8, expr=True))')],'Сводный счёт и чувствительность')
put('28','финальная_схема_проблем','Проблемы планировочной организации придомовых территорий','Занятие 4, I: нарушения по трём блокам (1 — пространственные, 2 — функциональные, 3 — социальные)',
 'Наибольшая концентрация нарушений (≥ 6 из 11): ячейки %s. Предпосылки — отдельной картой 29.'%', '.join('%d (%d)'%(k,s) for s,k in top if s>=6),
 BASE+[CELLBG,PL['p13f'],PL['p13'],PL['p34u'],PL['p34c'],PL['p34a'],PL['p32'],PL['p21'],BLDL,PL['p14'],PL['p33'],PL['p11'],PL['p23'],PL['p31'],PL['p22'],PL['p12'],CELLNUM],'Итог: финальная схема проблем')
put('29','предпосылки','Предпосылки развития планировочной организации','Занятие 4, I: на что можно опереться при реорганизации придомовых территорий',
 'Комфортных ячеек %d; освоенные и контролируемые участки %s м²; организованных узлов входа %d; благоприятных закрытых объектов %d.'%(n('P','select count(*) from pre_comfort_cells'),fmt(n('P','select sum(area) from pre_osv_ctl')),n('P','select count(*) from pre_nodes'),n('P','select count(*) from pre_fav_closed')),
 BASE+[CELLBG,L('P','pre_comfort_cells','Комфортная ячейка (балл ≥ 0,67)','single(fill("#e6f2df",255,"#b8b2a7",0.2))'),L('P','pre_osv_ctl','Освоенная и контролируемая территория','single(fill(C["green"],215))'),BLDL,
  L('P','pre_axes','Пешеходная ось с высокой интенсивностью','single(line("#1d6b3a",0.5,"dash"))'),L('P','pre_fav_closed','Благоприятный закрытый объект','single(ring("#1d6b3a",3.0,0.5))'),
  L('P','pre_nodes','Организованный узел входа','single(mark("#2a9d4b",3.4,"triangle",C["white"]))'),CELLNUM],'Предпосылки')
maps.sort(key=lambda m:m['num'])
out=SP+'maps12/'; os.makedirs(out,exist_ok=True)
for f_ in os.listdir(out):
    if f_.endswith('.py'): os.remove(out+f_)
tpl=open(SP+'chk/prelude.py',encoding='utf-8').read()
def esc(s): return s.replace('\\','\\\\').replace('"','\\"')
for m in maps:
    s=tpl
    for k,v in (('@@NUM@@',m['num']),('@@TITLE@@',esc(m['title'])),('@@SUBTITLE@@',esc(m['sub'])),('@@SCALE@@','3000'),('@@NOTE@@',m['note'].replace('"""',"'''"))):
        s=s.replace(k,v)
    s=s.replace('@@LAYERS@@','\n'.join(m['layers']))
    open(out+'%s_%s.py'%(m['num'],m['slug']),'w',encoding='utf-8').write(s)
import json; json.dump(maps,open(SP+'maps_meta12.json','w'),ensure_ascii=False,indent=1)
print(len(maps),'скриптов')
