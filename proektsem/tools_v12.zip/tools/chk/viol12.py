import sys,pickle,collections,cv2,re;sys.path.insert(0,'lib')
import gp,io9,rb,numpy as np
from scipy import ndimage as ndi
K='out12/konkovo_v12.gpkg';A='out12/analiz_v12.gpkg'
cells=io9.load(K,'cells')[2]
allp=np.vstack([np.array(p[0]) for g,a in cells for p in gp.polys(g)])
x0,y0=allp.min(0)-15;x1,y1=allp.max(0)+15;R=0.5
W=rb.Win(x0,y0,x1,y1,R)
CL=np.zeros((W.h,W.w),np.int16)
for g,a in cells:
    for p in gp.polys(g): W.fill(CL,[np.array(p[0])],a['num'],holes=[np.array(h) for h in p[1:]])
def mask(layer,src,filt=None):
    m=W.blank()
    for g,a in io9.load(src,layer)[2]:
        if filt and not filt(a):continue
        for p in gp.polys(g): W.fill(m,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
    return m
def labels_near(pt,r):
    px=int((pt[0]-x0)/R);py=int((pt[1]-y0)/R);k=int(r/R)
    sub=CL[max(py-k,0):py+k+1,max(px-k,0):px+k+1]
    yy,xx=np.ogrid[:sub.shape[0],:sub.shape[1]]
    cy=py-max(py-k,0);cx=px-max(px-k,0)
    d=(yy-cy)**2+(xx-cx)**2<=k*k
    return set(np.unique(sub[d]).tolist())-{0}
def label_at(pt):
    px=int((pt[0]-x0)/R);py=int((pt[1]-y0)/R);return int(CL[py,px]) if 0<=py<W.h and 0<=px<W.w else 0
def line_len_by_cell(l,step=1.0):
    l=np.array(l);L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))]
    s=np.arange(0,L[-1],step)+step/2
    if len(s)==0: return {}
    P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])]
    out=collections.Counter()
    for p in P: out[label_at(p)]+=step
    out.pop(0,None);return out
def area_by_cell(m):
    c=collections.Counter()
    v,n=np.unique(CL[m>0],return_counts=True)
    return {int(a):float(b)*R*R for a,b in zip(v,n) if a}
num=[a['num'] for g,a in cells]
V={n:{} for n in num}
for g,a in cells: V[a['num']].update(is_anal=a['is_anal'],area=a['area'],score=a['score'],comfort=a['comfort'],vertical=a['vertical'],isolation=a['isolation'],planning=a['planning'],vert_koef=a['vert_koef'],iso_koef=a['iso_koef'],size=a['size'])
# подъезды
ent=io9.load(K,'entrances_buildings')[2]
pod=collections.Counter()
for g,a in ent:
    for c in labels_near(g[1],8): pod[c]+=1
for n in num: V[n]['pod']=pod.get(n,0)
# входы
oc=io9.load(A,'osv_cells')[2]
for g,a in oc: V[a['num']].update(ent_n=a['nodes_n'],ent_non=a['nodes_non'],unosv_m2=a['unosv_m2'],parcels_area=a['assessed_m2'],unosv_pct=a['unosv_pct'],loading_m2=a['loading_m2'])
# износ зданий
def wear(a):
    off=a['Степень изношенности']
    est=a['Наша оценка изношенности']
    mid=None
    if est:
        m=re.findall(r'\d+',est); mid=np.mean([int(x) for x in m])/100 if m else None
    return off,mid
bw=[]
for g,a in io9.load(K,'buildings')[2]:
    off,mid=wear(a)
    if off is None and mid is None: continue
    w_main=off if off is not None else mid
    ring=np.array(gp.polys(g)[0][0]);bm=W.blank();W.fill(bm,[ring],1)
    bm=cv2.dilate(bm,np.ones((int(2*8/R)+1,)*2,np.uint8))
    lbs=set(np.unique(CL[bm>0]).tolist())-{0}
    bw.append(dict(id=a['id'],addr=a['Адрес / ориентир'],off=off,est=mid,w=w_main,w_hi=max([x for x in (off,mid) if x is not None]),cells=lbs))
for n in num: V[n]['wear40']=sum(1 for b in bw if b['w']>=0.40 and n in b['cells']);V[n]['wear40_alt']=sum(1 for b in bw if b['w_hi']>=0.40 and n in b['cells'])
# погрузка: площадь по ячейкам уже; опасные объекты
objs=[]
for g,a in io9.load(K,'business')[2]:
    if a['danger']=='опасный' and a['isolation']=='открытый': objs.append(('business',a['label'],g[1],'опасный открытый'))
for g,a in io9.load(K,'garbage')[2]: objs.append(('garbage','мусорная площадка',g[1],'опасный открытый (допущение)'))
fav=[]
for g,a in io9.load(K,'business')[2]:
    if a['danger']=='благоприятный' and a['isolation']=='закрытый': fav.append((a['label'],g[1]))
for g,a in io9.load(K,'playgrounds')[2]:
    if a['danger']=='благоприятный' and a['isolation']=='закрытый':
        c=np.array(gp.polys(g)[0][0]).mean(0); fav.append(('площадка '+a['type'],c))
for n in num: V[n]['danger_obj']=0;V[n]['fav_closed']=0
for t,nm,pt,kind in objs:
    for c in labels_near(pt,6): V[c]['danger_obj']+=1
for nm,pt in fav:
    for c in labels_near(pt,6): V[c]['fav_closed']+=1
# 2в совмещение
net=io9.load(A,'network')[2]
comb=collections.Counter();comb_edges=[]
for g,a in net:
    if a['razdel']=='по проезжей части' and (a['group']=='высокая' or a['vgroup']=='высокая'):
        comb_edges.append((g,a))
        for l in gp.lines(g):
            for c,v in line_len_by_cell(l).items(): comb[c]+=v
for n in num: V[n]['combined_m']=round(comb.get(n,0))
# зоны контроля
AJ=mask('control_zones',A,lambda a:a['type']=='АЖ');PJ=mask('control_zones',A,lambda a:a['type']=='ПЖ');AP=mask('control_zones',A,lambda a:a['type']=='АП');PP=mask('control_zones',A,lambda a:a['type']=='ПП')
PERS=((AJ>0)|(PJ>0)).astype(np.uint8)
UNC=mask('control',A,lambda a:a['type']=='неконтролируемая')
COMP=mask('competition',A)
unc=area_by_cell(UNC);comp=area_by_cell(COMP)
# 3а транзит в личных зонах
tr=io9.load(A,'transit')[2];t3=collections.Counter();t3_lines=[]
for g,a in tr:
    if a['cls']!='высокая':continue
    for l in gp.lines(g):
        l=np.array(l);L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))];s=np.arange(0.5,L[-1],1.0)
        if not len(s):continue
        P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])]
        for p in P:
            px=int((p[0]-x0)/R);py=int((p[1]-y0)/R)
            if PERS[py,px] and CL[py,px]: t3[int(CL[py,px])]+=1.0
for n in num: V[n]['transit_res_m']=round(t3.get(n,0))
# 3б
hi_ped=[np.array(l) for g,a in tr if a['cls']=='высокая' and a['mode']=='пешеходный' for l in gp.lines(g)]
def dline(p,lines):
    best=1e9
    for l in lines:
        v=l[1:]-l[:-1];L2=(v**2).sum(1)+1e-12;t=np.clip(((p-l[:-1])*v).sum(1)/L2,0,1);Q=l[:-1]+t[:,None]*v;best=min(best,np.hypot(*(Q-p).T).min())
    return best
biz3=[]
for n in num: V[n]['biz_transit']=0
for g,a in io9.load(K,'business')[2]:
    if a['function']!='обслуживающий': continue
    p=np.array(g[1])
    if dline(p,hi_ped)<=15:
        biz3.append((a['label'],p))
        for c in labels_near(p,6): V[c]['biz_transit']+=1
# 3в площадки
pz=io9.load(A,'playgrounds_zones')[2];pg3=[]
for n in num: V[n]['pg_out']=0
for g,a in pz:
    ps=gp.polys(g);m=W.blank()
    for p in ps: W.fill(m,[np.array(p[0])],1)
    ys,xs=np.nonzero(m)
    if not len(ys): continue
    if a['zone']=='ближняя' and a['control']!='контролируемая' or a['zone']=='периферийная':
        pg3.append((g,a));lab=np.bincount(CL[ys,xs]);lab[0]=0
        if lab.sum(): V[int(lab.argmax())]['pg_out']+=1
# 3г
for n in num:
    v=V[n];v['competition_m2']=round(comp.get(n,0));v['unc_m2']=round(unc.get(n,0));v['unc_pct']=round(100*unc.get(n,0)/v['area'],1) if v['area'] else 0;v['comp_pct']=round(100*comp.get(n,0)/v['area'],1) if v['area'] else 0
pickle.dump(dict(V=V,bw=bw,objs=objs,fav=fav,biz3=biz3,pg3=pg3,comb_edges=comb_edges),open('out12/viol12.pkl','wb'))
print(len(bw),[ (b['id'],b['off'],b['est']) for b in bw if b['w']>=0.4][:30])
print('pod cells',sorted(n for n in num if V[n]['pod']>0), 'is_anal=0 with pod',[n for n in num if V[n]['pod']>0 and not V[n]['is_anal']])
print('objs',objs,'fav',len(fav),'biz3',len(biz3),'pg3',len(pg3),'comb edges',len(comb_edges))
