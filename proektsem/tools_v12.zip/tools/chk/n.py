import sys; sys.path.insert(0,'lib')
import dxf, gp, xf, msk, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MP
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
L={'AVTOSTOYANKI':'#2a9d8f','ZDANIYA':'#a39279','PROEZDY':'#777','ULICY_PROEZZH_CHAST':'#222','DOR_DOROZHKA':'#c9a','ПЕШЕХОДНЫЕ_ДОРОЖКИ':'#e0a','OGRAZHDENIYA':'#b13840','PL_DETSKAYA':'#d9c35b'}
E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf',layers=set(L))
x0,x1,y0,y1=407480,407800,6167040,6167320
fig,ax=plt.subplots(figsize=(16,9))
for e in E:
    P=np.array(e['pts'])
    if len(P)<2: continue
    Q=np.array(xf.cad2utm(P))
    if Q[:,0].max()<x0 or Q[:,0].min()>x1: continue
    ax.plot(Q[:,0],Q[:,1],c=L[e['layer']],lw=.8)
for r in gp.read(U+'fc0568b7-competitions_2.gpkg'):
    for p in gp.polys(r['_g']): ax.add_patch(MP(np.array(p[0]),fc='#b13840',alpha=.3,ec='r'))
bz=gp.read(U+'92246443-business_2.gpkg')
for r in bz:
    e,n=msk.utm37(np.array(r['_g'][1][0]),np.array(r['_g'][1][1])); ax.plot(e+5,n+9.5,'k.',ms=4)
ax.set_xlim(x0,x1);ax.set_ylim(y0,y1);ax.set_aspect('equal');plt.savefig('chk/zoom1.png',dpi=90,bbox_inches='tight')
