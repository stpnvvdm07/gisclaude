import numpy as np,collections
def dens(parts,step=2.0,close=False):
    out=[]
    for p in parts:
        p=list(p)
        if len(p)<2: continue
        if close and tuple(p[0])!=tuple(p[-1]): p=p+[p[0]]
        for i in range(len(p)-1):
            a=np.array(p[i],float);b=np.array(p[i+1],float);L=np.linalg.norm(b-a);n=max(1,int(L/step))
            out.append(a+(b-a)*np.linspace(0,1,n,endpoint=False)[:,None])
    return np.vstack(out) if out else np.zeros((0,2))
class NN:
    def __init__(s,B,cell=12.0):
        s.B=np.asarray(B,float); s.c=cell; g=collections.defaultdict(list)
        for i,(x,y) in enumerate(s.B): g[(int(x//cell),int(y//cell))].append(i)
        s.g={k:np.array(v) for k,v in g.items()}
    def q(s,A):
        A=np.asarray(A,float).reshape(-1,2); j=np.full(len(A),-1); d=np.full(len(A),1e9)
        for i,(x,y) in enumerate(A):
            kx,ky=int(x//s.c),int(y//s.c); cand=[s.g[k] for k in ((kx+a,ky+b) for a in(-1,0,1) for b in(-1,0,1)) if k in s.g]
            if not cand: continue
            cand=np.concatenate(cand); dd=np.hypot(s.B[cand,0]-x,s.B[cand,1]-y); m=dd.argmin(); j[i]=cand[m]; d[i]=dd[m]
        return j,d
