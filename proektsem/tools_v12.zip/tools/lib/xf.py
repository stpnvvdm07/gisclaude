import numpy as np,sys,os
sys.path.insert(0,os.path.dirname(__file__)); import msk
X0,Y0=12.268,11.964
def cad2utm(P):
    P=np.asarray(P,float).reshape(-1,2); e,n=msk.msk2utm(P[:,0]-X0,P[:,1]-Y0); return np.c_[e,n]
def utm2cad(P):
    P=np.asarray(P,float).reshape(-1,2); x,y=msk.utm2msk(P[:,0],P[:,1]); return np.c_[x+X0,y+Y0]
PROJ=f"+proj=tmerc +lat_0=55.66666666667 +lon_0=37.5 +k=1 +x_0={X0:.3f} +y_0={Y0:.3f} +ellps=bessel +towgs84=316.151,78.924,589.65,-1.57273,2.69209,2.34693,8.4507 +units=m +no_defs"
