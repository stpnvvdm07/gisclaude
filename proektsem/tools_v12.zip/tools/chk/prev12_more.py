exec(open('chk/plot12.py').read())
import pickle,collections,sqlite3
m=pickle.load(open('out12/viol2_12.pkl','rb'));BS=m['base'];scope=set(m['scope'])
fmt=lambda x:f'{x:,.0f}'.replace(',',' ')
# ================= 03 входы
fig,ax,lg=sheet('Входы на внутриквартальную территорию','Занятие 1, I.2: места входа с внешних территорий общего пользования и способ их пространственной фиксации')
cells=basemap(ax)
polys(ax,[r for r in cells if r['is_anal']==0],'#ebe8e1',z=1.2)
lines(ax,gp.read(K,'fences'),'#8a7fb0',.7,8)
lines(ax,gp.read(K,'arches'),'#16161c',.8,8)
E=gp.read(K,'entries_territory')
SH={'арка':'s','ворота':'D','калитка':'d','разрыв в застройке':'o','въезд':'p','разрыв в насаждениях':'h','не зафиксирован':'X'}
CO={'организован':'#2a9d4b','не организован':'#d62828'}
for r in E:
    t=r['podtip'][7:];q=T([r['_g'][1]])[0]
    if r['level']=='внутренний':
        ax.scatter(*q,s=34,marker=SH[t],c='#b9b4ab',edgecolors='white',linewidths=.6,zorder=14)
    else:
        ax.scatter(*q,s=70,marker=SH[t],c=CO[r['fix_class']],edgecolors='white',linewidths=.9,zorder=15)
labels(ax,cells,which=scope,fs=6.5)
frame(ax);scalebar(fig,ax)
ext=[r for r in E if r['level']=='внешний'];cnt=collections.Counter((r['podtip'][7:],r['fix_class']) for r in ext)
L=Legend(lg)
L.head('Способ фиксации входа (форма знака)')
order=['арка','ворота','калитка','разрыв в застройке','въезд','разрыв в насаждениях','не зафиксирован']
for t in order:
    o=cnt[(t,'организован')];n=cnt[(t,'не организован')]
    L.item('mark',f'{t} — {o+n}'+(f' (орг. {o}, неорг. {n})' if o and n else ''),m=SH[t],s=70,c='#8b877f',ec='white')
L.head('Организованность (цвет знака)')
L.item('mark',f"организован — {sum(1 for r in ext if r['fix_class']=='организован')}\nфиксация высокая или средняя: арка, ворота,\nкалитка, разрыв между фасадами\n(здания с двух сторон), въезд между\nзданиями или со шлагбаумом",m='o',s=70,c=CO['организован'],ec='white')
L.item('mark',f"не организован — {sum(1 for r in ext if r['fix_class']=='не организован')}\nвход «с любой стороны»: въезд только\nпроезжей частью, разрыв в насаждениях,\nвход без фиксации",m='o',s=70,c=CO['не организован'],ec='white')
L.item('mark',f"внутренний проход — {sum(1 for r in E if r['level']=='внутренний')}\n(глубже 20 м от внешней границы\nтерритории, в п. 1.2 не входит)",m='o',s=34,c='#b9b4ab',ec='white')
L.head('Основа')
L.item('line','ограждение',c='#8a7fb0',lw=1)
L.item('fill','территория вне зафиксированных границ',fc='#ebe8e1')
nodes=gp.read(K,'entry_nodes');ne=[r for r in nodes if r['level']=='внешний']
L.note(f"Узел входа = входы ближе 12 м друг к другу\n(одно место). Внешних узлов {len(ne)}: организовано\n{sum(1 for r in ne if r['fix_class']=='организован')}, не организовано {sum(1 for r in ne if r['fix_class']!='организован')} (узел организован, только\nесли организованы все его входы).\nИсправлено в v12: 16 въездов «только проезжая\nчасть» переведены в неорганизованные.")
bx=fig.add_axes([0.13,0.075,0.57,0.19]);
lab=[t for t in order];o=[cnt[(t,'организован')] for t in lab];n=[cnt[(t,'не организован')] for t in lab]
y=np.arange(len(lab))[::-1]
bx.barh(y,o,color=CO['организован'],height=.62);bx.barh(y,n,left=o,color=CO['не организован'],height=.62)
for yy,a_,b_ in zip(y,o,n): bx.text(a_+b_+0.3,yy,str(a_+b_),va='center',fontsize=8.5)
bx.set_yticks(y);bx.set_yticklabels(lab,fontsize=8.5);bx.tick_params(axis='x',labelsize=8);bx.xaxis.get_major_locator().set_params(integer=True);bx.spines[['top','right']].set_visible(False)
bx.set_title('Внешние входы по способу фиксации (зелёный — организован, красный — нет)',fontsize=10,loc='left',fontweight='semibold')
foot(fig);fig.savefig('out12/prev/03_входы.png',dpi=110);plt.close(fig)

# ================= 22 освоенность
fig,ax,lg=sheet('Освоенность внутриквартальных территорий','Занятие 3, II.2: освоенная = благоустроена и используется; частично освоенная = одно из двух; неосвоенная (заброшенная) = ни того, ни другого')
cells=basemap(ax)
O=gp.read(A,'osvoennost')
OC={'освоенная':COL['green'],'частично освоенная':'#e9d68a','неосвоенная':COL['red'],'не оценивается':'#ece9e3'}
for k,c in OC.items(): polys(ax,[r for r in O if r['cls']==k],c,z=2)
outline(ax,[r for r in gp.read(K,'people_dens') if r['dens']=='много'],COL['blue'],1.6,12,ls=(0,(5,2)))
outline(ax,[r for r in gp.read(K,'people_dens') if r['dens']=='мало'],'#16161c',1.6,12,ls=(0,(5,2)))
outline(ax,gp.read(K,'osv_manual'),COL['red'],2.0,12)
lines(ax,gp.read(S,'slopesandwalls'),'#16161c',1.0,12,ls=(0,(1,1.5)))
labels(ax,cells,which=scope,fs=6.5)
frame(ax);scalebar(fig,ax)
ar=collections.Counter();
for r in O: ar[r['cls']]+=r['area']
tot=ar['освоенная']+ar['частично освоенная']+ar['неосвоенная']
L=Legend(lg);L.head('Освоенность (ячейки анализа)')
for k in ('освоенная','частично освоенная','неосвоенная'):
    L.item('fill',f"{k} — {fmt(ar[k])} м² ({100*ar[k]/tot:.0f} %)",fc=OC[k])
L.item('fill','не оценивается: полосы уже 5 м, участки\nшкол и детсадов, территории вне ячеек анализа',fc=OC['не оценивается'])
L.head('Наблюдения команды')
L.item('fill','много людей (участки считаются используемыми)',fc='none',ec=COL['blue'],lw=1.6,ls=(0,(5,2)))
L.item('fill','мало людей (участки считаются неиспользуемыми)',fc='none',ec='#16161c',lw=1.6,ls=(0,(5,2)))
L.item('fill','неосвоенная территория, контур команды',fc='none',ec=COL['red'],lw=2)
L.item('line','откос, подпорная стенка',c='#16161c',lw=1.0,ls=(0,(1,1.5)))
L.head('Правила')
L.note('Благоустроено: площадка, газон или насаждения,\nиная поверхность шириной ≥ 5 м (принята как\nпокрытие). Не благоустроено: откос (≥ 30 %\nплощади участка) или контур команды.\nИспользуется: наблюдение «много людей»;\nплощадка (место поведения); ≥ 25 % участка\nв 10 м от пешеходной связи с ≥ 2 путями дерева;\n≥ 25 % участка в 30 м от подъезда.')
bx=fig.add_axes([0.03,0.07,0.33,0.2]);bx.axis('off');bx.set_xlim(0,1);bx.set_ylim(0,1)
bx.text(0,1,'Матрица: благоустройство × использование, м²',fontsize=10,fontweight='semibold',va='top')
mat=collections.Counter()
for r in O:
    if r['cls']=='не оценивается':continue
    mat[(r['B'],r['U'])]+=r['area']
cellc={(1,1):COL['green'],(1,0):'#e9d68a',(0,1):'#e9d68a',(0,0):COL['red']}
nm={(1,1):'освоенная',(1,0):'частично',(0,1):'частично',(0,0):'неосвоенная'}
for i,b in enumerate((1,0)):
    for j,u in enumerate((1,0)):
        x=0.3+j*0.34;y=0.52-i*0.36
        bx.add_patch(mp.Rectangle((x,y),0.32,0.32,fc=cellc[(b,u)],ec='white'))
        bx.text(x+0.16,y+0.2,fmt(mat[(b,u)]),ha='center',fontsize=11,fontweight='semibold',color='white' if (b,u)==(0,0) else '#16161c')
        bx.text(x+0.16,y+0.08,nm[(b,u)],ha='center',fontsize=8,color='white' if (b,u)==(0,0) else '#16161c')
bx.text(0.46,0.88,'используется',ha='center',fontsize=8.5);bx.text(0.80,0.88,'не используется',ha='center',fontsize=8.5)
bx.text(0.28,0.68,'благоустроено',ha='right',fontsize=8.5);bx.text(0.28,0.32,'не благоустроено',ha='right',fontsize=8.5)
cx=fig.add_axes([0.53,0.085,0.20,0.17])
why=collections.Counter()
for r in O:
    if r['cls']!='не оценивается': why[r['U_why']]+=r['area']
ks=[k for k,_ in why.most_common()];vals=[why[k]/1000 for k in ks]
cx.barh(np.arange(len(ks))[::-1],vals,color=['#8ed0ad' if 'нет' not in k and 'мало' not in k else '#cfc6b8' for k in ks],height=.6)
cx.set_yticks(np.arange(len(ks))[::-1]);cx.set_yticklabels(ks,fontsize=8);cx.tick_params(axis='x',labelsize=8);cx.spines[['top','right']].set_visible(False)
cx.set_xlabel('тыс. м²',fontsize=8);cx.set_title('Основание признака «используется»',fontsize=10,loc='left',fontweight='semibold')
foot(fig);fig.savefig('out12/prev/22_освоенность.png',dpi=110);plt.close(fig)

# ================= 29 предпосылки
fig,ax,lg=sheet('Предпосылки развития планировочной организации','Занятие 4, I: на что можно опереться при реорганизации придомовых территорий')
cells=basemap(ax)
polys(ax,gp.read(P,'pre_comfort_cells'),'#e6f2df',z=1.3)
polys(ax,gp.read(P,'pre_osv_ctl'),COL['green'],z=2,al=.85)
lines(ax,gp.read(P,'pre_axes'),'#1d6b3a',1.6,10,ls=(0,(4,2)))
pts(ax,gp.read(P,'pre_fav_closed'),s=48,marker='o',c='white',edgecolors='#1d6b3a',linewidths=1.6,zorder=13)
pts(ax,gp.read(P,'pre_nodes'),s=90,marker='^',c='#2a9d4b',edgecolors='white',linewidths=1,zorder=14)
labels(ax,cells,which=scope,fs=6.5)
frame(ax);scalebar(fig,ax)
con=sqlite3.connect('file:'+P+'?immutable=1',uri=True);q=lambda s_:con.execute(s_).fetchone()[0]
L=Legend(lg);L.head('Предпосылки')
L.item('fill',f"комфортная ячейка (балл ≥ 0,67) — {q('select count(*) from pre_comfort_cells')}",fc='#e6f2df',ec='#b8b2a7',lw=.6)
L.item('fill',f"освоенная и контролируемая территория —\n{fmt(q('select sum(area) from pre_osv_ctl'))} м²",fc=COL['green'],al=.85)
L.item('mark',f"организованный узел входа — {q('select count(*) from pre_nodes')}",m='^',s=90,c='#2a9d4b',ec='white')
L.item('mark',f"благоприятный закрытый объект — {q('select count(*) from pre_fav_closed')}\n(не воздействует на жильё)",m='o',s=48,c='white',ec='#1d6b3a',lw=1.6)
L.item('line','пешеходная ось с высокой интенсивностью\n(каркас для общественных пространств)',c='#1d6b3a',lw=1.6,ls=(0,(4,2)))
L.head('Основа');L.item('fill','здание',fc=COL['bld']);L.item('fill','ячейка анализа (номер)',fc='#fbfaf7',ec='#b8b2a7',lw=.6)
foot(fig);fig.savefig('out12/prev/29_предпосылки.png',dpi=110);plt.close(fig)
