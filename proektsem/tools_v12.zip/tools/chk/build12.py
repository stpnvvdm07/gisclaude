import sys,pickle,collections,cv2;sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np
from io9 import tow
K='out12/konkovo_v12.gpkg';A='out12/analiz_v12.gpkg'
d=pickle.load(open('out12/viol12.pkl','rb'));V=d['V'];m=pickle.load(open('out12/viol2_12.pkl','rb'));base=m['base'];scope=set(m['scope']);ITEMS=m['ITEMS']
cls=lambda s:'высокая' if s>=6 else ('средняя' if s>=4 else 'низкая')
F=lambda it:'p'+it.replace('.','_')
ck=gpw.create('out12/problems_v12.gpkg')
gt,f,cells=io9.load(K,'cells')
allp=np.vstack([np.array(p[0]) for g,a in cells for p in gp.polys(g)])
W=rb.Win(*(allp.min(0)-15),*(allp.max(0)+15),0.5)
SC=W.blank()
for g,a in cells:
    if a['num'] in scope:
        for p in gp.polys(g): W.fill(SC,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
def mask_of(rows,filt=lambda a:True):
    mm=W.blank()
    for g,a in rows:
        if not filt(a): continue
        for p in gp.polys(g): W.fill(mm,[np.array(p[0])],1,holes=[np.array(h) for h in p[1:]])
    return mm
def to_polys(mm,minarea=30):
    return [(('Polygon',[np.asarray(r).tolist() for r in rings]),{'area':round(rb.polyarea([np.asarray(r) for r in rings]))}) for rings in W.polys(mm,eps=0.3,minarea=minarea)]
# --- ячейки со счётом
feats=[]
for g,a in cells:
    n=a['num'];v=V[n];r=base.get(n)
    o={'num':n,'in_scope':1 if n in scope else 0,'is_anal':a['is_anal'],'pod':v['pod'],'score':r[0] if r else None,'cls':cls(r[0]) if r else None,'comfort_score':round(r[2],2) if r else None}
    for it in ITEMS: o[F(it)]=(1 if r[1][it] else 0) if r else (1 if (it=='1.3' and not a['is_anal']) else None)
    o.update(nodes_non=v['ent_non'],wear40=v['wear40'],loading_m2=v['loading_m2'],danger_obj=v['danger_obj'],combined_m=v['combined_m'],transit_res_m=v['transit_res_m'],biz_transit=v['biz_transit'],pg_out=v['pg_out'],comp_pct=v['comp_pct'],unc_pct=v['unc_pct'],unosv_pct=v['unosv_pct'],fav_closed=v['fav_closed'])
    feats.append((tow(g),o))
fl=[('num','INTEGER'),('in_scope','INTEGER'),('is_anal','INTEGER'),('pod','INTEGER'),('score','INTEGER'),('cls','TEXT'),('comfort_score','REAL')]+[(F(it),'INTEGER') for it in ITEMS]+[('nodes_non','INTEGER'),('wear40','INTEGER'),('loading_m2','INTEGER'),('danger_obj','INTEGER'),('combined_m','INTEGER'),('transit_res_m','INTEGER'),('biz_transit','INTEGER'),('pg_out','INTEGER'),('comp_pct','REAL'),('unc_pct','REAL'),('unosv_pct','REAL'),('fav_closed','INTEGER')]
gpw.add_layer(ck,'viol_cells','POLYGON',fl,feats)
cf=[('num','INTEGER')]
gpw.add_layer(ck,'p1_1_cells',gt,cf+[('comfort_score','REAL')],[(tow(g),{'num':a['num'],'comfort_score':round(base[a['num']][2],2)}) for g,a in cells if a['num'] in scope and base[a['num']][1]['1.1']])
gpw.add_layer(ck,'p1_3_cells',gt,cf+[('in_scope','INTEGER')],[(tow(g),{'num':a['num'],'in_scope':1 if a['num'] in scope else 0}) for g,a in cells if not a['is_anal']])
# --- узлы входов
gt,f,nodes=io9.load(K,'entry_nodes')
gpw.add_layer(ck,'p1_2_nodes',gt,f,[(tow(g),a) for g,a in nodes if a['in_12']=='да' and a['fix_class']=='не организован'])
gpw.add_layer(ck,'pre_nodes',gt,f,[(tow(g),a) for g,a in nodes if a['in_12']=='да' and a['fix_class']=='организован'])
# --- износ
bw={b['id']:b for b in d['bw']};gt,f,rows=io9.load(K,'buildings')
gpw.add_layer(ck,'p1_4_wear',gt,[('id','INTEGER'),('addr','TEXT'),('wear','REAL'),('src','TEXT')],[(tow(g),{'id':a['id'],'addr':a['Адрес / ориентир'],'wear':round(float(bw[a['id']]['w']),2),'src':'указан' if bw[a['id']]['off'] is not None else 'оценка команды'}) for g,a in rows if a['id'] in bw and bw[a['id']]['w']>=0.40])
# --- 2.x
gt,f,rows=io9.load(K,'loading_zones');gpw.add_layer(ck,'p2_1_loading',gt,f,[(tow(g),a) for g,a in rows])
gpw.add_layer(ck,'p2_2_objects','POINT',[('src','TEXT'),('name','TEXT'),('kind','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'src':s,'name':n,'kind':k}) for s,n,p,k in d['objs']])
gpw.add_layer(ck,'p2_3_combined','LINESTRING',[('razdel','TEXT'),('group','TEXT'),('vgroup','TEXT'),('length','REAL')],[(('LineString',np.asarray(l).tolist()),{'razdel':a['razdel'],'group':a['group'],'vgroup':a['vgroup'],'length':a['length']}) for g,a in d['comb_edges'] for l in gp.lines(g)])
# --- 3.1 транзит в зонах АЖ/ПЖ
PERS=mask_of(io9.load(A,'control_zones')[2],lambda a:a['type'] in ('АЖ','ПЖ'))
lines=[]
for g,a in io9.load(A,'transit')[2]:
    if a['cls']!='высокая':continue
    for l in gp.lines(g):
        l=np.array(l);L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))];s=np.arange(0.5,L[-1],1.0)
        if not len(s):continue
        P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])];px=np.round(W.px(P)).astype(int)
        if PERS[px[:,1],px[:,0]].mean()>=0.5: lines.append((('LineString',l.tolist()),{'mode':a['mode'],'load':a['load'],'length':a['length']}))
gpw.add_layer(ck,'p3_1_transit','LINESTRING',[('mode','TEXT'),('load','REAL'),('length','REAL')],lines)
# --- 3.2 территории обслуживающих объектов с внешним транзитом: 10 м вокруг объектов, слитно
mm=W.blank()
for nm,p in d['biz3']: cv2.circle(mm,tuple(np.round(W.px([p])[0]).astype(int)),int(10/0.5),1,-1)
gpw.add_layer(ck,'p3_2_service','POLYGON',[('area','INTEGER')],to_polys(mm))
gpw.add_layer(ck,'p3_2_objects','POINT',[('name','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'name':n}) for n,p in d['biz3']])
gpw.add_layer(ck,'p3_3_places','POLYGON',[('type','TEXT'),('zone','TEXT'),('control','TEXT')],[(tow(g),{'type':a['type'],'zone':a['zone'],'control':a['control']}) for g,a in d['pg3']])
# --- 3.4 (в ячейках анализа)
comp=mask_of(io9.load(A,'competition')[2])&SC
unc=mask_of(io9.load(A,'control')[2],lambda a:a['type']=='неконтролируемая')&SC
ab=mask_of(io9.load(A,'osvoennost')[2],lambda a:a['cls']=='неосвоенная')&SC
gpw.add_layer(ck,'p3_4_competition','POLYGON',[('area','INTEGER')],to_polys(comp))
gpw.add_layer(ck,'p3_4_uncontrolled','POLYGON',[('area','INTEGER')],to_polys(unc&(ab==0)))
gpw.add_layer(ck,'p3_4_abandoned','POLYGON',[('area','INTEGER')],to_polys(ab))
# --- предпосылки
ctl=mask_of(io9.load(A,'control')[2],lambda a:a['type']=='контролируемая')
osv=mask_of(io9.load(A,'osvoennost')[2],lambda a:a['cls']=='освоенная')
gpw.add_layer(ck,'pre_osv_ctl','POLYGON',[('area','INTEGER')],to_polys(osv&ctl&SC,minarea=50))
gpw.add_layer(ck,'pre_fav_closed','POINT',[('name','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'name':n}) for n,p in d['fav']])
gpw.add_layer(ck,'pre_comfort_cells',gt if False else 'POLYGON',[('num','INTEGER'),('comfort_score','REAL')],[(tow(g),{'num':a['num'],'comfort_score':round(base[a['num']][2],2)}) for g,a in cells if a['num'] in scope and not base[a['num']][1]['1.1']])
gpw.add_layer(ck,'pre_axes','LINESTRING',[('mode','TEXT'),('load','REAL'),('length','REAL')],[(tow(g),{'mode':a['mode'],'load':a['load'],'length':a['length']}) for g,a in io9.load(A,'transit')[2] if a['cls']=='высокая' and a['mode']=='пешеходный'])
ck.close()
R2=0.25
print('areas m2: comp',int(comp.sum()*R2),'unc',int((unc&(ab==0)).sum()*R2),'aband',int(ab.sum()*R2),'pre',int((osv&ctl&SC).sum()*R2))
