exec(open('chk/plot12.py').read())
import pickle,collections
m=pickle.load(open('out12/viol2_12.pkl','rb'));BS=m['base'];scope=set(m['scope'])
fig,ax,lg=sheet('Проблемы планировочной организации придомовых территорий','Занятие 4, I: нарушения по трём блокам. Ячейки анализа: 42 (в зафиксированных границах и с выходом подъездов)')
cells=basemap(ax)
vc=gp.read(P,'viol_cells')
# 1.3 — ячейки вне зафиксированных границ
polys(ax,gp.read(P,'p1_3_cells'),'#e7e4dd',z=1.5)
polys(ax,gp.read(P,'p1_3_cells'),ec='#a09a8f',hatch='\\\\\\\\',z=1.6,al=.9)
# 3.4
polys(ax,gp.read(P,'p3_4_uncontrolled'),ec=COL['red'],hatch='////',z=2,al=.55)
polys(ax,gp.read(P,'p3_4_competition'),COL['pink'],z=2.5,al=.75)
polys(ax,gp.read(P,'p3_4_abandoned'),COL['red'],z=2.6,al=.9)
# 2.1, 3.2, 3.3
polys(ax,gp.read(P,'p3_2_service'),'#c9d6f2',ec=COL['blue'],lw=.8,z=3)
polys(ax,gp.read(P,'p2_1_loading'),COL['purple'],z=3.5)
polys(ax,gp.read(P,'p3_3_places'),COL['yellow'],ec='#16161c',lw=1,z=8)
# 1.4
polys(ax,gp.read(P,'p1_4_wear'),COL['dark'],z=7.5)
# 1.1 контур ячейки
outline(ax,gp.read(P,'p1_1_cells'),'#1f6f78',1.5,9,ls=(0,(4,2.5)))
# линии
lines(ax,gp.read(P,'p2_3_combined'),COL['orange'],3.2,10)
lines(ax,gp.read(P,'p3_1_transit'),'#7a1f27',1.5,11,ls=(0,(3,2)))
# точки
pts(ax,gp.read(P,'p2_2_objects'),s=55,marker='X',c='#16161c',edgecolors='white',linewidths=.8,zorder=13)
pts(ax,gp.read(P,'p1_2_nodes'),s=95,marker='^',c='#d62828',edgecolors='white',linewidths=1.0,zorder=14)
labels(ax,cells,which=scope,fs=6.5,col='#55524c')
frame(ax);scalebar(fig,ax)
import sqlite3
def q(sql,f=P): return sqlite3.connect('file:'+f+'?immutable=1',uri=True).execute(sql).fetchone()[0]
it=m['ITEMS'];cnt={i:sum(r[1][i] for r in BS.values()) for i in it}
N=dict(n11=q('select count(*) from p1_1_cells'),n12=q('select count(*) from p1_2_nodes'),n13=q('select count(*) from p1_3_cells'),n14=q('select count(*) from p1_4_wear'),
 n21=q('select count(*) from p2_1_loading'),a21=q('select sum(area) from p2_1_loading'),n22=q('select count(*) from p2_2_objects'),g22=q("select count(*) from p2_2_objects where src='garbage'"),
 l23=q('select sum(length) from p2_3_combined'),n23=q('select count(*) from p2_3_combined'),l31=q('select sum(length) from p3_1_transit'),n32=q('select count(*) from p3_2_objects'),n33=q('select count(*) from p3_3_places'),
 a34c=q('select sum(area) from p3_4_competition'),a34u=q('select sum(area) from p3_4_uncontrolled'),a34a=q('select sum(area) from p3_4_abandoned'))
fmt=lambda x:f'{x:,.0f}'.replace(',',' ')
L=Legend(lg)
L.head('1. Пространственно-планировочные')
L.item('fill',f'1.1 ячейка с нарушением размеров, пропорций,\nфиксации границ (балл < 0,67) — {N["n11"]} яч.',fc='none',ec='#1f6f78',lw=1.5,ls=(0,(4,2.5)))
L.item('mark',f'1.2 неорганизованный узел входа — {N["n12"]}\n(в {cnt["1.2"]} ячейках анализа)',m='^',s=95,c='#d62828',ec='white')
L.item('fill2',f'1.3 территория вне зафиксированных границ —\n{N["n13"]} яч. (в счёте {cnt["1.3"]} с подъездами)',fc='#e7e4dd',hc='#a09a8f',hatch='\\\\\\\\')
L.item('fill',f'1.4 здание с износом ≥ 40 % — {N["n14"]}',fc=COL['dark'])
L.head('2. Функционально-планировочные')
L.item('fill',f'2.1 зона загрузки с заездом грузового\nтранспорта — {N["n21"]}, {fmt(N["a21"])} м²',fc=COL['purple'])
L.item('mark',f'2.2 опасный открытый объект — {N["n22"]}\n(из них {N["g22"]} мусорных площадок, допущение)',m='X',s=55,c='#16161c',ec='white')
L.item('line',f'2.3 совмещение транзитных пешеходных\nи транспортных потоков на проезде — {fmt(N["l23"])} м',c=COL['orange'],lw=3.2)
L.head('3. Социально-планировочные')
L.item('line',f'3.1 транзит через придомовую территорию\n(высокий, в зонах АЖ/ПЖ) — {fmt(N["l31"])} м',c='#7a1f27',lw=1.5,ls=(0,(3,2)))
L.item('fill',f'3.2 территория обслуживающих объектов\nс внешним транзитом — {N["n32"]} объектов',fc='#c9d6f2',ec=COL['blue'],lw=.8)
L.item('fill',f'3.3 место поведения вне зоны контроля — {N["n33"]}',fc=COL['yellow'],ec='#16161c',lw=1)
L.item('fill',f'3.4 конкуренция активного публичного\nи персонального контроля — {fmt(N["a34c"])} м²',fc=COL['pink'],al=.75)
L.item('fill2',f'3.4 неконтролируемая территория — {fmt(N["a34u"])} м²',fc='white',hc=COL['red'],hatch='////')
L.item('fill',f'3.4 заброшенная (неосвоенная) — {fmt(N["a34a"])} м²',fc=COL['red'],al=.9)
L.head('Основа')
L.item('fill','здание',fc=COL['bld'])
L.item('fill','ячейка анализа (номер)',fc='#fbfaf7',ec='#b8b2a7',lw=.6)
top=sorted(((r[0],n) for n,r in BS.items()),reverse=True)
bx=fig.add_axes([0.024,0.075,0.714,0.19]);bx.axis('off');bx.set_xlim(0,1);bx.set_ylim(0,1)
bx.text(0,0.98,'Ячейки с наибольшим числом нарушений (≥ 6 из 11)',fontsize=10.5,fontweight='semibold',va='top')
tops=[(sc_,n) for sc_,n in top if sc_>=6]
blk={'1':'#1f6f78','2':COL['purple'],'3':COL['red']}
x0=0.09;dx=0.052;y0=0.70;dy=0.62/max(len(tops),1)
for j,i_ in enumerate(it): bx.text(x0+j*dx+dx/2,y0+0.07,i_,fontsize=8,ha='center',color='#55524c')
bx.text(x0+len(it)*dx+0.02,y0+0.07,'счёт',fontsize=8,color='#55524c')
for k,(sc_,n) in enumerate(tops):
    y=y0-k*dy-dy/2
    bx.text(0.0,y,f'ячейка {n}',fontsize=9,va='center')
    for j,i_ in enumerate(it):
        on=BS[n][1][i_]
        bx.add_patch(mp.Rectangle((x0+j*dx+0.004,y-dy*0.38),dx-0.008,dy*0.76,fc=blk[i_[0]] if on else '#eeebe5',ec='none'))
    bx.text(x0+len(it)*dx+0.02,y,str(sc_),fontsize=9.5,va='center',fontweight='semibold')
foot(fig)
fig.savefig('out12/prev/28_финальная_схема_проблем.png',dpi=110)
