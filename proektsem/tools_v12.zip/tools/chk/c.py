import sys; sys.path.insert(0,'lib')
import gp, math, collections, numpy as np, msk
import geo
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
b8=gp.read(V+'konkovo_v8.gpkg','buildings'); print(len(b8),[k for k in b8[0] if k!='_g'])
b2=gp.read(U+'c21fbc75-buildings_2.gpkg')
def cen(g):
    p=gp.polys(g)[0][0]; a=np.array(p); return a.mean(0)
def ar(g): return sum(geo.area(r[0]) for r in gp.polys(g))
by={r['id']:r for r in b8}
for r in b2:
    if r['id'] in by:
        o=by[r['id']]; print('id',r['id'],'area2',round(ar(r['_g']),1),'area8',round(ar(o['_g']),1),'cdist',round(float(np.hypot(*(cen(r['_g'])-cen(o['_g'])))),2))
    else:
        c=cen(r['_g']); 
        best=min(b8,key=lambda o:np.hypot(*(cen(o['_g'])-c)))
        print('fid',r['fid'],'noid; area',round(ar(r['_g']),1),'nearest v8 id',best['id'],'d',round(float(np.hypot(*(cen(best['_g'])-c))),2),'area8',round(ar(best['_g']),1))
# all fids vs v8 ids
print('v8 school/kinder/unique rows:')
for o in b8:
    t=str(o.get('Комментарий') or '')+str(o.get('Адрес / ориентир') or '')
    if any(s in t.lower() for s in ('школ','сад','уник')): print(o['id'],o.get('Адрес / ориентир'),o.get('Комментарий'),o.get('Тип здания'))
print(collections.Counter(o.get('Тип здания') for o in b8))
