import sys,glob;sys.path.insert(0,'lib')
exec(open('chk/prev11.py').read().split("fig,ax=")[0])
fig,axs=plt.subplots(1,2,figsize=(30,10))
o=gp.read(A,'osvoennost')
for ax,key,cm in ((axs[0],'cls',{'освоенная':'#5ec46e','частично освоенная':'#d9c35b','неосвоенная':'#b13840'}),(axs[1],'kind',None)):
    polys(ax,gp.read(K,'cells'),'#fff',ec='#999',lw=.5,z=1)
    if cm:
        for k,c in cm.items(): polys(ax,[r for r in o if r['cls']==k],c,z=2)
    else:
        kc={'деревья':'#2e8b57','трава':'#a8d08d','прочее':'#e06060'}
        for r in o:
            c=kc.get(r['kind'],'#e0c040')
            polys(ax,[r],c,z=2)
    polys(ax,gp.read(K,'buildings'),'#7a6a55',z=3)
    polys(ax,gp.read(K,'people_dens'),'none',ec='#1040ff',lw=2,z=5)
    polys(ax,gp.read(K,'osv_manual'),'none',ec='k',lw=2,z=5)
    lines(ax,gp.read(S:='in/proektsem/vector/proektbase/slopesandwalls.gpkg','slopesandwalls'),'k',2,6,':')
    for r in gp.read(K,'cells'):
        c=T(np.array(gp.polys(r['_g'])[0][0]).mean(0));ax.text(*c,str(r['num']),fontsize=9,color='#333',zorder=8)
    ax.set_aspect('equal');ax.autoscale();ax.axis('off')
plt.savefig('chk/aud_osv.png',dpi=55,bbox_inches='tight')
