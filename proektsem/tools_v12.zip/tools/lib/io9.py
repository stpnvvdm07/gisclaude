import sqlite3,sys,os
sys.path.insert(0,os.path.dirname(__file__))
import gp,gpw
def meta(path,table):
    c=sqlite3.connect('file:'+path+'?mode=ro&immutable=1',uri=True)
    gt=c.execute("select geometry_type_name from gpkg_geometry_columns where table_name=?",(table,)).fetchone()[0]
    gcol=c.execute("select column_name from gpkg_geometry_columns where table_name=?",(table,)).fetchone()[0]
    f=[(r[1],r[2] or 'TEXT') for r in c.execute(f'pragma table_info("{table}")') if r[1] not in ('fid',gcol)]
    return gt,f
def load(path,table):
    gt,f=meta(path,table)
    rows=gp.read(path,table)
    out=[]
    for r in rows:
        g=r.pop('_g'); r.pop('fid',None); out.append((g,r))
    return gt,f,out
def tow(g):
    """gp geometry -> gpw geometry"""
    t,c=g
    if t=='MultiPolygon': return ('MultiPolygon',[x[1] for x in c])
    if t=='MultiLineString': return ('MultiLineString',[x[1] for x in c])
    return g
