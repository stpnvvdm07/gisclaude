import sys; sys.path.insert(0,'lib')
import gp, geo, numpy as np
from matplotlib.path import Path
V='/mnt/user-data/uploads/proektsem/vector/'
pk=gp.read(V+'konkovo_v8.gpkg','parking'); bl=gp.read(V+'konkovo_v8.gpkg','buildings')
print([k for k in pk[0] if k!='_g'])
bp=[Path(np.array(p[0])) for o in bl for p in gp.polys(o['_g'])]
def stats(ring):
    ring=np.array(ring); mn,mx=ring.min(0),ring.max(0)
    xs=np.arange(mn[0],mx[0],0.5);ys=np.arange(mn[1],mx[1],0.5)
    G=np.array([(x,y) for x in xs for y in ys]);ins=Path(ring).contains_points(G);G=G[ins]
    m=np.zeros(len(G),bool)
    for p in bp: m|=p.contains_points(G)
    return len(G)*.25,m.sum()*.25
pp=[]
for r in pk:
    for p in gp.polys(r['_g']):
        a=geo.area(p[0]); s=stats(p[0]); pp.append((r['fid'],len(p),len(p[0]),round(abs(a)),round(s[1])))
        print(r['fid'],'rings',len(p),'verts',len(p[0]),'area',round(abs(a)),'over bldg',round(s[1]))
