import sys; sys.path.insert(0,'lib')
import gp,rb,numpy as np
V='/mnt/user-data/uploads/proektsem/vector/'
O='/tmp/claude-0/-home-claude/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/scratchpad/in/proektsem/vector/proektbase/building_vadim.gpkg'
old=gp.read(O); v8=[r for r in gp.read(V+'konkovo_v8.gpkg','buildings')]
def cen(g):
    ps=gp.polys(g); a=np.vstack([np.array(p[0]) for p in ps]); return a.mean(0)
def ar(g): return sum(abs(rb.ringarea(p[0])) for p in gp.polys(g))
Co=np.array([cen(r['_g']) for r in old]); Ao=np.array([ar(r['_g']) for r in old])
Cn=np.array([cen(r['_g']) for r in v8]); An=np.array([ar(r['_g']) for r in v8])
print(len(old),len(v8))
M=np.array([[1,0],[0,1],[0,0]],float)
def apply(M,P): return np.c_[P,np.ones(len(P))]@M
for it in range(15):
    cur=apply(M,Co); pairs=[]
    for i in range(len(Co)):
        d=np.hypot(*(Cn-cur[i]).T); j=d.argmin()
        if d[j]<12 and 0.6<Ao[i]/An[j]<1.7: pairs.append((i,j))
    P=Co[[i for i,j in pairs]];Q=Cn[[j for i,j in pairs]]
    X=np.c_[P-Co.mean(0),np.ones(len(P))]; sol,_,_,_=np.linalg.lstsq(X,Q-Co.mean(0),rcond=None)
    M=np.array([[sol[0,0],sol[0,1]],[sol[1,0],sol[1,1]],[sol[2,0],sol[2,1]]])
    # convert back to non-centred translation
    c=Co.mean(0); M2=M.copy(); M2[2]=M[2]-M[:2].T@c+c; 
    # store centred form
    Mc=M
    cur=np.c_[Co-c,np.ones(len(Co))]@Mc+c
    r=np.hypot(*(Cn[[j for i,j in pairs]]-cur[[i for i,j in pairs]]).T)
    print(it,len(pairs),'median resid',round(float(np.median(r)),2),'linear',Mc[:2].round(4).tolist())
    M=np.array([[1,0],[0,1],[0,0]],float); 
    # next iteration uses centred affine: re-init cur via function
    def apply(M_,P_,Mc=Mc,c=c): return np.c_[P_-c,np.ones(len(P_))]@Mc+c
    M=None
    # emulate by overriding apply for next loop
    class _M: pass
    apply_=apply
    M=Mc
    def apply(Mx,P_,Mc=Mc,c=c): return np.c_[P_-c,np.ones(len(P_))]@Mc+c
import pickle; pickle.dump({'Mc':Mc,'c':c},open('out9/old2new.pkl','wb'))
print('Mc',Mc.tolist(),'c',c)
