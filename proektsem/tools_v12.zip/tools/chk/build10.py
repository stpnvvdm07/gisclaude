import sys,pickle,collections,cv2,os,copy; sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np
from io9 import tow
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'; OUT='out10/'
parcels=pickle.load(open(OUT+'parcels.pkl','rb')); ents=pickle.load(open('out9/ent8.pkl','rb')); e3=pickle.load(open('out9/ent3.pkl','rb'))
lab=np.load(OUT+'lab.npy'); w=pickle.load(open(OUT+'win.pkl','rb')); R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R); W.h,W.w=lab.shape
def cls(p,tb=1.0,tu=1.0):
    if p['man']>=0.5 and not p['kind'].startswith('площадка'): return 'неосвоенная'
    b=p['B']>=tb; u=p['U']>=tu
    return 'освоенная' if b and u else ('частично освоенная' if b or u else 'неосвоенная')
ck=gpw.create(OUT+'konkovo_v10.gpkg')
SKIP={'entries_territory','buildings','loading_zones','business','playgrounds'}
for t in ['arches','boundary','cells','cells_excluded','crossings','entrances_buildings','fences','garbage','gates','green','trees','parking','osv_manual']:
    gt,f,rows=io9.load(K,t); gpw.add_layer(ck,t,gt,f,[(tow(g),a) for g,a in rows])
# people_dens (наблюдение)
pdz=gp.read('in2/people_dens.gpkg','people_dens')
gpw.add_layer(ck,'people_dens','POLYGON',[('dens','TEXT'),('area','INTEGER')],[(tow(r['_g']) if r['_g'][0]!='Polygon' else r['_g'],{'dens':r['dens'],'area':int(round(0.5*abs(np.dot(np.array(gp.polys(r['_g'])[0][0])[:-1,0],np.array(gp.polys(r['_g'])[0][0])[1:,1])-np.dot(np.array(gp.polys(r['_g'])[0][0])[1:,0],np.array(gp.polys(r['_g'])[0][0])[:-1,1]))))}) for r in pdz])
# buildings: assessments for детсад (id 10) and 83А (id 4)
gt,f,rows=io9.load(K,'buildings'); feats=[]
for g,a in rows:
    a=dict(a); a['assess_note']=None
    if a['id']==10 and not a['function']:
        a.update(function='обслуживающий',danger='благоприятный',isolation='закрытый',assess_note='по аналогии со школами (id 32, 35): детсад, огороженная территория')
    if a['id']==4 and not a['function']:
        a.update(function='обслуживающий',danger='благоприятный',isolation='открытый',assess_note='по арендаторам 83А (шаурма, кафе, столовая, банк): точки оценены как обслуживающие/благоприятные/открытые')
    if a['function'] and not a['assess_note']: a['assess_note']='оценка обследования'
    feats.append((tow(g),a))
gpw.add_layer(ck,'buildings',gt,f+[('assess_note','TEXT')],feats)
# loading zones
gt,f,rows=io9.load(K,'loading_zones')
gpw.add_layer(ck,'loading_zones',gt,f+[('function_orig','TEXT')],[(tow(g),{**a,'function':('обслуживающий' if a['function']=='м' else a['function']),'function_orig':(a['function'] if a['function']=='м' else None)}) for g,a in rows])
# playgrounds
def pg_fix(a):
    a=dict(a); a['danger_orig']=None
    if a['danger']=='неблагоприятный': a['danger_orig']='неблагоприятный'; a['danger']='опасный'
    return a
gt,f,rows=io9.load(K,'playgrounds')
gpw.add_layer(ck,'playgrounds',gt,f+[('danger_orig','TEXT')],[(tow(g),pg_fix(a)) for g,a in rows])
# business
gt,f,rows=io9.load(K,'business')
byid=collections.defaultdict(list)
for g,a in io9.load(K,'buildings')[2]:
    for p in gp.polys(g): byid[a['id']].append(np.array(p[0]))
def dmin(P,i):
    best=1e9
    for r in byid[i]:
        A_,B_=r[:-1],r[1:];d=B_-A_;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A_)*d).sum(1)/L,0,1);Q=A_+d*t[:,None];best=min(best,np.hypot(*(P-Q).T).min())
    return best
bf=[];chg=collections.Counter();fin_d={x[0]:float(x[3]) for x in pickle.load(open('out9/biz.pkl','rb'))['final']}
raw={r['fid']:r for r in gp.read('/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/92246443-business_2.gpkg')}
rawfids=[r['fid'] for r in gp.read('/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/92246443-business_2.gpkg')]
for (g,a),fid in zip(rows,rawfids):
    a=dict(a);a['fid_src']=fid;notes=[]
    a['placement_orig']=a['placement']
    if a['placement']=='пристроенный': a['placement']='встроенно-пристроенный';chg['пристроенный→встроенно-пристроенный']+=1
    if a['bld_id']==4 and a['placement']!='отдельно стоящий' : a['placement']='отдельно стоящий';notes.append('размещение приведено к зданию 83А (отдельно стоящее)');chg['83А→отдельно стоящий']+=1
    if a['Название']=='СберБанк' and a['function']=='обслуживающий': a['function']='не связан';notes.append('СберБанк: функция по остальным отделениям банков (3 из 4 «не связан»)');chg['СберБанк→не связан']+=1
    if a['Название']=='Около' and a['isolation']=='закрытый': a['isolation']='открытый';notes.append('«Около»: изоляция как у fid 4 (магазины в основном «открытый»)');chg['Около→открытый']+=1
    if a['Название']=='-': a['Название']=None;chg['Название "-"→NULL']+=1
    if a['Назначение']=='-': a['Назначение']=(a['Название'] or '').lower();notes.append('назначение выведено из названия');chg['Назначение "-"→из названия']+=1
    a['label']=a['Название'] or a['Назначение']
    d=fin_d[fid];a['pos_d']=round(float(d),1);a['pos_q']='точно' if d<=2 else 'приблизительно'
    if a['fid_src']==31: notes.append('адрес 55с3, по геометрии у дома 53к1 (id 37)')
    a['edit_note']='; '.join(notes) or None
    bf.append((tow(g),a))
print(chg)
gpw.add_layer(ck,'business','POINT',f+[('fid_src','INTEGER'),('placement_orig','TEXT'),('label','TEXT'),('pos_d','REAL'),('pos_q','TEXT'),('edit_note','TEXT')],bf)
# entries
et=[]
for r in ents:
    et.append((('Point',(float(r['pt'][0]),float(r['pt'][1]))),{'podtip':'Вход — '+r['podtip'],'fix_class':r['cls'],'degree':r['deg'],'level':r['level'],'node':r['node'],'src':r['src'],'survey_id':r['sid'],'comment':r['comment'],'photo':r['photo'],'author':r['author'],'evidence':r['ev'],'edit_note':'; '.join(r['note']) or None,'gap_bld_m':(None if not np.isfinite(r['gap_B']) else round(float(r['gap_B']),1))}))
gpw.add_layer(ck,'entries_territory','POINT',[('podtip','TEXT'),('fix_class','TEXT'),('degree','TEXT'),('level','TEXT'),('node','INTEGER'),('src','TEXT'),('survey_id','INTEGER'),('comment','TEXT'),('photo','TEXT'),('author','TEXT'),('evidence','TEXT'),('edit_note','TEXT'),('gap_bld_m','REAL')],et)
# nodes
nodes=collections.defaultdict(list)
for r in ents: nodes[r['node']].append(r)
nf=[]
for n,rs in sorted(nodes.items()):
    c=np.mean([r['pt'] for r in rs],axis=0); org=any(r['cls']=='организован' for r in rs)
    best=max(rs,key=lambda r:{'высокая':3,'средняя':2,'низкая':1,'нет':0}[r['deg']])
    nf.append((('Point',(float(c[0]),float(c[1]))),{'node':n,'n':len(rs),'ways':', '.join(sorted(set(r['podtip'] for r in rs))),'fix_class':'организован' if org else 'не организован','degree':best['deg'],'level':'внутренний' if all(r['level']=='внутренний' for r in rs) else 'внешний'}))
gpw.add_layer(ck,'entry_nodes','POINT',[('node','INTEGER'),('n','INTEGER'),('ways','TEXT'),('fix_class','TEXT'),('degree','TEXT'),('level','TEXT')],nf)
# candidates (unconfirmed)
import cv2
DT=cv2.distanceTransform(e3['U'],cv2.DIST_L2,5)*e3['win'][4];x0,y0,x1,y1,R3=e3['win']
net=io9.load(A,'network')[2]
AC=[r['pt'] for r in ents if r['podtip']=='арка']
cand=[]
for j,m in enumerate(e3['M']):
    dn=min(np.hypot(*(r['pt']-m['p'])) for r in ents)
    da=min(np.hypot(*(a-m['p'])) for a in AC)
    best=0
    for (i,t) in m['n']:
        for l in gp.lines(net[i][0]):
            l=np.array(l);L=np.r_[0,np.cumsum(np.hypot(*np.diff(l,axis=0).T))];s=np.arange(0,L[-1],0.5);P=np.c_[np.interp(s,L,l[:,0]),np.interp(s,L,l[:,1])]
            dd=np.hypot(*(P-m['p']).T)
            if dd.min()>2: continue
            for q in P[dd<20]: best=max(best,DT[min(max(int((q[1]-y0)/R3),0),DT.shape[0]-1),min(max(int((q[0]-x0)/R3),0),DT.shape[1]-1)])
    if dn>20 and da>20 and best>=8: cand.append((m['p'],sorted(set(t for i,t in m['n'])),round(float(best),1),round(float(dn),0)))
print('candidates',len(cand),[(np.round(c[0]),c[1],c[2],c[3]) for c in cand])
gpw.add_layer(ck,'entry_candidates','POINT',[('net_type','TEXT'),('depth_m','REAL'),('dist_entry_m','REAL'),('comment','TEXT')],[(('Point',(float(p[0]),float(p[1]))),{'net_type':', '.join(t),'depth_m':d,'dist_entry_m':de,'comment':'сеть пересекает контур территории; полевой точки/замера/арки рядом нет — проверить, это вход или тупик у фасада'}) for p,t,d,de in cand])
ck.close()
# ---------- analiz_v10
ca=gpw.create(OUT+'analiz_v10.gpkg')
for t in ['competition','control','control_zones','facades','heights','network','ped_exits','roads_tree','roads_tree_start','transit','veh_exits']:
    gt,f,rows=io9.load(A,t); gpw.add_layer(ca,t,gt,f,[(tow(g),a) for g,a in rows])
gt,f,rows=io9.load(A,'playgrounds_zones'); gpw.add_layer(ca,'playgrounds_zones',gt,f+[('danger_orig','TEXT')],[(tow(g),pg_fix(a)) for g,a in rows])
gt,f,rows=io9.load(A,'flows')
EP=np.array([r['pt'] for r in ents]);EN=[r['node'] for r in ents]
ff=[]
for g,a in rows:
    p=np.array(g[1]);d=np.hypot(*(EP-p).T);k=d.argmin()
    ff.append((tow(g),{**a,'entry_node':EN[k] if d[k]<=20 else None,'entry_dist':round(float(d[k]),1),'car_obs':1 if (a['in_car']+a['out_car'])>0 else 0}))
gpw.add_layer(ca,'flows','POINT',f+[('entry_node','INTEGER'),('entry_dist','REAL'),('car_obs','INTEGER')],ff)
pf=[]
for p in parcels:
    c=cls(p)
    sh=lambda q:0.5*abs(np.dot(q[:-1,0],q[1:,1])-np.dot(q[1:,0],q[:-1,1]))
    pas=[sh(np.asarray(rings[0]))-sum(sh(np.asarray(h)) for h in rings[1:]) for rings in p['poly']]
    for rings,pa0 in zip(p['poly'],pas):
        pa=p['area']*pa0/sum(pas)
        pf.append((('Polygon',[np.asarray(r).tolist() for r in rings]),{'kind':p['kind'],'area':round(pa),'cell':p['cell'],'cover':p['B_cover'],'green':p['B_green'],'relief':p['B_relief'],'light':None,'urns':None,'B':p['B'],'ped':p['ped'],'T':round(p['T'],1),'U_model':p['U_model'],'U':p['U'],'u_src':p['u_src'],'cls':c,'forced':'да' if (p['man']>=0.5 and not p['kind'].startswith('площадка')) else None}))
gpw.add_layer(ca,'osvoennost','POLYGON',[('kind','TEXT'),('area','INTEGER'),('cell','INTEGER'),('cover','INTEGER'),('green','INTEGER'),('relief','INTEGER'),('light','INTEGER'),('urns','INTEGER'),('B','REAL'),('ped','INTEGER'),('T','REAL'),('U_model','REAL'),('U','REAL'),('u_src','TEXT'),('cls','TEXT'),('forced','TEXT')],pf)
CLr=np.zeros(lab.shape,np.int16); cells=gp.read(K,'cells')
for r in cells:
    for p in gp.polys(r['_g']): W.fill(CLr,[np.array(p[0])],r['num'],holes=[np.array(h) for h in p[1:]])
# entries per cell: cells within 12 m
ecell=collections.defaultdict(list)
rad=int(12/R)
for r in ents:
    px=int((r['pt'][0]-W.x0)/R);py=int((r['pt'][1]-W.y0)/R)
    sub=CLr[max(py-rad,0):py+rad,max(px-rad,0):px+rad]
    yy,xx=np.ogrid[:sub.shape[0],:sub.shape[1]]
    ids=set(np.unique(sub).tolist())-{0}
    for i in ids: ecell[i].append(r)
rows=[]
gt_cells=io9.meta(K,'cells')[0]; cf=[]
for r in cells:
    n=r['num']; m=CLr==n; tot=m.sum()*R*R; ar={k:sum(p['area'] for p in parcels if p['cell']==n and cls(p)==k) for k in ('освоенная','частично освоенная','неосвоенная')}
    s=sum(ar.values()); dom=max(ar,key=ar.get) if s>0 else None
    es=ecell.get(n,[]); eo=sum(1 for e in es if e['cls']=='организован')
    a={'num':n,'is_anal':r['is_anal'],'area':round(tot),'parcels_area':round(s),'osv_m2':round(ar['освоенная']),'part_m2':round(ar['частично освоенная']),'unosv_m2':round(ar['неосвоенная']),
       'osv_pct':round(100*ar['освоенная']/s,1) if s else None,'part_pct':round(100*ar['частично освоенная']/s,1) if s else None,'unosv_pct':round(100*ar['неосвоенная']/s,1) if s else None,'dominant':dom,
       'parking_m2':round(float((lab[m]==3).sum()*R*R)),'loading_m2':round(float((lab[m]==4).sum()*R*R)),'entries_n':len(es),'entries_org':eo,'entries_non':len(es)-eo}
    cf.append((tow(r['_g']),a))
fl_=[('num','INTEGER'),('is_anal','INTEGER'),('area','INTEGER'),('parcels_area','INTEGER'),('osv_m2','INTEGER'),('part_m2','INTEGER'),('unosv_m2','INTEGER'),('osv_pct','REAL'),('part_pct','REAL'),('unosv_pct','REAL'),('dominant','TEXT'),('parking_m2','INTEGER'),('loading_m2','INTEGER'),('entries_n','INTEGER'),('entries_org','INTEGER'),('entries_non','INTEGER')]
gpw.add_layer(ca,'osv_cells',gt_cells,fl_,cf)
ca.close()
pickle.dump({'cells':[(a,) for _,a in cf],'chg':chg,'cand':cand},open(OUT+'cellrows.pkl','wb'))
print('done')
