import sys; sys.path.insert(0,'lib')
import gp, numpy as np, geo, collections
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
def feats(path,t=None): return gp.read(path,t)
def info(g):
    ps=gp.polys(g); a=sum(geo.area(p[0]) for p in ps); c=np.vstack([np.array(p[0]) for p in ps]).mean(0); return a,c
c2=feats(U+'fc0568b7-competitions_2.gpkg'); c8=feats(V+'analiz_v8.gpkg','competition')
print('comp2',len(c2),'v8',len(c8))
A8=[info(r['_g']) for r in c8]
for r in c2:
    a,c=info(r['_g']); j=min(range(len(A8)),key=lambda j:np.hypot(*(A8[j][1]-c)))
    d=np.hypot(*(A8[j][1]-c)); print(r['fid'],round(a),'area attr',round(r['area'] or 0),'nearest v8',c8[j]['fid'] if 'fid' in c8[j] else j,round(A8[j][0]),'d',round(float(d),1))
used=set()
for r in c2:
    a,c=info(r['_g']); used.add(min(range(len(A8)),key=lambda j:np.hypot(*(A8[j][1]-c))))
print('v8 not matched:',[ (j,round(A8[j][0])) for j in range(len(A8)) if j not in used])
p2=feats(U+'5801ca10-playground_2.gpkg'); p8=feats(V+'analiz_v8.gpkg','playgrounds_zones')
print('pg2',len(p2),'pg8',len(p8))
P8=[info(r['_g']) for r in p8]
bad=0
for r in p2:
    a,c=info(r['_g']); j=min(range(len(P8)),key=lambda j:np.hypot(*(P8[j][1]-c)))
    d=np.hypot(*(P8[j][1]-c))
    s=''
    for k in ('type','area','dist','zone','conflict','control','problem'):
        if r[k]!=p8[j][k]: s+=f' {k}:{r[k]}!={p8[j][k]}'
    if d>0.5 or s: print(r['fid'],'d',round(float(d),2),s); bad+=1
print('differences',bad)
print(collections.Counter((r['type'],r['function'],r['isolation']) for r in p2))
print('v8 control/zone/problem',collections.Counter((r['zone'],r['control'],r['problem']) for r in p8))
