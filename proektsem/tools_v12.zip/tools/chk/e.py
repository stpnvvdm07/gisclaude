import sys; sys.path.insert(0,'lib')
import gp, numpy as np, msk
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
b8=gp.read(V+'konkovo_v8.gpkg','buildings')
bz=gp.read(U+'92246443-business_2.gpkg')
segs=[]
for o in b8:
    for pr in gp.polys(o['_g']):
        r=np.array(pr[0]); segs.append((r[:-1],r[1:]))
A=np.vstack([s[0] for s in segs]);B=np.vstack([s[1] for s in segs])
def dmin(P):
    d=B-A;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A)*d).sum(1)/L,0,1);Q=A+d*t[:,None];return np.hypot(*(P-Q).T).min()
pts=np.array([[float(x) for x in msk.utm37(np.array(r['_g'][1][0]),np.array(r['_g'][1][1]))] for r in bz])
best=None
for dx in np.arange(-25,25.1,1.0):
  for dy in np.arange(-25,25.1,1.0):
    m=np.median([dmin(p+[dx,dy]) for p in pts])
    if best is None or m<best[0]: best=(m,dx,dy)
print('raw median',np.median([dmin(p) for p in pts]),'best',best)
b=best
for dx in np.arange(b[1]-1,b[1]+1.01,0.25):
  for dy in np.arange(b[2]-1,b[2]+1.01,0.25):
    m=np.median([dmin(p+[dx,dy]) for p in pts])
    if m<best[0]: best=(m,dx,dy)
print('refined',best)
dx,dy=best[1],best[2]
d=np.array([dmin(p+[dx,dy]) for p in pts]);print('after shift: median',np.median(d),'max',d.max(),'>3m:',(d>3).sum(),'>5m:',(d>5).sum())
print('--- specific')
for dx,dy in [(0,0),(5,-9.5),(-5,9.5),(5,9.5),(-5,-9.5)]:
    d=np.array([dmin(p+[dx,dy]) for p in pts]);print(dx,dy,'median',round(float(np.median(d)),2),'<=3m:',int((d<=3).sum()),'of',len(d))
print('--- fine')
bb=None
for dx in np.arange(3,8.01,0.25):
  for dy in np.arange(7,12.01,0.25):
    d=np.array([dmin(p+[dx,dy]) for p in pts]); s=(d<=3).sum(); m=np.median(d)
    if bb is None or (s,-m)>(bb[0],-bb[1]): bb=(s,m,dx,dy)
print(bb)
dx,dy=bb[2],bb[3]
d=np.array([dmin(p+[dx,dy]) for p in pts]);print(sorted(np.round(d,1))[-12:])
