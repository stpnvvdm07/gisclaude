import numpy as np,collections,math
def pip(pts,ring):
    pts=np.asarray(pts,float).reshape(-1,2); r=np.asarray(ring,float); x,y=pts[:,0],pts[:,1]; inside=np.zeros(len(pts),bool)
    for a,b,c,d in zip(r[:-1,0],r[:-1,1],r[1:,0],r[1:,1]):
        if b==d: continue
        m=((b>y)!=(d>y))&(x<(c-a)*(y-b)/(d-b)+a); inside^=m
    return inside
def closed(r):
    r=[tuple(map(float,p)) for p in r]; return r if r[0]==r[-1] else r+[r[0]]
def area(r):
    r=np.asarray(closed(r)); return float((r[:-1,0]*r[1:,1]-r[1:,0]*r[:-1,1]).sum()/2)
def perim(r):
    r=np.asarray(closed(r)); return float(np.linalg.norm(np.diff(r,axis=0),axis=1).sum())
def ccw(r): r=closed(r); return r if area(r)>0 else r[::-1]
def grid_in(ring,step):
    r=np.asarray(closed(ring)); mn,mx=r.min(0),r.max(0)
    xs=np.arange(mn[0]+step/2,mx[0],step); ys=np.arange(mn[1]+step/2,mx[1],step)
    if len(xs)==0 or len(ys)==0: return np.array([r[:-1].mean(0)])
    g=np.array(np.meshgrid(xs,ys)).reshape(2,-1).T; g=g[pip(g,r)]
    return g if len(g) else np.array([r[:-1].mean(0)])
def simplify_collinear(ring,tol=0.02):
    r=closed(ring)[:-1]; ch=True
    while ch and len(r)>3:
        ch=False; n=len(r); keep=[]
        for i in range(n):
            a,b,c=np.array(r[i-1]),np.array(r[i]),np.array(r[(i+1)%n]); ac=c-a; L=np.linalg.norm(ac)
            d=abs(ac[0]*(b-a)[1]-ac[1]*(b-a)[0])/L if L>1e-9 else 0
            t=((b-a)@ac)/(L*L) if L>1e-9 else .5
            if d<tol and -1e-6<=t<=1+1e-6 and not ch: ch=True; continue
            keep.append(r[i])
        r=keep
    return r+[r[0]]
def dp(pts,tol):
    pts=np.asarray(pts,float)
    if len(pts)<3: return pts
    keep=np.zeros(len(pts),bool); keep[0]=keep[-1]=True; st=[(0,len(pts)-1)]
    while st:
        a,b=st.pop()
        if b-a<2: continue
        A,B=pts[a],pts[b]; ab=B-A; L=np.hypot(*ab); seg=pts[a+1:b]
        d=np.abs(ab[0]*(seg[:,1]-A[1])-ab[1]*(seg[:,0]-A[0]))/L if L>1e-9 else np.hypot(*(seg-A).T)
        i=d.argmax()
        if d[i]>tol: keep[a+1+i]=True; st+=[(a,a+1+i),(a+1+i,b)]
    return pts[keep]
def mbr(ring):
    p=np.array(closed(ring)); best=None
    for i in range(len(p)-1):
        e=p[i+1]-p[i]; L=np.linalg.norm(e)
        if L<1e-6: continue
        u=e/L; v=np.array([-u[1],u[0]]); x=p@u; y=p@v; w,h=x.max()-x.min(),y.max()-y.min()
        if best is None or w*h<best[0]*best[1]: best=(w,h)
    return max(best),min(best)
def seg_dist(P,A,B):
    """distance from points P(n,2) to segments A,B (m,2) -> (n,m)"""
    P=np.asarray(P,float)[:,None,:]; A=np.asarray(A,float)[None]; B=np.asarray(B,float)[None]; ab=B-A
    t=np.clip(((P-A)*ab).sum(-1)/np.maximum((ab*ab).sum(-1),1e-12),0,1)
    return np.linalg.norm(A+t[...,None]*ab-P,axis=-1)
