import sys; sys.path.insert(0,'lib')
import dxf, gp, xf, numpy as np
from scipy.spatial import cKDTree
V='/mnt/user-data/uploads/proektsem/vector/'
def dens(P,s=0.3):
    out=[]
    for a,b in zip(P[:-1],P[1:]):
        n=max(1,int(np.hypot(*(b-a))/s)); out+= [a+(b-a)*i/n for i in range(n)]
    return out
res={}
for lay,key in (('PROEZDY','проезд'),('DOR_DOROZHKA','дорожка'),('ТРОТУАРЫ','тротуар'),('ПЕШЕХОДНЫЕ_ДОРОЖКИ','дорожка')):
    E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf',layers={lay}); pts=[]
    for e in E:
        P=np.array(e['pts'])
        if len(P)>=2: pts+=dens(np.array(xf.cad2utm(P)))
    T=cKDTree(np.array(pts)); res[lay]=T
n=gp.read(V+'analiz_v8.gpkg','network')
for t,lay in (('проезд','PROEZDY'),('дорожка','DOR_DOROZHKA'),('тротуар','ТРОТУАРЫ')):
    d=[]
    for r in n:
        if r['type']!=t: continue
        for l in gp.lines(r['_g']):
            a=np.array(l); m=a[len(a)//2]
            d.append(res[lay].query(m)[0])
    d=np.array(d); print(t,'n',len(d),'median dist to edge',np.median(d).round(2),'p25',np.percentile(d,25).round(2),'p75',np.percentile(d,75).round(2))
