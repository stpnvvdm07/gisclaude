import sys; sys.path.insert(0,'lib')
import dxf, collections
E=dxf.read('/mnt/user-data/uploads/yacheiki_1_v8.dxf')
c=collections.Counter((e['layer'],e['type']) for e in E)
for k,v in sorted(c.items(),key=lambda x:str(x[0])): print(k,v)
