"""Raster boolean ops on polygons (no shapely). Window-based, res in metres."""
import numpy as np, cv2
class Win:
    def __init__(s,x0,y0,x1,y1,res=0.2):
        s.x0,s.y0,s.res=x0,y0,res; s.w=int(np.ceil((x1-x0)/res)); s.h=int(np.ceil((y1-y0)/res))
    def px(s,P):
        P=np.asarray(P,float); return np.c_[(P[:,0]-s.x0)/s.res,(P[:,1]-s.y0)/s.res]
    def blank(s): return np.zeros((s.h,s.w),np.uint8)
    def fill(s,m,rings,val=1,holes=()):
        for r in rings:
            cv2.fillPoly(m,[np.round(s.px(r)*16).astype(np.int32)],val,shift=4)
        for r in holes:
            cv2.fillPoly(m,[np.round(s.px(r)*16).astype(np.int32)],0,shift=4)
        return m
    def line(s,m,pts,halfw,val=1):
        cv2.polylines(m,[np.round(s.px(pts)*16).astype(np.int32)],False,val,thickness=max(1,int(round(2*halfw/s.res))),lineType=cv2.LINE_8,shift=4)
        return m
    def polys(s,m,eps=0.12,minarea=0.5):
        """mask -> list of [outer, hole,...] rings in world coords"""
        m=(m>0).astype(np.uint8)
        cs,h=cv2.findContours(m,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_NONE)
        if h is None: return []
        h=h[0]; out={}
        def conv(c):
            a=cv2.approxPolyDP(c,eps/s.res,True)[:,0,:].astype(float)
            if len(a)<3: return None
            P=np.c_[s.x0+(a[:,0]+0.5)*s.res,s.y0+(a[:,1]+0.5)*s.res]
            # pixel centres -> shift by half pixel outward is ignored (<=res/2)
            return P
        for i,c in enumerate(cs):
            if h[i][3]==-1:
                P=conv(c)
                if P is None: continue
                if abs(_a(P))<minarea: continue
                out[i]=[np.vstack([P,P[:1]])]
        for i,c in enumerate(cs):
            if h[i][3]!=-1 and h[i][3] in out:
                P=conv(c)
                if P is not None and abs(_a(P))>=minarea: out[h[i][3]].append(np.vstack([P,P[:1]]))
        return list(out.values())
def _a(P):
    x,y=P[:,0],P[:,1]; return 0.5*np.sum(x*np.roll(y,-1)-np.roll(x,-1)*y)
def ringarea(r):
    r=np.asarray(r); return 0.5*np.sum(r[:-1,0]*r[1:,1]-r[1:,0]*r[:-1,1])
def polyarea(p): return abs(ringarea(p[0]))-sum(abs(ringarea(h)) for h in p[1:])
