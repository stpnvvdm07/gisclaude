import sys,pickle;sys.path.insert(0,'lib')
import gp,io9,numpy as np,matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as P
K='in2/konkovo_v9.gpkg'; A='out9/analiz_v9.gpkg'
col={'арка':'purple','ворота':'red','калитка':'orange','въезд':'blue','разрыв в застройке':'green','разрыв в насаждениях':'olive','не зафиксирован':'black'}
fig,ax=plt.subplots(figsize=(22,22))
def polys(t,**k):
    for g,a in io9.load(K,t)[2]:
        for p in gp.polys(g): ax.add_patch(P(np.array(p[0]),closed=True,**k))
polys('boundary',fill=False,ec='gray',lw=1,ls='--')
polys('cells',fill=False,ec='k',lw=0.8)
polys('buildings',fc='#ddd',ec='#999',lw=0.3)
polys('green',fc='#cfe8c0',ec='none',alpha=.6)
for g,a in io9.load(A,'network')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='#c80' if a['type']=='проезд' else '#06c',lw=.8)
for g,a in io9.load(K,'fences')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='brown',lw=1.2)
for g,a in io9.load(K,'arches')[2]:
    for l in gp.lines(g): l=np.array(l);ax.plot(l[:,0],l[:,1],c='purple',lw=2.5)
for g,a in io9.load(K,'gates')[2]: ax.plot(*g[1],'s',c='m',ms=6,mfc='none')
for i,(g,a) in enumerate(io9.load(K,'entries_territory')[2]):
    k=a['podtip'].replace('Вход — ','');ax.plot(*g[1],'o',c=col[k],ms=8);ax.text(g[1][0]+3,g[1][1]+3,str(i),fontsize=9,color=col[k])
for g,a in io9.load(A,'flows')[2]: ax.plot(*g[1],'*',c='r',ms=12)
ax.set_aspect('equal');ax.autoscale()
ax.legend(handles=[plt.Line2D([],[],marker='o',ls='',c=c,label=k) for k,c in col.items()]+[plt.Line2D([],[],marker='*',ls='',c='r',label='замер потока'),plt.Line2D([],[],marker='s',ls='',mfc='none',c='m',label='gates')])
plt.savefig('chk/ent_all.png',dpi=60,bbox_inches='tight')
xs=[g[1][0] for g,a in io9.load(K,'entries_territory')[2]];ys=[g[1][1] for g,a in io9.load(K,'entries_territory')[2]]
print(min(xs),max(xs),min(ys),max(ys))
