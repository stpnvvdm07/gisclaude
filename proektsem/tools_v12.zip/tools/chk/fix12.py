# v12: исправленные входы/узлы и освоенность. Источник: konkovo_v10, analiz_v10, parcels12.pkl
import sys,pickle,collections,cv2;sys.path.insert(0,'lib')
import gp,gpw,io9,rb,numpy as np
from io9 import tow
exec(open('chk/osv12rule.py').read())
K='out10/konkovo_v10.gpkg';A='out10/analiz_v10.gpkg';OUT='out12/'
scope=set(pickle.load(open('out10/viol2.pkl','rb'))['scope'])
DEG={'высокая':3,'средняя':2,'низкая':1,'нет':0}
# ---------- konkovo_v12
ck=gpw.create(OUT+'konkovo_v12.gpkg')
cells=io9.load(K,'cells')[2]
for t in [r[0] for r in __import__('sqlite3').connect('file:'+K+'?immutable=1',uri=True).execute('select table_name from gpkg_geometry_columns')]:
    if t in ('entries_territory','entry_nodes'): continue
    gt,f,rows=io9.load(K,t); gpw.add_layer(ck,t,gt,f,[(tow(g),a) for g,a in rows])
gt,f,ents=io9.load(K,'entries_territory')
chg=[];et=[]
for g,a in ents:
    new='организован' if DEG[a['degree']]>=2 else 'не организован'
    if new!=a['fix_class']: chg.append((a['podtip'],a['fix_class'],new,a['evidence']))
    b=dict(a);b['fix_v10']=a['fix_class'];b['fix_class']=new
    b['in_12']='да' if a['level']=='внешний' else 'нет (внутренний проход)'
    et.append((tow(g),b))
gpw.add_layer(ck,'entries_territory',gt,f+[('fix_v10','TEXT'),('in_12','TEXT')],et)
# узлы: организован, только если все входы узла организованы
allp=np.vstack([np.array(p[0]) for g,a in cells for p in gp.polys(g)])
CW=rb.Win(*(allp.min(0)-15),*(allp.max(0)+15),0.5);CL=np.zeros((CW.h,CW.w),np.int16)
isan={a['num']:a['is_anal'] for g,a in cells}
for g,a in cells:
    for p in gp.polys(g): CW.fill(CL,[np.array(p[0])],a['num'],holes=[np.array(h) for h in p[1:]])
def near_cells(pt,r=8):
    px=int((pt[0]-CW.x0)/0.5);py=int((pt[1]-CW.y0)/0.5);k=int(r/0.5)
    sub=CL[max(py-k,0):py+k+1,max(px-k,0):px+k+1]
    return set(np.unique(sub).tolist())-{0}
nodes=collections.defaultdict(list)
for g,a in et: nodes[a['node']].append((np.array(g[1]),a))
nf=[]
for n,rs in sorted(nodes.items()):
    c=np.mean([p for p,a in rs],axis=0)
    org=all(a['fix_class']=='организован' for p,a in rs)
    worst=min(rs,key=lambda x:DEG[x[1]['degree']])[1]['degree']
    lvl='внешний' if any(a['level']=='внешний' for p,a in rs) else 'внутренний'
    nc=set().union(*[near_cells(p) for p,a in rs])
    inner=sorted(x for x in nc if isan[x]==1) or sorted(x for x in nc if x in scope)
    nf.append((('Point',(float(c[0]),float(c[1]))),{'node':n,'n':len(rs),'ways':', '.join(sorted(set(a['podtip'][7:] for p,a in rs))),'fix_class':'организован' if org else 'не организован','degree':worst,'level':lvl,
              'in_12':'да' if lvl=='внешний' else 'нет','cells':','.join(map(str,inner))}))
gpw.add_layer(ck,'entry_nodes','POINT',[('node','INTEGER'),('n','INTEGER'),('ways','TEXT'),('fix_class','TEXT'),('degree','TEXT'),('level','TEXT'),('in_12','TEXT'),('cells','TEXT')],nf)
ck.close()
# ---------- analiz_v12
ca=gpw.create(OUT+'analiz_v12.gpkg')
for t in [r[0] for r in __import__('sqlite3').connect('file:'+A+'?immutable=1',uri=True).execute('select table_name from gpkg_geometry_columns')]:
    if t in ('osvoennost','osv_cells'): continue
    gt,f,rows=io9.load(A,t); gpw.add_layer(ca,t,gt,f,[(tow(g),a) for g,a in rows])
P=pickle.load(open(OUT+'parcels12.pkl','rb'))
lab=np.load('out10/lab.npy');w=pickle.load(open('out10/win.pkl','rb'));R=w['res']
W=rb.Win(w['x0'],w['y0'],w['x0']+lab.shape[1]*R,w['y0']+lab.shape[0]*R,R);W.h,W.w=lab.shape
EX=W.blank()
for g,a in io9.load(K,'cells_excluded')[2]:
    for p in gp.polys(g): W.fill(EX,[np.array(p[0])],1)
CLr=np.zeros(lab.shape,np.int16)
for g,a in cells:
    for p in gp.polys(g): W.fill(CLr,[np.array(p[0])],a['num'],holes=[np.array(h) for h in p[1:]])
pf=[];stat=collections.Counter()
for p in P:
    allr=np.vstack([np.array(r) for rings in p['poly'] for r in rings[:1]])
    x0,y0=allr.min(0)-1;x1,y1=allr.max(0)+1;sw=rb.Win(x0,y0,x1,y1,R);m=sw.blank()
    for rings in p['poly']: sw.fill(m,[np.array(rings[0])],1,holes=[np.array(h) for h in rings[1:]])
    i0=int(round((x0-W.x0)/R));j0=int(round((y0-W.y0)/R))
    ex=EX[j0:j0+m.shape[0],i0:i0+m.shape[1]];cl=CLr[j0:j0+m.shape[0],i0:i0+m.shape[1]]
    exs=float((ex[m>0]>0).mean()) if ex.shape==m.shape else 0
    cc=np.bincount(cl[m>0][cl[m>0]>0]) if ex.shape==m.shape and (cl[m>0]>0).any() else np.array([0])
    cell=int(cc.argmax()) if cc.sum() else 0
    b=B12(p);u,uw=U12(p);c=cls12(p);note=None
    if exs>=0.5: c,note='не оценивается','территория учреждения (школа, детсад)'
    elif cell==0 or cell not in scope: c,note='не оценивается','вне ячеек анализа'
    elif c=='полоса': c,note='не оценивается','полоса уже 5 м (отмостка, обочина)'
    elif p['man']>=0.5 and not p['kind'].startswith('площадка'): note='ручной контур команды';b,u,uw=0,0,'контур команды «неосвоенная»'
    stat[c]+=p['area']
    sh=lambda q:0.5*abs(np.dot(q[:-1,0],q[1:,1])-np.dot(q[1:,0],q[:-1,1]))
    pas=[sh(np.asarray(r[0]))-sum(sh(np.asarray(h)) for h in r[1:]) for r in p['poly']]
    for rings,pa0 in zip(p['poly'],pas):
        pf.append((('Polygon',[np.asarray(r).tolist() for r in rings]),{'kind':p['kind'],'area':round(p['area']*pa0/sum(pas)),'cell':cell,'in_scope':1 if cell in scope else 0,
          'B':b,'B_why':('контур команды «неосвоенная»' if note=='ручной контур команды' else 'откос / подпорная стенка (≥30 % площади)') if not b else ('площадка' if p['kind'].startswith('площадка') else ('озеленение' if p['kind'] in ('трава','деревья') else 'покрытие (принято)')),
          'U':u,'U_why':uw,'slope_pct':round(100*p['slope_sh']),'path_pct':round(100*p['near_path']),'pod_pct':round(100*p['near_pod']),'cls':c,'note':note}))
gpw.add_layer(ca,'osvoennost','POLYGON',[('kind','TEXT'),('area','INTEGER'),('cell','INTEGER'),('in_scope','INTEGER'),('B','INTEGER'),('B_why','TEXT'),('U','INTEGER'),('U_why','TEXT'),('slope_pct','INTEGER'),('path_pct','INTEGER'),('pod_pct','INTEGER'),('cls','TEXT'),('note','TEXT')],pf)
# osv_cells
agg=collections.defaultdict(collections.Counter)
for g,a in pf: agg[a['cell']][a['cls']]+=a['area']
nodec=collections.defaultdict(list)
for g,a in nf:
    if a['in_12']=='да':
        for c in [int(x) for x in a['cells'].split(',') if x]: nodec[c].append(a)
cf=[]
for g,a in cells:
    n=a['num'];s=agg[n];tot=s['освоенная']+s['частично освоенная']+s['неосвоенная']
    m_=CLr==n
    ns=nodec.get(n,[])
    cf.append((tow(g),{'num':n,'is_anal':a['is_anal'],'in_scope':1 if n in scope else 0,'area':round(float(m_.sum()*R*R)),'assessed_m2':round(tot),'osv_m2':round(s['освоенная']),'part_m2':round(s['частично освоенная']),'unosv_m2':round(s['неосвоенная']),
      'osv_pct':round(100*s['освоенная']/tot,1) if tot else None,'part_pct':round(100*s['частично освоенная']/tot,1) if tot else None,'unosv_pct':round(100*s['неосвоенная']/tot,1) if tot else None,
      'parking_m2':round(float((lab[m_]==3).sum()*R*R)),'loading_m2':round(float((lab[m_]==4).sum()*R*R)),'nodes_n':len(ns),'nodes_org':sum(1 for x in ns if x['fix_class']=='организован'),'nodes_non':sum(1 for x in ns if x['fix_class']!='организован')}))
gpw.add_layer(ca,'osv_cells','POLYGON',[('num','INTEGER'),('is_anal','INTEGER'),('in_scope','INTEGER'),('area','INTEGER'),('assessed_m2','INTEGER'),('osv_m2','INTEGER'),('part_m2','INTEGER'),('unosv_m2','INTEGER'),('osv_pct','REAL'),('part_pct','REAL'),('unosv_pct','REAL'),('parking_m2','INTEGER'),('loading_m2','INTEGER'),('nodes_n','INTEGER'),('nodes_org','INTEGER'),('nodes_non','INTEGER')],cf)
ca.close()
pickle.dump(dict(chg=chg,nodes=[a for g,a in nf],stat=dict(stat)),open(OUT+'fix12.pkl','wb'))
print('entries changed',len(chg),collections.Counter((c[0],c[1],c[2]) for c in chg))
print('nodes',collections.Counter((a['level'],a['fix_class']) for g,a in nf))
print('osv',{k:round(v) for k,v in stat.items()})
print('nodes non ext per cell',{k:len([x for x in v if x['fix_class']!='организован']) for k,v in sorted(nodec.items())})
