import sys,pickle; sys.path.insert(0,'lib')
exec(open('chk/fix2d.py').read().split("print('--- affine ICP')")[0].replace("print(","(lambda *a,**k:None)("))
def fit(P,Q,w):
    X=np.c_[P,np.ones(len(P))];W=np.sqrt(w)[:,None];M,_,_,_=np.linalg.lstsq(X*W,Q*W,rcond=None);return M
def apply(M,P): return np.c_[P,np.ones(len(P))]@M
idx=[i for i in range(len(P0)) if grp[i]!='Вв']; c0=P0[idx].mean(0); Pc=P0-c0
M=np.array([[1,0],[0,1],[7.5,-4.5]],float)
for it in range(30):
    cur=apply(M,Pc); T=[];ds=[]
    for i in idx:
        d,q=dproj(cur[i]+c0,bid[i]); T.append(q-c0); ds.append(d)
    ds=np.array(ds); M=fit(Pc[idx],np.array(T),1/np.maximum(ds,0.5))
print('affine linear',M[:2].round(4).tolist(),'shift',M[2].round(2))
cur=apply(M,Pc)+c0
rows=[]
for i,r in enumerate(bz):
    d,q=dproj(cur[i],bid[i]); rows.append((r['fid'],i,bid[i],d,q,cur[i]))
res=np.array([x[3] for x in rows])
print('residual (own-building facade): median',round(float(np.median(res)),2),'<=2m',int((res<=2).sum()),'2-4m',int(((res>2)&(res<=4)).sum()),'>4m',int((res>4).sum()))
# Введенского 16: raw coordinates inside bld 13? use affine too
final=[];issues=[]
for fid,i,b,d,q,c in rows:
    pos=q if d<=12 else c
    final.append((fid,b,pos,d))
    if d>4: issues.append((fid,bz[i]['adress'],bz[i]['Название'],round(float(d),1)))
print('flagged',issues)
pickle.dump({'final':final,'issues':issues,'M':M,'c0':c0},open('out9/biz.pkl','wb'))
print('--- check nearest by geometry for flagged/55с3')
for fid,i,b,d,q,c in rows:
    if bz[i]['adress'] in ('Миклухо-Маклая 55с3','Введенского 16') or d>4:
        ds={k:round(float(dproj(c,k)[0]),1) for k in SG}
        top=sorted(ds.items(),key=lambda x:x[1])[:3]
        print(fid,bz[i]['adress'],bz[i]['Название'],'assigned',b,round(float(d),1),'nearest',top)
