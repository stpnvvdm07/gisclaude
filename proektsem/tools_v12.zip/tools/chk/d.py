import sys; sys.path.insert(0,'lib')
import gp, math, collections, numpy as np, msk, geo
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
b8=gp.read(V+'konkovo_v8.gpkg','buildings')
bz=gp.read(U+'92246443-business_2.gpkg')
def segd(P,A,B):
    A=np.array(A);B=np.array(B);P=np.array(P);d=B-A;L=d@d
    t=0 if L==0 else max(0,min(1,((P-A)@d)/L)); return float(np.hypot(*(P-(A+t*d))))
def inside(P,g):
    for pr in gp.polys(g):
        if geo.pip([P],pr[0])[0] if False else False: pass
    return False
rings=[]
for o in b8:
    for pr in gp.polys(o['_g']): rings.append((o['id'],pr[0]))
def pipt(P,ring):
    x,y=P;c=False
    for i in range(len(ring)-1):
        x1,y1=ring[i];x2,y2=ring[i+1]
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1:c=not c
    return c
res=[]
for r in bz:
    lon,lat=r['_g'][1]; e,n=msk.utm37(np.array(lon),np.array(lat)); P=(float(e),float(n))
    best=(1e9,None);ins=None
    for bid,ring in rings:
        if pipt(P,ring): ins=bid
        for i in range(len(ring)-1):
            d=segd(P,ring[i],ring[i+1])
            if d<best[0]: best=(d,bid)
    res.append((r['fid'],P,ins,best))
    print(r['fid'],r['adress'],r['Название'],r['характер размещения'],'inside' if ins else '', ins, 'nearest bld',best[1],round(best[0],1))
# duplicates
print('dup coords:')
P=np.array([x[1] for x in res])
for i in range(len(P)):
    for j in range(i+1,len(P)):
        d=np.hypot(*(P[i]-P[j]))
        if d<2: print(res[i][0],res[j][0],round(float(d),2))
