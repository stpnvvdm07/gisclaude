import sys,pickle,cv2,collections;sys.path.insert(0,'lib')
import gp,io9,numpy as np,networkx as nx
A='out9/analiz_v9.gpkg';K='in2/konkovo_v9.gpkg'
d=pickle.load(open('out9/ent3.pkl','rb'));U=d['U'];x0,y0,x1,y1,R=d['win']
DT=cv2.distanceTransform(U,cv2.DIST_L2,5)*R
def dep(p):
    return DT[min(max(int((p[1]-y0)/R),0),DT.shape[0]-1),min(max(int((p[0]-x0)/R),0),DT.shape[1]-1)]
net=io9.load(A,'network')[2]
key=lambda p:(round(p[0]*2),round(p[1]*2))
G=nx.Graph()
for i,(g,a) in enumerate(net):
    for l in gp.lines(g):
        l=np.array(l);L=float(np.hypot(*np.diff(l,axis=0).T).sum())
        mid=l[len(l)//2]
        G.add_edge(key(l[0]),key(l[-1]),i=i,L=L,dm=min(dep(q) for q in l),typ=a['type'])
M=d['M']
res=[]
for j,m in enumerate(M):
    # start nodes: endpoints of incident edges nearest to crossing, on inner side
    best=0;reach=0
    for (i,t) in m['n']:
        es=[(u,v) for u,v,dd in G.edges(data=True) if dd['i']==i]
        for u,v in es:
            for s in (u,v):
                dd=dep((s[0]/2,s[1]/2))
                if dd<3: continue
                # BFS avoiding strip edges (min depth <3 on both ends)
                H=nx.Graph([(a,b,dt) for a,b,dt in G.edges(data=True) if not (dep((a[0]/2,a[1]/2))<3 and dep((b[0]/2,b[1]/2))<3)])
                if s not in H:continue
                lens=nx.single_source_dijkstra_path_length(H,s,cutoff=250,weight='L')
                mx=max(dep((n[0]/2,n[1]/2)) for n in lens)
                best=max(best,mx);reach=max(reach,len(lens))
    res.append((j,np.round(m['p']),round(float(best),1),reach,m['near']))
    print(j,np.round(m['p']),'max depth reached',round(float(best),1),'nodes',reach,'nearest entry',m['near'])
