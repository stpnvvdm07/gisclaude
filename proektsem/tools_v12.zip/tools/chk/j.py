import sys; sys.path.insert(0,'lib')
import gp, numpy as np
V='/mnt/user-data/uploads/proektsem/vector/'
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
ent=gp.read(U+'81ecacc9-entrances_points_1.gpkg'); et=gp.read(V+'konkovo_v8.gpkg','entries_territory')
E=np.array([r['_g'][1] for r in et]); P=np.array([r['_g'][1] for r in ent])
def f(sh): d=np.hypot(*((E[None]-(P+sh)[:,None])).transpose(2,0,1)).min(1); return d
print('raw med',np.median(f((0,0))))
best=None
for dx in np.arange(-12,12.1,0.5):
  for dy in np.arange(-12,12.1,0.5):
    d=f((dx,dy)); s=(np.median(d),(d<5).sum())
    if best is None or s[0]<best[0][0]: best=(s,dx,dy)
print(best); d=f((best[1],best[2])); print(np.round(np.sort(d),1))
print('(5,9.5)',np.median(f((5,9.5))),(f((5,9.5))<5).sum())
