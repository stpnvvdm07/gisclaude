import sys; sys.path.insert(0,'lib')
import gp, numpy as np, collections
V='/mnt/user-data/uploads/proektsem/vector/'
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
for t in ('ped_exits','veh_exits','roads_tree','roads_tree_start','network'):
    rs=gp.read(V+'analiz_v8.gpkg',t); print(t,len(rs),{k:v for k,v in rs[0].items() if k!='_g'},rs[0]['_g'][0])
    if t=='roads_tree': print(collections.Counter(r['group'] for r in rs), collections.Counter(r['workload'] for r in rs).most_common(8))
et=gp.read(V+'konkovo_v8.gpkg','entries_territory'); print('entries_territory',len(et),et[0]['_g'], {k:v for k,v in et[0].items() if k!='_g'})
