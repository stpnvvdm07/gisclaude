import sys,pickle,collections; sys.path.insert(0,'lib')
import gp,io9,rb,geo,numpy as np,msk
U='/root/.claude/uploads/8d9b1c11-c411-58d4-b1c3-22f59a5b6165/'
V='/mnt/user-data/uploads/proektsem/vector/'
K=V+'konkovo_v8.gpkg'; A=V+'analiz_v8.gpkg'
log=[]
def say(*a): s=' '.join(str(x) for x in a); print(s); log.append(s)
bgt,bf,bld=io9.load(K,'buildings')
# ---- buildings assessment by fid
b2=gp.read(U+'c21fbc75-buildings_2.gpkg')
v8=gp.read(K,'buildings'); fid2id={r['fid']:r for r in v8}
out={}
for r in b2:
    o=fid2id.get(r['fid'])
    ar=lambda g:round(sum(abs(rb.ringarea(p[0])) for p in gp.polys(g)),1)
    ok = o is not None and ar(o['_g'])==ar(r['_g'])
    say('bld fid',r['fid'],'id',r['id'],'matched v8 fid',bool(o),'same area',ok)
    out[r['fid']]={k:r[k] for k in ('function','danger','isolation')}
# ---- business: shift
bz=gp.read(U+'92246443-business_2.gpkg')
rings=[np.array(p[0]) for g,_ in [(r['_g'],0) for r in v8] for p in gp.polys(g)]
rid=[r['id'] for r in v8 for p in gp.polys(r['_g'])]
A_=np.vstack([r[:-1] for r in rings]);B_=np.vstack([r[1:] for r in rings]);SID=np.concatenate([[rid[i]]*(len(rings[i])-1) for i in range(len(rings))])
def nearest(P):
    d=B_-A_;L=(d**2).sum(1)+1e-9;t=np.clip(((P-A_)*d).sum(1)/L,0,1);Q=A_+d*t[:,None];D=np.hypot(*(P-Q).T);j=D.argmin();return D[j],SID[j],Q[j]
P0=np.array([[float(x) for x in msk.utm37(np.array(r['_g'][1][0]),np.array(r['_g'][1][1]))] for r in bz])
best=None
for dx in np.arange(2,9.01,0.25):
  for dy in np.arange(6,13.01,0.25):
    c=sum(min(nearest(p+[dx,dy])[0],6) for p in P0)
    if best is None or c<best[0]: best=(c,dx,dy)
say('business shift',best[1],best[2],'mean robust residual',round(best[0]/len(P0),2))
dx,dy=best[1],best[2]
P=P0+[dx,dy]
# by cluster residual
res=[]
for r,p in zip(bz,P):
    d,i,q=nearest(p); res.append((r['fid'],r['adress'],d,i,q))
import itertools
for ad,g in itertools.groupby(sorted(res,key=lambda x:x[1]),key=lambda x:x[1]):
    g=list(g); say('  ',ad,'n',len(g),'median resid',round(float(np.median([x[2] for x in g])),1),'max',round(max(x[2] for x in g),1))
bad=[x for x in res if x[2]>4]; say('points >4 m from a facade after shift:',[(x[0],round(x[2],1)) for x in bad])
pickle.dump({'bld_assess':out,'biz_shift':(dx,dy),'biz_P':P,'biz_res':[(x[0],x[2],x[3]) for x in res]},open('out9/fix2.pkl','wb'))
# ---- playgrounds
pgt,pff,pg8=io9.load(A,'playgrounds_zones')
p2=gp.read(U+'5801ca10-playground_2.gpkg')
def cen(g): return np.vstack([np.array(p[0]) for p in gp.polys(g)]).mean(0)
def area(g): return sum(abs(rb.ringarea(p[0])) for p in gp.polys(g))
C8=np.array([cen(g) for g,_ in pg8]); A8=np.array([area(g) for g,_ in pg8])
sh=np.array([-0.12,-5.68]); match={}; used=set()
order=sorted(range(len(p2)),key=lambda i:-area(p2[i]['_g']))
for i in order:
    c=cen(p2[i]['_g'])+sh; a=area(p2[i]['_g'])
    cost=np.hypot(*(C8-c).T)+np.abs(A8-a)/max(a,1)*20
    for u in used: cost[u]=1e9
    j=int(cost.argmin()); used.add(j); match[i]=j
    t8=pg8[j][1]['type']
    say('pg2',p2[i]['fid'],p2[i]['type'],'-> v8',j,t8,'d',round(float(np.hypot(*(C8[j]-c))),2),'area',round(a),round(A8[j]),'OK' if t8==p2[i]['type'] else 'TYPE MISMATCH')
pickle.dump({'pg_match':match},open('out9/fix2b.pkl','wb'))
open('out9/log2.txt','w').write('\n'.join(log))
