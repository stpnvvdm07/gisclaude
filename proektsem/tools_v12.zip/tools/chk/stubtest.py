import sys,glob,types,py_compile
from unittest import mock
for m in ['qgis','qgis.core','qgis.PyQt','qgis.PyQt.QtGui','qgis.utils']:
    sys.modules[m]=mock.MagicMock()
sys.modules['qgis.PyQt.QtGui'].QFontDatabase.return_value.families.return_value=[]
ok=0
for f in sorted(glob.glob('maps/*.py')):
    py_compile.compile(f,doraise=True)
    src=open(f,encoding='utf-8').read()
    g={'__name__':'__main__'}
    try: exec(compile(src,f,'exec'),g); ok+=1
    except Exception as e: print('ERR',f,type(e).__name__,e)
print('ok',ok)
