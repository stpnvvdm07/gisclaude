import sqlite3,struct,math
def _wkb(b,o=0):
    bo='<' if b[o]==1 else '>'
    t,=struct.unpack_from(bo+'I',b,o+1); o+=5
    hasz=(t//1000 in(1,3)) or bool(t&0x80000000); hasm=(t//1000 in(2,3)) or bool(t&0x40000000)
    if t&0x20000000: o+=4
    base=(t&0xffff)%1000; d=2+hasz+hasm
    def pts(o):
        n,=struct.unpack_from(bo+'I',b,o); o+=4
        v=struct.unpack_from(bo+'%dd'%(n*d),b,o); o+=8*n*d
        return [(v[i*d],v[i*d+1]) for i in range(n)],o
    if base==1:
        v=struct.unpack_from(bo+'%dd'%d,b,o); return ('Point',(v[0],v[1])),o+8*d
    if base==2:
        p,o=pts(o); return ('LineString',p),o
    if base==3:
        n,=struct.unpack_from(bo+'I',b,o); o+=4; rs=[]
        for _ in range(n):
            p,o=pts(o); rs.append(p)
        return ('Polygon',rs),o
    if base in(4,5,6,7):
        n,=struct.unpack_from(bo+'I',b,o); o+=4; gs=[]
        for _ in range(n):
            g,o=_wkb(b,o); gs.append(g)
        return ({4:'MultiPoint',5:'MultiLineString',6:'MultiPolygon',7:'GC'}[base],gs),o
    raise ValueError(t)
def geom(blob):
    if blob is None: return None
    fl=blob[3]; env=[0,32,48,48,64][(fl>>1)&7]
    return _wkb(blob,8+env)[0]
def layers(path):
    c=sqlite3.connect('file:'+path+'?mode=ro&immutable=1',uri=True)
    return [r[0] for r in c.execute("select table_name from gpkg_contents")]
def read(path,table=None):
    c=sqlite3.connect('file:'+path+'?mode=ro&immutable=1',uri=True)
    if table is None: table=c.execute("select table_name from gpkg_contents").fetchone()[0]
    gc=c.execute("select column_name from gpkg_geometry_columns where table_name=?",(table,)).fetchone()[0]
    cur=c.execute(f'select * from "{table}"'); cols=[d[0] for d in cur.description]
    out=[]
    for r in cur:
        d=dict(zip(cols,r)); d['_g']=geom(d.pop(gc)); out.append(d)
    return out
def polys(g):
    if g is None: return []
    if g[0]=='Polygon': return [g[1]]
    if g[0]=='MultiPolygon': return [x[1] for x in g[1]]
    return []
def lines(g):
    if g is None: return []
    if g[0]=='LineString': return [g[1]]
    if g[0]=='MultiLineString': return [x[1] for x in g[1]]
    return []
